"""
Preload / warm-up script — tải sẵn TẤT CẢ model cần thiết trước khi chạy
pipeline, để lúc chạy thật (`create_kb_from_file.py`, `worker.py`,
`api/main.py`...) không có request nào phải tải model giữa chừng nữa.

Model nào được tải và tải ở đâu:
  - sentence-transformers embedding model (B1/B2/D)  -> ~/.cache/huggingface
  - cross-encoder reranker model (D.5)                -> ~/.cache/huggingface
  - GLiNER NER model (A3.2, optional)                 -> ~/.cache/huggingface
Tất cả cache vào cùng 1 thư mục `~/.cache/huggingface` (chuẩn của HF), nên
chỉ cần tải 1 lần — các lần chạy sau (kể cả container mới nếu mount volume
này vào) sẽ đọc từ cache, không đụng mạng nữa.

Chạy 1 lần duy nhất, trước khi bắt đầu dùng pipeline:
    pip install -r requirements.txt --break-system-packages
    python scripts/preload_models.py

Muốn tải nhanh hơn / tránh warning rate-limit: set HF_TOKEN trước khi chạy
    export HF_TOKEN=hf_xxxxxxxx
    python scripts/preload_models.py

Sau khi preload xong, chạy pipeline với HF_HUB_OFFLINE=1 để ĐẢM BẢO không
bao giờ có request mạng nào tới Hugging Face nữa (sẽ lỗi rõ ràng thay vì
tải ngầm, nếu thiếu model nào chưa preload):
    export HF_HUB_OFFLINE=1
"""
from __future__ import annotations

import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from common.config import settings


def _step(name: str):
    print(f"\n--- {name} ---")


# def preload_embedding_model():
#     _step(f"Embedding model: {settings.embedding_model_name}")
#     if settings.embedding_mode == "hash":
#         print("EMBEDDING_MODE=hash -> bỏ qua, không dùng Hugging Face.")
#         return
#     from sentence_transformers import SentenceTransformer
#     t0 = time.time()
#     model = SentenceTransformer(settings.embedding_model_name)
#     _ = model.encode(["warm-up sentence"], normalize_embeddings=True)
#     print(f"OK ({time.time() - t0:.1f}s) — đã cache vào ~/.cache/huggingface")


def preload_embedding_model():
    _step(f"Embedding model: {settings.embedding_model_name}")
    if settings.embedding_mode == "hash":
        print("EMBEDDING_MODE=hash -> bỏ qua, không dùng Hugging Face.")
        return
    from sentence_transformers import SentenceTransformer
    t0 = time.time()
    model = SentenceTransformer("BAAI/bge-m3")
    _ = model.encode(["warm-up sentence"], normalize_embeddings=True)
    print(f"OK ({time.time() - t0:.1f}s) — đã cache vào ~/.cache/huggingface")

def preload_reranker_model():
    _step("Cross-encoder reranker: BAAI/bge-reranker-v2-m3 (dùng ở stage D.5)")
    try:
        from sentence_transformers import CrossEncoder
        t0 = time.time()
        model = CrossEncoder("BAAI/bge-reranker-v2-m3")
        _ = model.predict([("warm-up query", "warm-up document")])
        print(f"OK ({time.time() - t0:.1f}s)")
    except Exception as e:
        print(f"BỎ QUA (không bắt buộc, D sẽ fallback về thứ tự RRF nếu thiếu): {e}")


# def preload_gliner_model():
#     _step("GLiNER NER model: urchade/gliner_small-v2.1 (dùng ở stage A3.2, optional)")
#     try:
#         from gliner import GLiNER
#         t0 = time.time()
#         model = GLiNER.from_pretrained("urchade/gliner_small-v2.1")
#         _ = model.predict_entities("warm-up text about Kubernetes", ["technology"])
#         print(f"OK ({time.time() - t0:.1f}s)")
#     except ImportError:
#         print("BỎ QUA — package `gliner` chưa cài (A3 sẽ tự fallback về regex NER, vẫn chạy được). "
#               "Cài bằng `pip install gliner` nếu muốn NER chính xác hơn.")
#     except Exception as e:
#         print(f"BỎ QUA: {e}")


def main():
    os.environ["HF_TOKEN"] = "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"
    print("=" * 70)
    print("PRELOAD MODELS — chạy 1 lần trước khi start pipeline")
    print(f"HF cache dir: {os.path.expanduser('~/.cache/huggingface')}")
    print(f"HF_TOKEN set: {'có' if os.getenv('HF_TOKEN') else 'không (vẫn tải được, chỉ chậm hơn)'}")
    print("=" * 70)
    
    preload_embedding_model()
    preload_reranker_model()
    # preload_gliner_model()

    print("\n" + "=" * 70)
    print("XONG. Từ giờ có thể chạy:")
    print("  export HF_HUB_OFFLINE=1   # bắt buộc dùng cache, không bao giờ gọi mạng nữa")
    print("  python examples/create_kb_from_file.py")
    print("=" * 70)


if __name__ == "__main__":
    main()
