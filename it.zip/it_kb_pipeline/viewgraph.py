import networkx as nx
from common import db
from common.config import settings

def export_fact_graph_with_evidence(source_id: str, output_file: str = None, 
                                    min_confidence: float = 0.0,
                                    max_evidence_length: int = 200):
    """
    Xuất đồ thị entity-fact ra file GraphML, mỗi edge có kèm evidence sample.
    gephi
    Args:
        source_id: ID tài liệu
        output_file: Tên file đầu ra (mặc định: entity_fact_graph_{source_id}.graphml)
        min_confidence: Chỉ xuất fact có confidence >= ngưỡng
        max_evidence_length: Độ dài tối đa của evidence sample
    """
    if output_file is None:
        output_file = f"entity_fact_graph_{source_id}.graphml"

    # 1. Lấy facts
    facts = db.get_all_facts_for_source(source_id)
    # print(f"fact {facts}")
    if not facts:
        print(f"Không có fact nào cho source_id {source_id}")
        return

    if min_confidence > 0:
        facts = [f for f in facts if f.get("confidence", 0) >= min_confidence]
        if not facts:
            print(f"Không có fact nào có confidence >= {min_confidence}")
            return

    # 2. Lấy evidence cho từng fact (lấy mẫu đầu tiên)
    fact_ids = [f["id"] for f in facts]
    evidence_samples = {}
    if fact_ids:
        with db.get_conn() as conn:
            # Lấy mỗi fact một evidence (có thể lấy nhiều hơn nếu muốn)
            rows = conn.execute("""
                SELECT DISTINCT ON (fact_id) fact_id, evidence_raw 
                FROM fact_evidence 
                WHERE fact_id = ANY(%s)
                ORDER BY fact_id, confidence DESC
            """, (fact_ids,)).fetchall()
            for r in rows:
                evidence_raw = r["evidence_raw"]
                if len(evidence_raw) > max_evidence_length:
                    evidence_raw = evidence_raw[:max_evidence_length] + "..."
                evidence_samples[r["fact_id"]] = evidence_raw

    # 3. Lấy entity map
    entity_map = db.load_entity_map(source_id)
    entity_info = {e.entity_id: e for e in entity_map}
    # 4. Xây dựng đồ thị
    G = nx.DiGraph()

    # Nodes
    entity_ids_in_facts = set()
    for f in facts:
        entity_ids_in_facts.add(f["source_entity_id"])
        entity_ids_in_facts.add(f["target_entity_id"])

    for eid in entity_ids_in_facts:
        info = entity_info.get(eid)
        if info is None:
            with db.get_conn() as conn:
                row = conn.execute("SELECT label, type FROM kg_nodes WHERE id = %s", (eid,)).fetchone()
            label = row["label"] if row else eid
            etype = row["type"] if row else "unknown"
            section_count = 0
            mention_count = 0
        else:
            label = info.canonical_name
            etype = info.type
            section_count = info.section_count
            mention_count = info.mention_count

        G.add_node(eid,
                   label=label,
                   type=etype,
                   section_count=section_count,
                   mention_count=mention_count,
                   source_id=source_id)

    # Edges
    for fact in facts:
        src = fact["source_entity_id"]
        tgt = fact["target_entity_id"]
        rel = fact["relation_type"]
        conf = fact.get("confidence", 0.0)
        evidence = evidence_samples.get(fact["id"], "")

        G.add_edge(src, tgt,
                   relation=rel,
                   confidence=conf,
                   evidence_sample=evidence,
                   fact_id=fact["id"])

    # 5. Ghi file
    nx.write_graphml(G, output_file)
    print(f"Đã xuất file {output_file} với {G.number_of_nodes()} nodes và {G.number_of_edges()} edges.")
    print(f"Mỗi edge có thuộc tính 'evidence_sample' để xem bằng chứng.")


def export_atom_graph_with_evidence(
    source_id: str,
    output_file: str = None,
    min_score: float = 0.0,
    include_relations: list = None,
    exclude_relations: list = None,   # <-- thêm tham số để loại trừ
    max_evidence_length: int = 200,
    include_nodes_without_edges: bool = True   # <-- có thể giữ
):
    """
    Xuất đồ thị atom (knowledge_atoms) với các cạnh từ kg_edges ra file GraphML.
    Mặc định loại bỏ các cạnh PARENT_OF (vì chúng không tham gia PPR).
    
    Args:
        source_id: ID tài liệu
        output_file: Tên file đầu ra (mặc định: atom_graph_{source_id}.graphml)
        min_score: Chỉ xuất edge có score >= ngưỡng (nếu có score)
        include_relations: Danh sách các loại quan hệ muốn bao gồm (None = tất cả)
        exclude_relations: Danh sách các loại quan hệ muốn loại trừ (mặc định ['PARENT_OF'])
        max_evidence_length: Độ dài tối đa của evidence sample
        include_nodes_without_edges: Có bao gồm các node không có cạnh không
    """
    if output_file is None:
        output_file = f"atom_graph_{source_id}.graphml"

    # 1. Lấy tất cả atom của source_id
    atoms = db.get_atoms_by_source(source_id)
    if not atoms:
        print(f"Không có atom nào cho source_id {source_id}")
        return
    atom_ids = [a.id for a in atoms]

    # 2. Lấy tất cả edges nối giữa hai atom
    edges_data = []
    if atom_ids:
        with db.get_conn() as conn:
            rows = conn.execute("""
                SELECT source_id, target_id, relation, evidence_raw, score
                FROM kg_edges
                WHERE source_id = ANY(%s) AND target_id = ANY(%s)
            """, (atom_ids, atom_ids)).fetchall()
            edges_data = rows

    if not edges_data:
        print(f"Không có cạnh nào giữa các atom cho source_id {source_id}")
        # Vẫn có thể xuất graph chỉ có node
        edges_data = []

    # 3. Lọc theo exclude_relations (mặc định loại bỏ PARENT_OF)
    if exclude_relations is None:
        exclude_relations = ['PARENT_OF']
    # exclude_relations = []
    exclude_set = set(exclude_relations)
    edges_data = [e for e in edges_data if e["relation"] not in exclude_set]

    # 4. Lọc theo include_relations
    if include_relations is not None:
        include_set = set(include_relations)
        edges_data = [e for e in edges_data if e["relation"] in include_set]

    # 5. Lọc theo min_score (chỉ áp dụng khi score có giá trị)
    if min_score > 0:
        edges_data = [e for e in edges_data if e.get("score") is not None and e["score"] >= min_score]

    # 6. Xây dựng đồ thị NetworkX
    G = nx.DiGraph()

    # Thêm node atom với các thuộc tính, thay thế None bằng chuỗi rỗng hoặc 0
    for atom in atoms:
        label = atom.raw[:80] + "..." if len(atom.raw) > 80 else atom.raw
        # Đảm bảo tất cả giá trị đều có thể serialize sang GraphML (string, number, boolean)
        G.add_node(
            atom.id,
            label=label,
            raw=atom.raw[:500] if atom.raw else "",
            normalized=atom.normalized or "",
            element_label=atom.label.value if atom.label else "",
            section_id=atom.section_id or "",
            confidence=atom.confidence if atom.confidence is not None else 0.0,
            contradicts_flag=1 if atom.contradicts_flag else 0,   # boolean -> int
            source_id=atom.source_id or "",
            node_type="atom"
        )

    # Thêm edge
    for e in edges_data:
        src = e["source_id"]
        tgt = e["target_id"]
        rel = e["relation"]
        score = e.get("score")
        evidence = e.get("evidence_raw") or ""
        if len(evidence) > max_evidence_length:
            evidence = evidence[:max_evidence_length] + "..."

        G.add_edge(
            src, tgt,
            relation=rel,
            score=score if score is not None else 0.0,
            evidence_sample=evidence,
            edge_type="atom_atom"
        )

    # 7. Ghi file GraphML (có thể bỏ qua các node không có cạnh nếu muốn)
    if not include_nodes_without_edges and G.number_of_edges() > 0:
        # Chỉ giữ các node có ít nhất một cạnh (kết nối)
        nodes_with_edges = set()
        for u, v in G.edges():
            nodes_with_edges.add(u)
            nodes_with_edges.add(v)
        G.remove_nodes_from([n for n in G.nodes() if n not in nodes_with_edges])

    nx.write_graphml(G, output_file)
    print(f"Đã xuất file {output_file} với {G.number_of_nodes()} node atom và {G.number_of_edges()} edge.")
    print(f"(Đã loại bỏ các cạnh PARENT_OF theo yêu cầu, vì chúng không tham gia PPR.)")

if __name__ == "__main__":
    source_id = "abc1"  # Thay bằng source_id thực tế
    export_fact_graph_with_evidence(source_id, min_confidence=0.1)
    export_atom_graph_with_evidence(source_id)
