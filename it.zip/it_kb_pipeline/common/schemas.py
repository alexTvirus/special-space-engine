"""
=============================================================================
CONTRACT LAYER — every dataclass/model in this file is the INPUT or OUTPUT
of exactly one pipeline stage (A1..E). This is the file to look at if you
later want to split the pipeline into separate microservices talking over
REST/gRPC: each stage function's signature is `f(<one of these models>) ->
<another of these models>`, so the model becomes your request/response body
(REST/JSON) or your .proto message (gRPC) unchanged.

Pipeline order (each arrow = "output of left is input of right"):

  file_path ─▶ A1 ─▶ UnifiedDoc ─▶ A2 ─▶ UnifiedDoc(annotated)
        UnifiedDoc ─▶ A3 ─▶ GlobalIndex
        UnifiedDoc ─▶ A3.5 ─▶ SectionHashReport (decides which sections go to A4)
        (section text + GlobalIndex) ─▶ A4 ─▶ list[KnowledgeElement] (queued via section_jobs)
        (list[KnowledgeElement] + GlobalIndex) ─▶ A5 ─▶ MergeResult (adds cross_links, contradicts)
        list[KnowledgeElement] ─▶ B1 ─▶ list[KnowledgeAtom] (deduped + embedded)
        list[KnowledgeAtom] ─▶ B2 ─▶ B2Output (chunk_records + kg nodes/edges + wiki files)
        (everything above) ─▶ C ─▶ persisted rows in Postgres/Git (see stages/c_storage.py)
        query: str ─▶ D ─▶ RetrievalResult (fused, reranked, self-verified context)
        RetrievalResult ─▶ E ─▶ AnswerWithCitations
=============================================================================
"""
from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Optional, Literal
from uuid import uuid4

from pydantic import BaseModel, Field


# =============================================================================
# A1 — Ensemble Parser + Unified Document Object (UDO)
# =============================================================================

class ElementType(str, Enum):
    HEADING = "heading"
    PARAGRAPH = "paragraph"
    TABLE = "table"
    LIST_ITEM = "list_item"
    CODE_BLOCK = "code_block"
    FOOTNOTE = "footnote"
    SIDEBAR = "sidebar"
    IMAGE_CAPTION = "image_caption"


class BBox(BaseModel):
    page: int = 0
    top: float = 0.0
    left: float = 0.0
    bottom: float = 0.0
    right: float = 0.0


class ElementMetadata(BaseModel):
    page: Optional[int] = None
    heading_level: Optional[int] = None
    font_size: Optional[float] = None
    bbox: Optional[BBox] = None
    is_footnote: bool = False
    is_sidebar: bool = False


class DocElement(BaseModel):
    """One structural unit inside a parsed document (heading/paragraph/table/...)."""
    id: str = Field(default_factory=lambda: f"el_{uuid4().hex[:12]}")
    type: ElementType
    content_display: str          # normalized/cleaned text for showing to LLM/UI
    content_raw: str              # verbatim text as it appears in the source, used for A4 exact-match verification
    section_id: Optional[str] = None
    chapter: Optional[str] = None
    metadata: ElementMetadata = Field(default_factory=ElementMetadata)


class ParseIssue(BaseModel):
    level: Literal["INFO", "WARNING", "ERROR"]
    message: str
    detail: Optional[dict] = None


class UnifiedDoc(BaseModel):
    """Output of A1 (and the thing A2 annotates in place)."""
    source_id: str
    file_path: str
    file_type: str
    parser_used: str
    parse_confidence: float
    elements: list[DocElement] = Field(default_factory=list)
    issues: list[ParseIssue] = Field(default_factory=list)
    needs_review: bool = False


# =============================================================================
# A2 — Reading Order Verify + Cross-page Table output is UnifiedDoc (above),
# plus a standalone report if a service wants only the diff.
# =============================================================================

class ReadingOrderReport(BaseModel):
    source_id: str
    diff_ratio: float
    needs_review: bool
    issues: list[ParseIssue] = Field(default_factory=list)


# =============================================================================
# A3 — Global Index Generation
# =============================================================================

class OutlineNode(BaseModel):
    level: int
    text: str
    page: Optional[int] = None
    section_id: str
    first_sentence: Optional[str] = None


class EntityMention(BaseModel):
    entity_id: str
    canonical_name: str
    mentions: list[str] = Field(default_factory=list)
    section_ids: list[str] = Field(default_factory=list)
    # --- A4.5 additions ---
    type: str = "OTHER"           # entity type, used as a hard gate in A4.5 dedupe (never merge across types)
    section_count: int = 0        # len(section_ids) — IDF-style signal: "common_cutoff" filter in A4.5/A5
    mention_count: int = 0        # total raw mentions merged into this entity (informational)
    # --- MỚI (đề xuất #2): embedding của canonical_name, đã được A4.5 tính
    # trong dedupe_candidates() nhưng trước đây bị bỏ đi ngay sau khi dùng
    # xong cho union-find — giờ persist lại (entity_map.name_embedding, cột
    # đã có sẵn trong schema.sql nhưng chưa từng được ghi) để D's
    # _entities_from_query có thể dùng làm fallback linking khi ILIKE
    # substring match miss.
    name_embedding: Optional[list[float]] = None


class CrossReference(BaseModel):
    from_section_id: str
    to_section_id: str
    relation_hint: str   # short phrase from the LLM describing the reference


class GlobalIndex(BaseModel):
    """Output of A3. Consumed as *context* by A4 and A5."""
    source_id: str
    heading_tree: list[OutlineNode] = Field(default_factory=list)
    entity_map: list[EntityMention] = Field(default_factory=list)
    cross_references: list[CrossReference] = Field(default_factory=list)
    size_tokens: int = 0
    fits_context: bool = True

    def heading_path_for(self, section_id: str) -> str:
        """Breadcrumb string like "1. Lập trình > 1.2 Ngôn ngữ" for a given
        section_id, built by walking `heading_tree` (a flat list ordered by
        document position, disambiguated by `level`) and tracking the most
        recent heading seen at each level up to and including this section's
        own level. Used by B2 to prepend context before embedding a parent
        chunk (see b2_wiki_graph_chunking.build_chunk_records) — an embedding
        of just the raw text loses "which section this belongs to", which
        matters when near-identical wording appears in two different
        sections with different meaning.

        Returns "" if section_id isn't found (never raises) — callers should
        treat that as "no breadcrumb available", not an error.
        """
        current: dict[int, str] = {}
        for node in self.heading_tree:
            for lvl in [l for l in current if l >= node.level]:
                del current[lvl]
            current[node.level] = node.text
            if node.section_id == section_id:
                return " > ".join(current[lvl] for lvl in sorted(current))
        return ""


# =============================================================================
# A3.5 — Section-Level Hashing
# =============================================================================

class SectionHashReport(BaseModel):
    source_id: str
    new_sections: list[str] = Field(default_factory=list)
    changed_sections: list[str] = Field(default_factory=list)
    unchanged_sections: list[str] = Field(default_factory=list)

    @property
    def sections_to_process(self) -> list[str]:
        """Sections that must be (re)sent to A4 — new or changed only."""
        return self.new_sections + self.changed_sections


# =============================================================================
# A4 — Pass 1: Constraint Extraction (per-section, queued)
# =============================================================================

class ElementLabel(str, Enum):
    FACT = "FACT"
    DEFINITION = "DEFINITION"
    CONSTRAINT = "CONSTRAINT"
    EXAMPLE = "EXAMPLE"
    WARNING = "WARNING"
    OTHER = "OTHER"
    HEADING = "HEADING"   # Thêm dòng này


class ExtractedElement(BaseModel):
    """One candidate fact/definition/constraint pulled out of a section by the LLM."""
    id: str = Field(default_factory=lambda: f"kx_{uuid4().hex[:12]}")
    label: ElementLabel
    raw: str                      # must be a verbatim substring of the section text
    normalized: Optional[str] = None
    # A4.5/A4.8/A5 rely on this: raw entity mentions extracted by the SAME LLM
    # call as the element itself (no separate GLiNER/NER pass — see
    # a4_constraint_extraction.EXTRACTION_SYSTEM_PROMPT). Each item is
    # {"name": str, "type": str} — NOT yet consolidated/deduped (that's A4.5's
    # job) and has no "entity_id" yet.
    entities: list[dict] = Field(default_factory=list)


class VerificationResult(BaseModel):
    status: Literal["VERIFIED", "REJECTED", "NEEDS_REVIEW"]
    method: Optional[Literal["exact", "fuzzy", "llm_review"]] = None
    similarity: Optional[float] = None
    flag: Optional[str] = None
    # Which escalation path produced this verdict ("llm_review" /
    # "human_review"), if any — lets callers route NEEDS_REVIEW items
    # differently from a hard REJECTED instead of collapsing both into the
    # same bucket.
    review_route: Optional[str] = None


class SectionJobInput(BaseModel):
    """Input to A4 for a single job (one row popped off `section_jobs`)."""
    job_id: str
    source_id: str
    section_id: str
    section_text: str
    heading: Optional[str] = None
    llm_tier: Literal["light", "strong"] = "light"
    attempt: int = 0
    max_attempts: int = 3


class SectionExtractionResult(BaseModel):
    """Output of A4 for one section — becomes input to B1 (dedup) once verified."""
    job_id: str
    source_id: str
    section_id: str
    elements: list[ExtractedElement] = Field(default_factory=list)
    verified: list[ExtractedElement] = Field(default_factory=list)
    rejected: list[ExtractedElement] = Field(default_factory=list)
    # Elements whose VerificationResult.status was NEEDS_REVIEW — kept
    # distinct from `rejected` so the a4_human_review_enabled escalation
    # path actually has somewhere to route to, instead of being silently
    # treated as a hallucination-suspected rejection.
    needs_review: list[ExtractedElement] = Field(default_factory=list)
    confidence: float = 0.0
    outcome: Literal["DONE", "RETRY", "MANUAL_REVIEW"] = "DONE"
    intra_links: list[CrossLink] = Field(default_factory=list)


# =============================================================================
# A5 — Pass 2: Global Merge
# =============================================================================

class CrossLink(BaseModel):
    from_id: str
    to_id: str
    relation: Literal["DEFINES", "EXTENDS", "CONTRADICTS", "RELATED_TO"]
    evidence_raw: str


class MergeResult(BaseModel):
    """Output of A5. Input to B1 together with the flat element list."""
    source_id: str
    cross_links: list[CrossLink] = Field(default_factory=list)
    resolved_entities: list[EntityMention] = Field(default_factory=list)
    community_summaries: list[str] = Field(default_factory=list)


# =============================================================================
# B1 — Dedup 3 tầng
# =============================================================================

class KnowledgeAtom(BaseModel):
    """The canonical, deduped, embedded unit of knowledge. Row of `knowledge_atoms`."""
    id: str
    source_id: str
    section_id: str
    chapter: Optional[str] = None
    page_start: Optional[int] = None
    label: ElementLabel
    raw: str
    normalized: Optional[str] = None
    confidence: float = 0.0
    contradicts_flag: bool = False
    embedding: Optional[list[float]] = None
    # Copied verbatim from ExtractedElement.entities by B1 (dedup_and_store).
    # Initially each dict is {"name":..., "type":...}; A4.5 (entity
    # consolidation) mutates these in place to add a resolved "entity_id" key
    # once the global entity_map for the source_id has been built — B2's
    # MENTIONS edge builder reads ent["entity_id"] and requires this to have
    # already happened.
    entities: list[dict] = Field(default_factory=list)


class MergeDecision(BaseModel):
    action: Literal["AUTO_MERGE", "FLAG_REVIEW", "NO_MERGE"]
    confidence: float = 0.0


class DedupReport(BaseModel):
    source_id: str
    kept: list[KnowledgeAtom] = Field(default_factory=list)
    dropped_ids: list[str] = Field(default_factory=list)
    merges: list[dict] = Field(default_factory=list)


# =============================================================================
# B2 — LLM Wiki + Knowledge Graph + Late Chunking
# =============================================================================

class ChunkRecord(BaseModel):
    id: str
    type: Literal["parent", "child", "community"]
    content: str
    embedding: Optional[list[float]] = None
    parent_id: Optional[str] = None
    children: list[str] = Field(default_factory=list)
    # For type="community": the ids of every atom/entity node in the
    # community (what got summarized). Reuses `children` so no new column is
    # needed — `member_node_ids` is just a clearer name for callers in B2.5.
    metadata: dict = Field(default_factory=dict)

    @property
    def member_node_ids(self) -> list[str]:
        return self.children


class KGNode(BaseModel):
    id: str
    label: str
    type: Literal["entity", "atom", "type"]
    source_id: Optional[str] = None  # scopes an entity/atom node to one document, for per-source community detection
    # Giai đoạn 1: tách graph "suy luận" (entity/type) khỏi "cấu trúc" (atom)
    tier: Literal["reasoning", "structural"] = "structural"

class KGEdge(BaseModel):
    source_id: str
    target_id: str
    relation: Literal["MENTIONS", "SIMILAR_TO", "DEFINES", "EXTENDS", "CONTRADICTS", "RELATED_TO","SAME_SECTION","PARENT_OF","INSTANCE_OF" ]
    # Only meaningful for the 4 LLM-confirmed relations (DEFINES/EXTENDS/
    # CONTRADICTS/RELATED_TO), which must be verifiable by substring-match
    # against the source text. MENTIONS/SIMILAR_TO are purely structural
    # (no text to quote), so this stays None for them — see `score` instead.
    evidence_raw: Optional[str] = None
    # Only meaningful for MENTIONS (always 1.0) and SIMILAR_TO (cosine score
    # from A4.8's ANN search). Kept as a separate field on purpose: cramming
    # a numeric score into evidence_raw would break the "evidence_raw is a
    # verbatim substring" contract that other code relies on for verification.
    score: Optional[float] = None
    tier: Literal["reasoning", "structural"] = "structural"

# Giai đoạn 0 — Fact layer
class Fact(BaseModel):
    """One entity-entity relation with a specific relation_type — row of
    `kg_facts`. Evidence is a full many-to-many list (FactEvidence), fixing
    the "only first evidence_raw kept" bug in build_kg's entity_entity_agg."""
    id: str
    source_id: Optional[str] = None
    source_entity_id: str
    target_entity_id: str
    relation_type: str
    confidence: float = 0.0

class FactEvidence(BaseModel):
    fact_id: str
    atom_id: str
    evidence_raw: str
    confidence: float = 1.0    

class WikiPage(BaseModel):
    section_id: str
    title: str
    markdown: str


class B2Output(BaseModel):
    """Output of B2. This is what stage C persists (chunk_records, kg_nodes/edges, wiki files)."""
    source_id: str
    chunk_records: list[ChunkRecord] = Field(default_factory=list)
    kg_nodes: list[KGNode] = Field(default_factory=list)
    kg_edges: list[KGEdge] = Field(default_factory=list)
    wiki_pages: list[WikiPage] = Field(default_factory=list)
    facts: list[Fact] = Field(default_factory=list)
    fact_evidence: list[FactEvidence] = Field(default_factory=list)


# =============================================================================
# C — Storage Layer (batch monitoring model; persistence itself is in db.py)
# =============================================================================

class BatchRun(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    started_at: datetime = Field(default_factory=datetime.utcnow)
    finished_at: Optional[datetime] = None
    total_documents: int = 0
    total_sections: int = 0
    failed_sections: int = 0
    manual_review_sections: int = 0


# =============================================================================
# D — Retrieval Engine (Online)
# =============================================================================

class RetrievalQuery(BaseModel):
    query_text: str
    top_k_final: int = 10
    top_k_per_source: int = 40
    # Optional: scope coverage_check()'s corpus-wide fallback (and community
    # search) to one document. Previously read via
    # getattr(query, "source_id", None) even though the field never existed
    # on the model — now it actually does.
    source_id: Optional[str] = None


class RetrievedCandidate(BaseModel):
    atom_id: str
    raw: str
    normalized: Optional[str] = None
    source: Literal["dense", "bm25", "graph", "community" ,"entity_path_hit"] = "dense"
    rank: int = 0
    type: str = None
    relevance_score: float = 0.0
    confidence: float = 0.0
    contradicts_flag: bool = False
    location: Optional[str] = None
    # --- provenance (D seed-then-expand) ---
    # "direct_match": surfaced by dense/bm25/graph-entity search against the
    # query itself. "graph_expansion": pulled in only because it has an edge
    # to a seed atom that matched directly — stage E's prompt needs to know
    # this distinction (see e_query_output.ANSWER_SYSTEM_PROMPT_ADDITION).
    origin: Literal["direct_match", "section_expansion", "graph_expansion"] = "direct_match"
    relation: Optional[str] = None       # KGEdge.relation that pulled this candidate in, if origin=graph_expansion
    linked_from: Optional[str] = None    # atom_id of the seed that pulled this candidate in
    section_id: Optional[str] = None   # <-- thêm
    ppr_score: Optional[float] = None     # MỚI — điểm PPR thô
    hop_distance: Optional[int] = None    # MỚI — chỉ để debug
    anchor_similarity: Optional[float] = None
    anchor_atom_id: Optional[str] = None  # atom_id of the specific seed this was scored against
    query_similarity: float = 0.0
    ppr_norm: Optional[float] = None 



class EntityPathHop(BaseModel):
    """One hop of an entity-fact chain found by entity_path_search
    (Entity_A --RELATION--> Entity_B), kept as its own structure INSTEAD of
    being flattened straight into individual RetrievedCandidate rows (which
    is what used to happen and lost the chain/ordering entirely). Distinct
    from `candidate_edges` on purpose: candidate_edges is generic ATOM-ATOM
    relations (DEFINES/EXTENDS/CONTRADICTS/RELATED_TO/...) from kg_edges,
    while this is the domain-specific ENTITY-ENTITY relation chain from
    kg_facts (CAUSES/TRIGGERS/...) — mixing the two concepts into one field
    would make stage E unable to tell "generic atom relation" from "the
    specific reasoning chain the Fact layer was built to provide"."""
    source_entity_id: str = ""
    source_label: str
    relation_type: str
    target_entity_id: str = ""
    target_label: str
    evidence_atom_ids: list[str] = Field(default_factory=list)


class RetrievalResult(BaseModel):
    """Output of D. Input to E."""
    query_text: str
    candidates: list[RetrievedCandidate] = Field(default_factory=list)
    insufficient_context: bool = False
    # Anti-hallucination metadata (see stages/d_retrieval.py::coverage_check)
    coverage_ratio: float = 1.0
    uncovered_terms: list[str] = Field(default_factory=list)
    top_parents: list[dict] = Field(default_factory=list)  # list of {"id": ..., "content": ..., "score": ...}
    suggestions: list[RetrievedCandidate] = Field(default_factory=list)
    # --- MỚI: danh sách các cạnh giữa các candidate (mỗi cạnh là dict)
    candidate_edges: list[dict] = Field(default_factory=list)
    # --- MỚI (đề xuất #1): chuỗi entity-fact (Entity_A --CAUSES--> Entity_B
    # --TRIGGERS--> Entity_C) mà entity_path_search tìm được, giữ nguyên cấu
    # trúc path thay vì để bị "phẳng hóa" thành candidates rời rạc — xem
    # stages/e_query_output.py::build_answer_json cho cách nó được đưa vào
    # prompt sinh câu trả lời.
    entity_paths: list[EntityPathHop] = Field(default_factory=list)
    # --- MỚI (đề xuất #8/#9): tín hiệu "chain suy luận nối các seed entity
    # của câu hỏi có bị đứt giữa đường hay không" — KHÁC coverage_ratio
    # (term-presence trên toàn pool, không biết gì về thứ tự/liên kết).
    # None khi entity_path_search không tìm được path tuyến tính nào giữa
    # 2 seed entity nào đó (single-hop, <2 seed, hoặc không path) — self_verify
    # phải coi None là "không áp dụng", không phải "đã đứt".
    chain_coverage: Optional[float] = None
    # --- MỚI (đề xuất #14): key terms tồn tại trong corpus nhưng KHÔNG được
    # retrieval surface (retrieval recall gap, khác "truly uncovered" —
    # xem stages/d_retrieval.py::resolve_uncovered_terms). Trước đây được
    # compute_coverage() tính ra rồi bỏ phí ngay trong retrieve() — không
    # field nào trên RetrievalResult giữ lại, nên caller (stage E) không có
    # cách nào tự động dùng lại để thử retrieve() bổ sung khi
    # insufficient_context=True. Xem stages/e_query_output.py::answer_query
    # / _retry_with_retrieval_gap cho nơi field này được dùng.
    retrieval_gap_terms: list[str] = Field(default_factory=list)


# =============================================================================
# E — Query Output + Citation Chain
# =============================================================================

class Citation(BaseModel):
    atom_id: str
    raw: str
    location: str

class Suggestion(BaseModel):
    chunk_id: str
    type: Literal["parent", "child"]
    content_preview: str  # trích đoạn ngắn (khoảng 100-200 ký tự)
    parent_id: Optional[str] = None  # nếu là child, hiển thị parent
    children_count: Optional[int] = None  # nếu là parent, số lượng child

class AnswerWithCitations(BaseModel):
    """Final output of the whole pipeline for one user query."""
    answer: str
    citations: list[Citation] = Field(default_factory=list)
    insufficient_context: bool = False
    # Topics/entities from the question that the knowledge base does not
    # cover at all (surfaced explicitly instead of being silently filled in
    # by the model's own background knowledge).
    uncovered_topics: list[str] = Field(default_factory=list)
    # Sentences that were generated with a citation but failed the post-hoc
    # grounding check (lexical overlap and/or LLM entailment check) and were
    # therefore stripped from `answer`. Kept for debugging/observability.
    stripped_unsupported_sentences: list[str] = Field(default_factory=list)
    suggestions: list[Suggestion] = Field(default_factory=list)  # <-- thêm dòng này
    # candidate_suggestions: list[RetrievedCandidate] = Field(default_factory=list)
