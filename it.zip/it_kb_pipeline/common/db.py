"""
Storage Layer (C) — all persistence goes through this module.

Design-doc mapping:
  - Document/vector/graph/queue all live in Postgres (see db/schema.sql)
  - `pgvector` for dense search (D.1), `tsvector`/`tsquery` for BM25-like
    search (D.2), `WITH RECURSIVE` for graph traversal (D.3 / B2.2)
  - `section_jobs` + `FOR UPDATE SKIP LOCKED` for the queue (A4.5)
  - `batch_runs` for monitoring (C.3)

If you split this into its own "storage-service" later: every method here
takes/returns the Pydantic models from common/schemas.py, so wrap each
method 1:1 as a REST or gRPC endpoint and nothing else in the codebase needs
to change — callers only ever import `db` from this module.
"""
from __future__ import annotations

import json
from contextlib import contextmanager
from typing import Iterator, Optional

import psycopg
from psycopg.rows import dict_row

from .config import settings

try:
    from pgvector.psycopg import register_vector
except ImportError:  # pgvector python package not installed — embeddings will
    register_vector = None  # fail to adapt; install `pgvector` to fix
from .schemas import (
    KnowledgeAtom, KGNode, KGEdge, ChunkRecord, SectionJobInput,
    RetrievedCandidate, BatchRun, ElementLabel, EntityMention, Fact, FactEvidence,
)


@contextmanager
def get_conn() -> Iterator[psycopg.Connection]:
    conn = psycopg.connect(
        settings.database_url,
        row_factory=dict_row
    )
    if register_vector is not None:
        register_vector(conn)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_schema(schema_path: str = "db/schema.sql") -> None:
    with open(schema_path, "r", encoding="utf-8") as f:
        sql = f.read()
    with get_conn() as conn:
        conn.execute(sql)


# =============================================================================
# A3.5 — section hashes
# =============================================================================

def get_section_hash(source_id: str, section_id: str) -> Optional[str]:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT content_hash FROM section_hashes WHERE source_id=%s AND section_id=%s",
            (source_id, section_id),
        ).fetchone()
        return row["content_hash"] if row else None


def upsert_section_hash(source_id: str, section_id: str, content_hash: str) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO section_hashes (source_id, section_id, content_hash)
               VALUES (%s, %s, %s)
               ON CONFLICT (source_id, section_id)
               DO UPDATE SET content_hash = EXCLUDED.content_hash, updated_at = now()""",
            (source_id, section_id, content_hash),
        )


# =============================================================================
# A4 — job queue (Postgres replaces Celery + Redis)
# =============================================================================

def enqueue_section_job(batch_id: str, source_id: str, section_id: str,
                         section_text: str,heading: str = "") -> str:
    with get_conn() as conn:
        row = conn.execute(
            """INSERT INTO section_jobs (batch_id, source_id, section_id, section_text,heading)
               VALUES (%s, %s, %s, %s, %s) RETURNING id""",
            (batch_id, source_id, section_id, section_text,heading),
            ).fetchone()
        return str(row["id"])


def claim_next_job() -> Optional[SectionJobInput]:
    """Atomically pop the next pending job. Safe for N concurrent workers."""
    with get_conn() as conn:
        row = conn.execute(
            """
            SELECT * FROM section_jobs
            WHERE status = 'pending' AND next_run_at <= now()
            ORDER BY next_run_at
            FOR UPDATE SKIP LOCKED
            LIMIT 1
            """
        ).fetchone()
        if row is None:
            return None
        conn.execute("UPDATE section_jobs SET status='processing', updated_at=now() WHERE id=%s",
                     (row["id"],))
        return SectionJobInput(
            job_id=str(row["id"]), source_id=row["source_id"], section_id=row["section_id"],
            section_text=row["section_text"], heading=row.get("heading"),  # <--- THÊM
            llm_tier=row["llm_tier"], attempt=row["attempt"], max_attempts=row["max_attempts"],
        )


def mark_job_done(job_id: str) -> None:
    with get_conn() as conn:
        conn.execute("UPDATE section_jobs SET status='done', updated_at=now() WHERE id=%s", (job_id,))


def mark_job_retry(job_id: str, attempt: int, llm_tier: str, backoff_seconds: int) -> None:
    with get_conn() as conn:
        conn.execute(
            """UPDATE section_jobs
               SET status='pending', attempt=%s, llm_tier=%s,
                   next_run_at = now() + (%s || ' seconds')::interval, updated_at=now()
               WHERE id=%s""",
            (attempt, llm_tier, backoff_seconds, job_id),
        )


def mark_job_manual_review(job_id: str, error: str = "") -> None:
    with get_conn() as conn:
        conn.execute(
            "UPDATE section_jobs SET status='manual_review', last_error=%s, updated_at=now() WHERE id=%s",
            (error, job_id),
        )


# =============================================================================
# B1/B2 — knowledge atoms (dedup target, vector + fts columns)
# =============================================================================

def upsert_knowledge_atom(atom: KnowledgeAtom) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO knowledge_atoms
                 (id, source_id, section_id, chapter, page_start, label, raw,
                  normalized, confidence, contradicts_flag, embedding, entities)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
               ON CONFLICT (id) DO UPDATE SET
                 normalized=EXCLUDED.normalized, confidence=EXCLUDED.confidence,
                 contradicts_flag=EXCLUDED.contradicts_flag, embedding=EXCLUDED.embedding,
                 entities=EXCLUDED.entities""",
            (atom.id, atom.source_id, atom.section_id, atom.chapter, atom.page_start,
             atom.label.value, atom.raw, atom.normalized, atom.confidence,
             atom.contradicts_flag, atom.embedding, json.dumps(atom.entities)),
        )


def update_atom_entities(atom_id: str, entities: list[dict]) -> None:
    """A4.5 calls this after resolving raw {"name","type"} entity mentions to
    consolidated entity_ids, so B2's MENTIONS edge builder can read
    ent["entity_id"] straight off the persisted atom."""
    with get_conn() as conn:
        conn.execute(
            "UPDATE knowledge_atoms SET entities=%s WHERE id=%s",
            (json.dumps(entities), atom_id),
        )


def find_similar_atoms(embedding: list[float], threshold: float, label: str | None = None,
                        limit: int = 10) -> list[dict]:
    """B1 tầng 2 — pgvector cosine similarity search."""
    with get_conn() as conn:
        if label is None:
            sql = """
                SELECT id, raw, label, 1 - (embedding <=> %(e)s::vector) AS similarity
                FROM knowledge_atoms
                WHERE 1 - (embedding <=> %(e)s::vector) > %(t)s
                ORDER BY similarity DESC LIMIT %(l)s
            """
            params = {"e": embedding, "t": threshold, "l": limit}
        else:
            sql = """SELECT id, raw, label, 1 - (embedding <=> %(e)s::vector) AS similarity
               FROM knowledge_atoms
               WHERE 1 - (embedding <=> %(e)s::vector) > %(t)s
                 AND (%(label)s::text IS NULL OR label = %(label)s::text)
               ORDER BY similarity DESC LIMIT %(l)s"""
            params = {"e": embedding, "t": threshold, "label": label, "l": limit}

        rows = conn.execute(sql, params).fetchall()
        return rows


# =============================================================================
# A4.8 — Vector Candidate Pre-filter (ANN search, SIMILAR_TO edges)
# =============================================================================

def ann_search_atoms(embedding: list[float], top_k: int, exclude_section: str,
                      source_id: Optional[str] = None) -> list[dict]:
    """ANN nearest-neighbor search over knowledge_atoms.embedding (uses the
    hnsw index already defined on that column — see db/schema.sql), excluding
    the atom's own section (A4.8 specifically wants cross-section candidates,
    same-section relations are already covered by simple adjacency/B2
    chunking). Scoped to `source_id` when given — cross-document ANN hits are
    rarely a meaningful "same document, different section" relation and just
    add noise/cost to A5's candidate_pairs.
    """
    with get_conn() as conn:
        if source_id is None:
            sql = """SELECT id, section_id, raw, 1 - (embedding <=> %(e)s::vector) AS score
                     FROM knowledge_atoms
                     WHERE section_id != %(sec)s
                     ORDER BY embedding <=> %(e)s::vector LIMIT %(k)s"""
            params = {"e": embedding, "sec": exclude_section, "k": top_k}
        else:
            sql = """SELECT id, section_id, raw, 1 - (embedding <=> %(e)s::vector) AS score
                     FROM knowledge_atoms
                     WHERE section_id != %(sec)s AND source_id = %(src)s
                     ORDER BY embedding <=> %(e)s::vector LIMIT %(k)s"""
            params = {"e": embedding, "sec": exclude_section, "src": source_id, "k": top_k}
        return conn.execute(sql, params).fetchall()


def upsert_similarity_edge(source_id: str, target_id: str, score: float) -> None:
    """Writes a SIMILAR_TO kg_edge directly — ready for retrieval (D's
    graph_search) immediately, with NO LLM call involved. Requires both
    endpoint kg_nodes to already exist (FK constraint); B2 upserts atom nodes
    before this runs, and A4.8 only ever links atom<->atom, so this is safe
    as long as A4.8 runs after each atom's KGNode has been upserted at least
    once — see create_kb_from_file.py orchestration."""
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO kg_edges (source_id, target_id, relation, score)
               VALUES (%s, %s, 'SIMILAR_TO', %s)
               ON CONFLICT (source_id, target_id, relation) DO UPDATE SET score = EXCLUDED.score""",
            (source_id, target_id, score),
        )


def load_similarity_edges(atom_ids: list[str]) -> list[KGEdge]:
    """SIMILAR_TO edges already created by A4.8, touching any of `atom_ids` —
    used by B2.build_kg to fold them into the same edge list as MENTIONS and
    the A5 cross_links, instead of regenerating them."""
    if not atom_ids:
        return []
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT source_id, target_id, relation, score FROM kg_edges
               WHERE relation = 'SIMILAR_TO' AND (source_id = ANY(%(ids)s) OR target_id = ANY(%(ids)s))""",
            {"ids": atom_ids},
        ).fetchall()
        return [KGEdge(source_id=r["source_id"], target_id=r["target_id"],
                        relation="SIMILAR_TO", score=r["score"]) for r in rows]


# =============================================================================
# A4.5 — persisted, consolidated entity map
# =============================================================================

def save_entity_map(source_id: str, entities: list[EntityMention]) -> None:
    """BUG FIX: this used to be a blind overwrite (ON CONFLICT DO UPDATE SET
    section_ids=EXCLUDED.section_ids, ...). A4.5 is only ever called with
    `new_atoms` (new/changed sections) on an incremental update — it has no
    visibility into which OTHER, unchanged sections already mention the same
    entity. Since `entity_id` is deterministic from (name, source_id), an
    entity that appears in both an unchanged section AND a freshly
    reprocessed section computes the SAME entity_id, and the blind overwrite
    silently discarded the unchanged section's contribution to
    section_ids/section_count/mention_count every time. That corrupts the
    IDF-style `section_count` signal A5's build_candidate_pairs relies on
    (design-doc §5/§6) — a genuinely common entity could get miscounted as
    rare (or vice versa) purely as an artifact of incremental update timing.

    Fix: merge additively. `create_kb_from_file.py` strips the changed
    sections' stale contribution first (see
    strip_section_ids_from_entity_map), so what's left in the DB row at this
    point only reflects UNCHANGED sections — safe to union with the freshly
    computed section_ids rather than replace.
    """
    with get_conn() as conn:
        for e in entities:
            existing = conn.execute(
                "SELECT section_ids, mention_count FROM entity_map WHERE entity_id=%s",
                (e.entity_id,),
            ).fetchone()
            if existing:
                merged_section_ids = sorted(set(existing["section_ids"] or []) | set(e.section_ids))
                merged_mention_count = int(existing["mention_count"] or 0) + e.mention_count
            else:
                merged_section_ids = sorted(set(e.section_ids))
                merged_mention_count = e.mention_count
            conn.execute(
                """INSERT INTO entity_map
                     (entity_id, source_id, canonical_name, type, section_ids, section_count, mention_count, name_embedding)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
                   ON CONFLICT (entity_id) DO UPDATE SET
                     canonical_name=EXCLUDED.canonical_name, type=EXCLUDED.type,
                     section_ids=EXCLUDED.section_ids, section_count=EXCLUDED.section_count,
                     mention_count=EXCLUDED.mention_count,
                     -- Only overwrite name_embedding when this write actually has one — an
                     -- incremental update that recomputes a row without re-running the embed
                     -- call (e.g. embed() failed, see a4_5's graceful degrade) should not wipe
                     -- out a previously-stored embedding.
                     name_embedding=COALESCE(EXCLUDED.name_embedding, entity_map.name_embedding),
                     updated_at=now()""",
                (e.entity_id, source_id, e.canonical_name, e.type,
                 json.dumps(merged_section_ids), len(merged_section_ids), merged_mention_count,
                 e.name_embedding),
            )


def load_entity_map(source_id: str) -> list[EntityMention]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM entity_map WHERE source_id=%s", (source_id,)
        ).fetchall()
        def _as_list(v):
            return v.to_list() if hasattr(v, "to_list") else v
        return [
            EntityMention(
                entity_id=r["entity_id"], canonical_name=r["canonical_name"], type=r["type"],
                section_ids=r["section_ids"] or [], section_count=r["section_count"] or 0,
                mention_count=r["mention_count"] or 0,
                name_embedding=_as_list(r.get("name_embedding")),
            )
            for r in rows
        ]


def strip_section_ids_from_entity_map(source_id: str, section_ids: list[str]) -> None:
    """Incremental update step 2 (design-doc mục 6), called BEFORE A4.5
    reconsolidates the freshly re-extracted atoms of `section_ids`
    (new/changed sections) — removes those section_ids from every existing
    entity_map row's `section_ids` array, and deletes the row entirely if
    that empties it out. This is what makes save_entity_map's additive merge
    correct: without stripping the stale (pre-edit) section references
    first, unioning the newly-extracted section_ids back in would just
    re-add them even if the entity is no longer actually mentioned in the
    new version of that section's text.

    BUG FIX (renamed from delete_entity_mentions_for_sections): the previous
    implementation used `DELETE ... WHERE NOT (section_ids ?| %s)`, which
    deletes rows that have NO overlap with `section_ids` — i.e. entities
    UNRELATED to the sections being updated — the exact opposite of the
    intended "strip stale references for the sections being updated". It was
    never wired into create_kb_from_file.py, so this bug never fired in
    practice, but it would have silently wiped unrelated entity_map rows the
    moment anything called it.
    """
    if not section_ids:
        return
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT entity_id, section_ids FROM entity_map WHERE source_id=%s AND section_ids ?| %s",
            (source_id, list(section_ids)),
        ).fetchall()
        stale = set(section_ids)
        for r in rows:
            remaining = [s for s in (r["section_ids"] or []) if s not in stale]
            if remaining:
                conn.execute(
                    "UPDATE entity_map SET section_ids=%s, section_count=%s, updated_at=now() WHERE entity_id=%s",
                    (json.dumps(remaining), len(remaining), r["entity_id"]),
                )
            else:
                conn.execute("DELETE FROM entity_map WHERE entity_id=%s", (r["entity_id"],))


# =============================================================================
# B2.5 — community membership (Louvain partition + lazy summary)
# =============================================================================

def get_nodes_edges_for_source(source_id: str, tier: Optional[str] = None) -> tuple[list[dict], list[dict]]:
    """All kg_nodes/kg_edges belonging to one document — input to B2.5's
    Louvain partitioning. An edge counts as "belonging" if EITHER endpoint's
    node is scoped to this source_id (kg_nodes.source_id), which covers
    atom<->atom and atom<->entity edges without needing a source_id column on
    kg_edges itself.

    `tier` (MỚI — đề xuất #4, tùy chọn, mặc định None = hành vi cũ không
    đổi): khi truyền "reasoning" hoặc "structural", chỉ trả về node/edge có
    đúng tier đó (cột đã có sẵn trên kg_nodes/kg_edges, ghi đúng từ A4.5/A5/
    B2, nhưng trước đây không kênh nào lọc theo nó khi đọc). Dùng để chạy
    graph_search_ppr trên graph "sạch" (chỉ entity-entity reasoning) khi seed
    là entity node, tách biệt khỏi graph atom+entity hỗn hợp mặc định — xem
    stages/d_retrieval.py::graph_search_ppr. KHÔNG có caller nào hiện tại
    truyền tier khác None; đổi default cần A/B test trước (xem báo cáo cải
    tiến kèm theo, mục 4)."""
    with get_conn() as conn:
        node_sql = "SELECT id, label, type FROM kg_nodes WHERE source_id=%(src)s"
        node_params = {"src": source_id}
        if tier is not None:
            node_sql += " AND tier = %(tier)s"
            node_params["tier"] = tier
        nodes = conn.execute(node_sql, node_params).fetchall()

        edge_sql = """SELECT e.source_id, e.target_id, e.relation, e.score
               FROM kg_edges e
               JOIN kg_nodes n1 ON e.source_id = n1.id
               JOIN kg_nodes n2 ON e.target_id = n2.id
               WHERE (n1.source_id = %(src)s OR n2.source_id = %(src)s)"""
        edge_params = {"src": source_id}
        if tier is not None:
            edge_sql += " AND e.tier = %(tier)s"
            edge_params["tier"] = tier
        edges = conn.execute(edge_sql, edge_params).fetchall()
        return nodes, edges


def load_community_membership(source_id: str) -> dict[str, list[str]]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT community_id, member_ids FROM community_membership WHERE source_id=%s",
            (source_id,),
        ).fetchall()
        return {r["community_id"]: (r["member_ids"] or []) for r in rows}


def save_community_membership(source_id: str, community_id: str, member_ids: list[str]) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO community_membership (source_id, community_id, member_ids)
               VALUES (%s,%s,%s)
               ON CONFLICT (source_id, community_id)
               DO UPDATE SET member_ids=EXCLUDED.member_ids, updated_at=now()""",
            (source_id, community_id, json.dumps(member_ids)),
        )


# =============================================================================
# Incremental update (design doc mục 6) — cleanup for changed/new sections
# =============================================================================

def get_atom_ids_for_sections(source_id: str, section_ids: list[str]) -> list[str]:
    if not section_ids:
        return []
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id FROM knowledge_atoms WHERE source_id=%s AND section_id = ANY(%s)",
            (source_id, section_ids),
        ).fetchall()
        return [r["id"] for r in rows]


def delete_kg_edges_touching_atoms(atom_ids: list[str]) -> None:
    """Removes MENTIONS/SIMILAR_TO/cross_link edges that reference any of
    `atom_ids` on either end — called before re-processing a changed section
    so stale edges don't linger alongside the freshly regenerated ones."""
    if not atom_ids:
        return
    with get_conn() as conn:
        conn.execute(
            "DELETE FROM kg_edges WHERE source_id = ANY(%s) OR target_id = ANY(%s)",
            (atom_ids, atom_ids),
        )


def delete_knowledge_atoms(atom_ids: list[str]) -> None:
    if not atom_ids:
        return
    with get_conn() as conn:
        conn.execute("DELETE FROM knowledge_atoms WHERE id = ANY(%s)", (atom_ids,))
        conn.execute("DELETE FROM kg_nodes WHERE id = ANY(%s)", (atom_ids,))


def delete_chunk_records_for_sections(source_id: str, section_ids: list[str]) -> None:
    """Deletes the parent chunk_record for each section_id (id format
    'parent_{section_id}', see B2.build_chunk_records) plus all its children,
    so a re-ingested/changed section doesn't leave a stale parent embedding
    alongside the new one."""
    if not section_ids:
        return
    parent_ids = [f"parent_{sid}" for sid in section_ids]
    with get_conn() as conn:
        conn.execute("DELETE FROM chunk_records WHERE parent_id = ANY(%s)", (parent_ids,))
        conn.execute("DELETE FROM chunk_records WHERE id = ANY(%s)", (parent_ids,))


# =============================================================================
# B2 — chunk records, knowledge graph
# =============================================================================

def upsert_chunk_record(rec: ChunkRecord) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO chunk_records (id, type, content, parent_id, embedding, metadata, children)
               VALUES (%s,%s,%s,%s,%s,%s,%s)
               ON CONFLICT (id) DO UPDATE SET content=EXCLUDED.content, embedding=EXCLUDED.embedding,
                 metadata=EXCLUDED.metadata, children=EXCLUDED.children""",
            (rec.id, rec.type, rec.content, rec.parent_id, rec.embedding,
             json.dumps(rec.metadata), json.dumps(rec.children)),
        )


def upsert_kg_node(node: KGNode) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO kg_nodes (id, label, type, source_id, tier) VALUES (%s,%s,%s,%s,%s)
               ON CONFLICT (id) DO UPDATE SET label=EXCLUDED.label,
                 source_id=COALESCE(EXCLUDED.source_id, kg_nodes.source_id),
                 tier=EXCLUDED.tier""",
            (node.id, node.label, node.type, node.source_id, node.tier),
        )


def insert_kg_edge(edge: KGEdge) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO kg_edges (source_id, target_id, relation, evidence_raw, score, tier)
               VALUES (%s,%s,%s,%s,%s,%s)
               ON CONFLICT (source_id, target_id, relation)
               DO UPDATE SET evidence_raw=EXCLUDED.evidence_raw, score=EXCLUDED.score,
                 tier=EXCLUDED.tier""",
            (edge.source_id, edge.target_id, edge.relation, edge.evidence_raw, edge.score, edge.tier),
        )


def graph_traverse(start_node: str, max_depth: int = 2) -> list[dict]:
    """B2.2 / D.3 — multi-hop traversal, replaces Neo4j (mã giả #13b)."""
    with get_conn() as conn:
        rows = conn.execute(
            """
            WITH RECURSIVE traverse(id, depth, path) AS (
                SELECT id, 0, ARRAY[id] FROM kg_nodes WHERE id = %(start)s
                UNION ALL
                SELECT e.target_id, t.depth + 1, t.path || e.target_id
                FROM kg_edges e
                JOIN traverse t ON e.source_id = t.id
                WHERE t.depth < %(depth)s AND NOT e.target_id = ANY(t.path)
            )
            SELECT DISTINCT id, depth FROM traverse
            """,
            {"start": start_node, "depth": max_depth},
        ).fetchall()
        return rows


def graph_traverse_multi(seed_ids: list[str], max_depth: int = 2, source_id: Optional[str] = None,
                          tier: Optional[str] = None) -> list[dict]:
    """Multi-seed BFS (D's seed-then-expand graph_search) that ALSO tracks
    which seed pulled a node in and the relation of the edge that reached it
    last — graph_traverse() (single-seed, id/depth only) doesn't carry enough
    information for soft_score()'s edge_confidence lookup or
    RetrievedCandidate.linked_from.

    Returns rows of {id, depth, relation, seed_id}, depth >= 1 only (the
    seeds themselves are excluded — the caller already has them). When
    multiple paths reach the same node, DISTINCT ON keeps the shortest one.

    FIX (confirmed real gap — this is the BFS FALLBACK path used when
    graph_search_ppr can't run; PPR's own cost controls, e.g.
    _bounded_graph_for_ppr's ego-radius cap, don't apply here at all since
    this is a separate raw SQL recursive CTE): previously had NO limit on
    how many out-edges were followed from each node at each hop. A single
    hub node reached at hop 1 (e.g. a common entity with hundreds of
    MENTIONS edges) could expand to hundreds/thousands of nodes by hop 2-3
    before max_depth even mattered — cost was effectively bounded by the
    graph's real degree distribution, not by anything this function
    controlled.

    Fix: `capped_edges` ranks each node's out-edges (via ROW_NUMBER, computed
    in a plain non-recursive CTE — Postgres does not allow window functions
    inside a recursive CTE's recursive term itself, so the ranking has to
    happen in a separate CTE the recursive term then joins against) and
    keeps only the top `settings.d_bfs_fanout_cap_per_hop` per node,
    ordered to prefer the 4 LLM-confirmed relations + SIMILAR_TO over
    MENTIONS — MENTIONS is the purely-structural "shares an entity" edge and
    is the most likely to fire in bulk on a generic hub entity, so when a
    node has more out-edges than the cap, MENTIONS edges are the first to be
    dropped rather than a semantically-confirmed relation.

    `tier` (MỚI — đề xuất #4, tùy chọn, mặc định None = hành vi cũ không
    đổi): lọc `capped_edges` theo kg_edges.tier ("reasoning" | "structural")
    khi được truyền — cho phép caller seed bằng entity node và traversal
    CHỈ đi qua cạnh entity-entity "suy luận", không lẫn MENTIONS/SAME_SECTION/
    PARENT_OF (structural). Không caller hiện tại nào truyền tier khác None;
    xem báo cáo cải tiến kèm theo, mục 4, cho lý do (cần A/B test trước khi
    đổi default ở graph_search()).
    """
    if not seed_ids:
        return []
    with get_conn() as conn:
        where = "AND n.source_id = %(source_id)s" if source_id else ""
        tier_filter = "AND e.tier = %(tier)s" if tier is not None else ""
        rows = conn.execute(
            f"""
            WITH RECURSIVE ranked_edges AS (
                SELECT e.source_id, e.target_id, e.relation,
                       ROW_NUMBER() OVER (
                           PARTITION BY e.source_id
                           ORDER BY (CASE WHEN e.relation = 'MENTIONS' THEN 1 ELSE 0 END),
                                    e.score DESC NULLS LAST
                       ) AS rn
                FROM kg_edges e
                JOIN kg_nodes tn ON tn.id = e.target_id
                WHERE (%(source_id)s::text IS NULL OR tn.source_id = %(source_id)s::text)
                  {tier_filter}
            ),
            capped_edges AS (
                SELECT source_id, target_id, relation
                FROM ranked_edges
                WHERE rn <= %(fanout_cap)s
            ),
            traverse(id, depth, path, relation, seed_id) AS (
                SELECT n.id, 0, ARRAY[n.id], NULL::text, n.id
                FROM kg_nodes n WHERE n.id = ANY(%(seeds)s) {where}
                UNION ALL
                SELECT ce.target_id, t.depth + 1, t.path || ce.target_id, ce.relation, t.seed_id
                FROM capped_edges ce
                JOIN traverse t ON ce.source_id = t.id
                WHERE t.depth < %(depth)s
                  AND NOT ce.target_id = ANY(t.path)
            )
            SELECT DISTINCT ON (id) id, depth, relation, seed_id
            FROM traverse
            WHERE depth > 0
            ORDER BY id, depth ASC
            """,
            {"seeds": seed_ids, "depth": max_depth, "source_id": source_id,
             "fanout_cap": settings.d_bfs_fanout_cap_per_hop, "tier": tier},
        ).fetchall()
        return rows


# =============================================================================
# D — Retrieval (dense / bm25 / graph)
# =============================================================================

def dense_search(query_embedding: list[float], limit: int = 20, source_id: Optional[str] = None) -> list[dict]:
    with get_conn() as conn:
        where = "WHERE source_id = %(source_id)s" if source_id else ""
        return conn.execute(
            f"""SELECT id, raw, normalized, source_id, section_id, chapter, page_start,label,
                      confidence, contradicts_flag,
                      1 - (embedding <=> %(e)s::vector) AS score
               FROM knowledge_atoms
               {where}
               ORDER BY embedding <=> %(e)s::vector LIMIT %(l)s""",
            {"e": query_embedding, "l": limit, "source_id": source_id},
        ).fetchall()

def chunk_children_atom_ids(parent_chunk_id: str) -> list[str]:
    """Expand a matched PARENT chunk_record back down to the exact child
    knowledge_atom ids under it (child chunk_records rows are written with
    `id=atom.id`, `parent_id=parent_id` — see B2.build_chunk_records), so
    retrieval can search at the context-restored parent level while still
    citing/grounding on the precise, verbatim child atom.
    """
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id FROM chunk_records WHERE parent_id=%s AND type='child'",
            (parent_chunk_id,),
        ).fetchall()
        return [r["id"] for r in rows]

# AFTER
def dense_search_chunks(query_embedding: list[float], limit: int = 20, source_id: Optional[str] = None) -> list[dict]:
    with get_conn() as conn:
        where = "AND id LIKE %(prefix)s" if source_id else ""
        prefix = f"parent_{source_id}%" if source_id else ""
        return conn.execute(
            f"""SELECT id, content, type,
                      1 - (embedding <=> %(e)s::vector) AS score
               FROM chunk_records
               WHERE type = 'parent' {where}
               ORDER BY embedding <=> %(e)s::vector LIMIT %(l)s""",
            {"e": query_embedding, "l": limit, "prefix": prefix},
        ).fetchall()


# AFTER
def bm25_search(query_text: str, limit: int = 20, source_id: Optional[str] = None) -> list[dict]:
    with get_conn() as conn:
        where = "AND source_id = %(source_id)s" if source_id else ""
        return conn.execute(
            f"""SELECT id, raw, normalized, source_id, section_id, chapter, page_start,
                      confidence, contradicts_flag,
                      ts_rank_cd(search_vector, query) AS score
               FROM knowledge_atoms, plainto_tsquery('simple', unaccent(%(q)s)) query
               WHERE search_vector @@ query {where}
               ORDER BY score DESC LIMIT %(l)s""",
            {"q": query_text, "l": limit, "source_id": source_id},
        ).fetchall()


# AFTER
def bm25_search_chunks(query_text: str, limit: int = 20, source_id: Optional[str] = None) -> list[dict]:
    with get_conn() as conn:
        where = "AND id LIKE %(prefix)s" if source_id else ""
        prefix = f"parent_{source_id}%" if source_id else ""
        return conn.execute(
            f"""SELECT id, content,type,
                      ts_rank_cd(search_vector, query) AS score
               FROM chunk_records, plainto_tsquery('simple', unaccent(%(q)s)) query
               WHERE type = 'parent' AND search_vector @@ query {where}
               ORDER BY score DESC LIMIT %(l)s""",
            {"q": query_text, "l": limit, "prefix": prefix},
        ).fetchall()


def atoms_for_ids(ids: list[str]) -> dict[str, dict]:
    if not ids:
        return {}
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM knowledge_atoms WHERE id = ANY(%s)", (ids,)
        ).fetchall()
        return {r["id"]: r for r in rows}


def get_knowledge_atom(atom_id: str) -> Optional[dict]:
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM knowledge_atoms WHERE id=%s", (atom_id,)
        ).fetchone()


def get_atoms_by_source(source_id: str) -> list[KnowledgeAtom]:
    """Used between A4/B1 (queue-based, per-section) and A5/B2 (whole-document):
    once all of a source_id's section_jobs are 'done', call this to gather
    every KnowledgeAtom stored so far and hand it to a5_global_merge / b2_*."""
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM knowledge_atoms WHERE source_id=%s ORDER BY section_id", (source_id,)
        ).fetchall()
        def _as_list(v):
            return v.to_list() if hasattr(v, "to_list") else v

        return [
            KnowledgeAtom(
                id=r["id"], source_id=r["source_id"], section_id=r["section_id"],
                chapter=r["chapter"], page_start=r["page_start"], label=r["label"],
                raw=r["raw"], normalized=r["normalized"], confidence=r["confidence"] or 0.0,
                contradicts_flag=r["contradicts_flag"], embedding=_as_list(r["embedding"]),
                entities=r.get("entities") or [],
            )
            for r in rows
        ]


def all_section_jobs_done(source_id: str) -> bool:
    """Cheap poll to know when it's safe to run A5/B2 for a source_id."""
    with get_conn() as conn:
        row = conn.execute(
            """SELECT count(*) FILTER (WHERE status NOT IN ('done', 'manual_review')) AS pending
               FROM section_jobs WHERE source_id=%s""",
            (source_id,),
        ).fetchone()
        return row["pending"] == 0


# =============================================================================
# C — batch monitoring
# =============================================================================

def start_batch(total_documents: int) -> str:
    with get_conn() as conn:
        row = conn.execute(
            "INSERT INTO batch_runs (total_documents) VALUES (%s) RETURNING id",
            (total_documents,),
        ).fetchone()
        return str(row["id"])


def finish_batch(batch_id: str) -> BatchRun:
    with get_conn() as conn:
        stats = conn.execute(
            """SELECT count(*) FILTER (WHERE status='manual_review') AS manual_review,
                      count(*) FILTER (WHERE status='failed') AS failed,
                      count(*) AS total
               FROM section_jobs WHERE batch_id=%s""",
            (batch_id,),
        ).fetchone()
        conn.execute(
            """UPDATE batch_runs SET finished_at=now(), total_sections=%s,
                      failed_sections=%s, manual_review_sections=%s WHERE id=%s""",
            (stats["total"], stats["failed"], stats["manual_review"], batch_id),
        )
        row = conn.execute("SELECT * FROM batch_runs WHERE id=%s", (batch_id,)).fetchone()
        row = dict(row)
        row["id"] = str(row["id"])
        return BatchRun(**row)

def set_contradicts_flag(atom_ids: list[str]) -> None:
    """Flips knowledge_atoms.contradicts_flag=TRUE for every id in
    `atom_ids` — called by B2 (build_kg) for both endpoints of every A5
    CONTRADICTS cross_link. Previously nothing in the codebase ever wrote to
    this column despite RetrievedCandidate/E reading it."""
    if not atom_ids:
        return
    with get_conn() as conn:
        conn.execute(
            "UPDATE knowledge_atoms SET contradicts_flag = TRUE WHERE id = ANY(%s)",
            (atom_ids,),
        )


def get_contradicting_atom(atom_id: str) -> Optional[dict]:
    """E's contradicts_flag handling: given an atom flagged contradicts_flag,
    find the atom(s) on the other end of its CONTRADICTS kg_edge so the
    answer can surface both sides instead of silently picking one."""
    with get_conn() as conn:
        row = conn.execute(
            """SELECT CASE WHEN source_id = %(id)s THEN target_id ELSE source_id END AS other_id
               FROM kg_edges WHERE relation = 'CONTRADICTS' AND (source_id = %(id)s OR target_id = %(id)s)
               LIMIT 1""",
            {"id": atom_id},
        ).fetchone()
        if not row:
            return None
        return get_knowledge_atom(row["other_id"])


def dense_search_communities(query_embedding: list[float], limit: int = 5,
                              source_id: Optional[str] = None) -> list[dict]:
    """D's community_search — dense search over the lazily-summarized
    community chunk_records B2.5 persists (type='community')."""
    with get_conn() as conn:
        if source_id is None:
            return conn.execute(
                """SELECT id, content, type, children,
                          1 - (embedding <=> %(e)s::vector) AS score
                   FROM chunk_records WHERE type = 'community'
                   ORDER BY embedding <=> %(e)s::vector LIMIT %(l)s""",
                {"e": query_embedding, "l": limit},
            ).fetchall()
        return conn.execute(
            """SELECT id, content, type, children,
                      1 - (embedding <=> %(e)s::vector) AS score
               FROM chunk_records WHERE type = 'community' AND id LIKE %(prefix)s
               ORDER BY embedding <=> %(e)s::vector LIMIT %(l)s""",
            {"e": query_embedding, "l": limit, "prefix": f"community_{source_id}_%"},
        ).fetchall()


def term_exists_in_corpus(term: str, source_id: Optional[str] = None) -> bool:
    """Corpus-wide existence check for a literal term, independent of
    retrieval ranking (dense/bm25/graph top-k). Used as a fallback by stage
    D's coverage_check: a term missing from the *retrieved* pool only tells
    us retrieval didn't surface it (embedding miss, bm25/tsvector 'english'
    config mangling a non-English token, or a graph node that was never
    linked) — it does NOT tell us the term is absent from the document.
    Only a full-corpus miss justifies telling the LLM 'tài liệu không đề cập
    đến X'. This is a plain ILIKE scan, not full-text ranked search, since we
    only need a yes/no existence answer here, not relevance scoring."""
    with get_conn() as conn:
        params = {"t": f"%{term}%"}
        query = "SELECT 1 FROM knowledge_atoms WHERE (raw ILIKE %(t)s OR normalized ILIKE %(t)s)"
        if source_id:
            query += " AND source_id = %(s)s"
            params["s"] = source_id
        row = conn.execute(query + " LIMIT 1", params).fetchone()
        return row is not None

def get_heading_atom(source_id: str, section_id: str) -> Optional[dict]:
    with get_conn() as conn:
        return conn.execute(
            "SELECT id FROM knowledge_atoms WHERE source_id=%s AND section_id=%s AND label='HEADING'",
            (source_id, section_id)
        ).fetchone()
    
def lookup_entity_ids(terms: list[str], source_id: Optional[str] = None) -> list[str]:
    """Tra entity_map để tìm entity_id ứng với key-term trích từ câu hỏi."""
    if not terms:
        return []
    with get_conn() as conn:
        # Chú ý: tên bảng thực tế là 'entity_map' (xem schema.sql)
        # cột canonical_name chứa tên entity
        rows = conn.execute(
            """SELECT DISTINCT entity_id FROM entity_map
               WHERE canonical_name = ANY(%(terms)s)
                 AND (%(source_id)s::text IS NULL OR source_id = %(source_id)s::text)""",
            {"terms": terms, "source_id": source_id},
        ).fetchall()
        return [r["entity_id"] for r in rows]

def get_atom_ids_mentioning_entities(entity_ids: list[str], source_id: Optional[str] = None,
                                      limit_per_entity: int = 5) -> list[str]:
    """Đề xuất #11 — MENTIONS edges (entity -> atom, kg_edges, xem
    stages/b2_wiki_graph_chunking.py) cho các entity_ids đã cho. Dùng làm
    nguồn bổ sung 'traversal_seed_ids' LỎNG HƠN seed dense/bm25 thường:
    atom chỉ được xác nhận qua entity TRÙNG KHỚP với câu hỏi, không cần
    similarity cao — phù hợp vai trò "điểm vào graph traversal" chứ KHÔNG
    phù hợp vai trò evidence câu trả lời cuối (xem
    stages/d_retrieval.py::retrieve(), biến traversal_seed_ids).

    `limit_per_entity` cap số atom lấy ra cho MỖI entity — 1 entity hub
    (mention ở rất nhiều atom) không được chiếm hết ngân sách; caller
    (retrieve()) còn áp thêm 1 cap TUYỆT ĐỐI trên tổng số atom thêm vào,
    xem settings.d_traversal_seed_max_extra_atoms.
    """
    if not entity_ids:
        return []
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT e.source_id AS entity_id, e.target_id AS atom_id
               FROM kg_edges e
               JOIN knowledge_atoms a ON a.id = e.target_id
               WHERE e.relation = 'MENTIONS' AND e.source_id = ANY(%(eids)s)
                 AND (%(source_id)s::text IS NULL OR a.source_id = %(source_id)s::text)""",
            {"eids": entity_ids, "source_id": source_id},
        ).fetchall()
    by_entity: dict[str, list[str]] = {}
    for r in rows:
        by_entity.setdefault(r["entity_id"], []).append(r["atom_id"])
    atom_ids: list[str] = []
    for aids in by_entity.values():
        atom_ids.extend(aids[:limit_per_entity])
    return list(dict.fromkeys(atom_ids))


def get_edges_between_atoms(atom_ids: list[str]) -> list[dict]:
    """Trả về các cạnh có cả source và target đều nằm trong danh sách atom_ids."""
    if not atom_ids:
        return []
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT source_id, target_id, relation, evidence_raw, score
               FROM kg_edges
               WHERE source_id = ANY(%(ids)s) AND target_id = ANY(%(ids)s)""",
            {"ids": atom_ids},
        ).fetchall()
        return rows

def get_atoms_by_sections(source_id: str, section_ids: list[str]) -> list[KnowledgeAtom]:
    """Lấy tất cả KnowledgeAtom thuộc các section_ids (kể cả heading cũ)."""
    if not section_ids:
        return []
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM knowledge_atoms WHERE source_id=%s AND section_id = ANY(%s)",
            (source_id, section_ids)
        ).fetchall()
        def _as_list(v):
            return v.to_list() if hasattr(v, "to_list") else v
        return [
            KnowledgeAtom(
                id=r["id"], source_id=r["source_id"], section_id=r["section_id"],
                chapter=r["chapter"], page_start=r["page_start"], label=r["label"],
                raw=r["raw"], normalized=r["normalized"], confidence=r["confidence"] or 0.0,
                contradicts_flag=r["contradicts_flag"], embedding=_as_list(r["embedding"]),
                entities=r.get("entities") or [],
            )
            for r in rows
        ]

# --- Giai đoạn 0 — Fact layer (MỚI) ---
def insert_kg_fact(fact: Fact) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO kg_facts (id, source_id, source_entity_id, target_entity_id, relation_type, confidence)
               VALUES (%s,%s,%s,%s,%s,%s)
               ON CONFLICT (id) DO UPDATE SET confidence=EXCLUDED.confidence, updated_at=now()""",
            (fact.id, fact.source_id, fact.source_entity_id, fact.target_entity_id,
             fact.relation_type, fact.confidence),
        )


def insert_fact_evidence(ev: FactEvidence) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO fact_evidence (fact_id, atom_id, evidence_raw, confidence)
               VALUES (%s,%s,%s,%s)
               ON CONFLICT (fact_id, atom_id) DO UPDATE SET evidence_raw=EXCLUDED.evidence_raw,
                 confidence=EXCLUDED.confidence""",
            (ev.fact_id, ev.atom_id, ev.evidence_raw, ev.confidence),
        )


# --- Giai đoạn 2 — entity linking + traversal cho entity-path retrieval (MỚI) ---
def ann_search_entities(embedding: list[float], top_k: int = 1, source_id: Optional[str] = None,
                         min_similarity: float = 0.75) -> list[dict]:
    """ANN nearest-neighbor search over entity_map.name_embedding (A4.5's
    per-entity embedding — see stages/a4_5_entity_consolidation.py, and
    db.save_entity_map for where it's persisted). Fallback entity-linking
    channel for D's _entities_from_query when ILIKE substring match on
    canonical_name misses — e.g. the question phrases an entity differently
    from the canonical alias A4.5 happened to pick (union-find keeps the
    LONGEST mention as canonical_name, which is not necessarily how a user
    phrases it in a question). Only rows with a non-NULL name_embedding are
    considered (older/incrementally-updated rows may not have one yet — see
    save_entity_map's COALESCE-on-conflict). Results below `min_similarity`
    are dropped rather than returned as low-confidence guesses, since a
    wrong entity-link here silently redirects entity_path_search onto the
    wrong part of the graph."""
    if not embedding:
        return []
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT entity_id, canonical_name,
                      1 - (name_embedding <=> %(e)s::vector) AS score
               FROM entity_map
               WHERE name_embedding IS NOT NULL
                 AND (%(source_id)s::text IS NULL OR source_id = %(source_id)s::text)
               ORDER BY name_embedding <=> %(e)s::vector LIMIT %(k)s""",
            {"e": embedding, "source_id": source_id, "k": top_k},
        ).fetchall()
        return [r for r in rows if (r.get("score") or 0.0) >= min_similarity]


def get_all_facts_for_source(source_id: Optional[str] = None) -> list[dict]:
    """All kg_facts rows (id, source_entity_id, target_entity_id,
    relation_type, confidence) for one source_id (or the whole KB if None) —
    input to stages/d_retrieval.py::graph_ppr_facts (đề xuất #6): the
    reasoning graph (kg_facts) is small/domain-stable enough to run
    full-graph PPR on directly, unlike the atom-mixed graph
    graph_search_ppr works with."""
    with get_conn() as conn:
        if source_id:
            rows = conn.execute(
                """SELECT id, source_entity_id, target_entity_id, relation_type, confidence
                   FROM kg_facts WHERE source_id=%s""",
                (source_id,),
            ).fetchall()
        else:
            rows = conn.execute(
                """SELECT id, source_entity_id, target_entity_id, relation_type, confidence
                   FROM kg_facts"""
            ).fetchall()
        return rows


def lookup_entity_ids_like(terms: list[str], source_id: Optional[str] = None,
                            limit_per_term: int = 3) -> list[str]:
    if not terms:
        return []
    with get_conn() as conn:
        ids: list[str] = []
        for term in terms:
            rows = conn.execute(
                """SELECT entity_id FROM entity_map
                   WHERE canonical_name ILIKE %(pattern)s
                     AND (%(source_id)s::text IS NULL OR source_id = %(source_id)s::text)
                   ORDER BY section_count DESC LIMIT %(limit)s""",
                {"pattern": f"%{term}%", "source_id": source_id, "limit": limit_per_term},
            ).fetchall()
            ids.extend(r["entity_id"] for r in rows)
        return list(dict.fromkeys(ids))


def graph_traverse_facts(seed_entity_ids: list[str], max_depth: int = 3,
                          source_id: Optional[str] = None,
                          bidirectional: bool = False) -> list[dict]:
    """BFS depth-capped traversal trên kg_facts, xuất phát từ nhiều seed cùng
    lúc. Trả về 1 row/entity mới duyệt tới (`reached_entity_id`) — DISTINCT
    ON, ORDER BY depth ASC — tức là cạnh cuối cùng của đường đi NGẮN NHẤT
    tới entity đó, từ BẤT KỲ seed nào tới trước.

    Mỗi row còn có `path`: mảng entity_id đầy đủ từ origin_seed (path[0])
    tới `reached_entity_id` (path[-1]) của chính đường đi ngắn nhất đó (đã
    có sẵn nội bộ trong recursive CTE, giờ được SELECT ra — đề xuất #8).
    Dùng để dựng lại 1 chain tuyến tính cụ thể nối 2 seed entity cụ thể (xem
    stages/d_retrieval.py::_linear_path_edges), thay vì chỉ có tập cạnh
    reachable phẳng như trước.

    bidirectional (mặc định False, GIỮ NGUYÊN hành vi cũ khi không truyền)
    — câu hỏi người dùng: 1 entity CHỈ từng là `target_entity_id` trong
    kg_facts (chưa bao giờ là `source_entity_id`, VD 1 entity "kết quả"
    kiểu "503 Error" — nhiều thứ gây ra nó, nó không gây ra gì khác; hoặc
    do LLM trích xuất không nhất quán chiều giữa các câu văn khác nhau cho
    cùng 1 cặp entity) — khi được dùng làm SEED, BFS 1 chiều cũ
    (`f.source_entity_id = t.entity_id`) không có cạnh nào để đi ra, luôn
    trả về path rỗng cho seed đó, dù entity đó CÓ mặt trong graph (là
    target của nhiều fact). bidirectional=True cho phép JOIN theo CẢ 2
    chiều — BFS được đi "ngược" 1 cạnh để tìm đường, nhưng
    `source_entity_id`/`target_entity_id`/`relation_type` trả về LUÔN là
    giá trị THẬT đã lưu trong kg_facts (không đảo ngược) — chỉ đổi chiều
    DUYỆT (tìm đường), không đổi chiều HIỂN THỊ/ý nghĩa quan hệ nhân-quả.

    reached_entity_id — entity THỰC SỰ mới duyệt tới ở bước này. Khi
    bidirectional=False, luôn bằng target_entity_id (y hệt hành vi cũ, chỉ
    thêm alias rõ nghĩa). Khi bidirectional=True, có thể bằng
    source_entity_id (nếu bước này đi NGƯỢC 1 cạnh) — code gọi hàm này
    (entity_path_search, đặc biệt _linear_path_edges/_chain_coverage_for_pairs)
    PHẢI dùng `reached_entity_id` để biết "entity nào mới được thêm vào
    path", KHÔNG dùng target_entity_id (chỉ đúng khi luôn đi thuận)."""
    if not seed_entity_ids:
        return []
    if not bidirectional:
        sql = """
            WITH RECURSIVE traverse(entity_id, depth, path, fact_id, source_entity_id,
                                     target_entity_id, relation_type, origin_seed) AS (
                SELECT id, 0, ARRAY[id], NULL::text, NULL::text, NULL::text, NULL::text, id
                FROM kg_nodes WHERE id = ANY(%(seeds)s)
                UNION ALL
                SELECT f.target_entity_id, t.depth + 1, t.path || f.target_entity_id,
                       f.id, f.source_entity_id, f.target_entity_id, f.relation_type, t.origin_seed
                FROM kg_facts f
                JOIN traverse t ON f.source_entity_id = t.entity_id
                WHERE t.depth < %(depth)s
                  AND NOT f.target_entity_id = ANY(t.path)
                  AND (%(source_id)s::text IS NULL OR f.source_id = %(source_id)s::text)
            ),
            seed_reach AS (
                SELECT target_entity_id AS entity_id, COUNT(DISTINCT origin_seed) AS seed_reach_count
                FROM traverse WHERE depth > 0
                GROUP BY target_entity_id
            )
            SELECT DISTINCT ON (t.target_entity_id) t.target_entity_id AS reached_entity_id,
                   t.source_entity_id, t.target_entity_id,
                   t.relation_type, t.fact_id, t.depth, sr.seed_reach_count, t.path
            FROM traverse t
            JOIN seed_reach sr ON sr.entity_id = t.target_entity_id
            WHERE t.depth > 0
            ORDER BY t.target_entity_id, t.depth ASC
            """
    else:
        sql = """
            WITH RECURSIVE traverse(entity_id, depth, path, fact_id, source_entity_id,
                                     target_entity_id, relation_type, origin_seed) AS (
                SELECT id, 0, ARRAY[id], NULL::text, NULL::text, NULL::text, NULL::text, id
                FROM kg_nodes WHERE id = ANY(%(seeds)s)
                UNION ALL
                SELECT
                    CASE WHEN f.source_entity_id = t.entity_id THEN f.target_entity_id ELSE f.source_entity_id END,
                    t.depth + 1,
                    t.path || (CASE WHEN f.source_entity_id = t.entity_id THEN f.target_entity_id ELSE f.source_entity_id END),
                    f.id, f.source_entity_id, f.target_entity_id, f.relation_type, t.origin_seed
                FROM kg_facts f
                JOIN traverse t ON (f.source_entity_id = t.entity_id OR f.target_entity_id = t.entity_id)
                WHERE t.depth < %(depth)s
                  AND NOT (CASE WHEN f.source_entity_id = t.entity_id THEN f.target_entity_id ELSE f.source_entity_id END) = ANY(t.path)
                  AND (%(source_id)s::text IS NULL OR f.source_id = %(source_id)s::text)
            ),
            seed_reach AS (
                SELECT entity_id, COUNT(DISTINCT origin_seed) AS seed_reach_count
                FROM traverse WHERE depth > 0
                GROUP BY entity_id
            )
            SELECT DISTINCT ON (t.entity_id) t.entity_id AS reached_entity_id,
                   t.source_entity_id, t.target_entity_id,
                   t.relation_type, t.fact_id, t.depth, sr.seed_reach_count, t.path
            FROM traverse t
            JOIN seed_reach sr ON sr.entity_id = t.entity_id
            WHERE t.depth > 0
            ORDER BY t.entity_id, t.depth ASC
            """
    with get_conn() as conn:
        rows = conn.execute(
            sql, {"seeds": seed_entity_ids, "depth": max_depth, "source_id": source_id},
        ).fetchall()
        return rows


def get_fact_evidence_for_facts(fact_ids: list[str]) -> list[dict]:
    if not fact_ids:
        return []
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT fe.fact_id, fe.atom_id, fe.evidence_raw, fe.confidence,
                        kf.confidence AS fact_confidence,
                        a.raw, a.normalized, a.section_id, a.source_id, a.chapter, a.page_start,
                        a.confidence AS atom_confidence, a.contradicts_flag
                FROM fact_evidence fe
                JOIN knowledge_atoms a ON a.id = fe.atom_id
                JOIN kg_facts kf ON kf.id = fe.fact_id
                WHERE fe.fact_id = ANY(%(ids)s)""",
            {"ids": fact_ids},
        ).fetchall()
        return rows

def find_near_duplicate_pairs(atom_ids: list[str], threshold: float) -> list[tuple[str, str, float]]:
    """Câu hỏi người dùng — candidate lấy từ 3 nguồn (seed/expanded/community/
    entity_path) có thể trùng NGỮ NGHĨA dù atom_id khác nhau (VD 3 atom diễn
    đạt lại cùng 1 sự kiện theo 3 cách khác nhau) — trùng atom_id đã được
    merge_candidates_with_priority() lọc đúng (không tốn slot), nhưng trùng
    NGỮ NGHĨA (atom_id khác) thì KHÔNG — mỗi bản vẫn chiếm 1 slot riêng,
    khiến candidate mới/khác thật sự bị dồn ra ngoài dù điểm cao hơn.

    Chỉ nên gọi trên tập candidate CUỐI CÙNG (đã bounded, ví dụ <=20) — self
    -join O(n^2) nhưng n nhỏ nên rẻ, tính trực tiếp trong SQL bằng pgvector
    (<=>) thay vì kéo vector về Python rồi tính tay.

    Trả về list (id1, id2, similarity) — chỉ các cặp similarity > threshold,
    id1 < id2 (không lặp cặp theo cả 2 chiều)."""
    if len(atom_ids) < 2:
        return []
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT a.id AS id1, b.id AS id2,
                      1 - (a.embedding <=> b.embedding) AS similarity
               FROM knowledge_atoms a, knowledge_atoms b
               WHERE a.id = ANY(%(ids)s) AND b.id = ANY(%(ids)s) AND a.id < b.id
                 AND a.embedding IS NOT NULL AND b.embedding IS NOT NULL
                 AND 1 - (a.embedding <=> b.embedding) > %(threshold)s""",
            {"ids": atom_ids, "threshold": threshold},
        ).fetchall()
        return [(r["id1"], r["id2"], float(r["similarity"])) for r in rows]