"""
LLM Pool với cơ chế Retry + Fallback
Tạo sẵn 3 pool: strong, medium, easy
Mỗi pool có danh sách LLM clients xoay vòng
Khi một LLM bị lỗi, tự động thử LLM tiếp theo trong pool
"""
from __future__ import annotations

import logging
import random
from typing import Optional, List, Callable, Any
from common.llm_client import (
    LLMClient, GroqClient, GeminiClient, CerebrasClient,AionLabsClient,ZaiClient,
    OpenrouterClient, HuggingFaceClient, OllamaClient,AlibabaClient,CloudflareClient,
    MistralClient,OllamaCloudClient
)
from common.config import settings

logger = logging.getLogger(__name__)

class RetryLLMClient(LLMClient):
    def __init__(self, pool: LLMClientPool, tier: str):
        self.pool = pool
        self.tier = tier

    def generate(self, prompt: str, system: Optional[str] = None,
                 json_mode: bool = False, tier: str = "light") -> str:
        # Bỏ qua tham số tier, dùng tier đã khởi tạo
        return self.pool.generate_with_retry(prompt, system, json_mode, self.tier)

    def embed(self, texts: list[str]) -> list[list[float]]:
        return self.pool.embed(texts)

class LLMPool:
    """Một pool chứa nhiều LLM clients, hỗ trợ retry + fallback"""
    
    def __init__(self, clients: List[LLMClient], name: str = "pool"):
        self.clients = clients
        self.name = name
        self._current_index = -1  # Bug 3 — bắt đầu ở -1 để lần gọi đầu tiên advance về 0
        self._failed_clients = set()  # Lưu các client đã fail trong lần gọi hiện tại
        
    def get_next_client(self) -> Optional[LLMClient]:
        """Lấy client tiếp theo trong pool (XOAY VÒNG thật — round-robin qua
        các client CHƯA fail, không phải luôn trả về client khả dụng đầu
        tiên như trước đây — Bug 3).

        Fix Bug 3: trước đây luôn `available[0]` -> client 0 (nếu không bao
        giờ fail) được dùng cho MỌI request, các client khác trong pool gần
        như không được gọi tới -> không đạt mục tiêu chia tải qua nhiều key.
        Giờ advance `_current_index` mỗi lần gọi, bỏ qua client đã fail."""
        if not self.clients:
            return None

        available = [i for i in range(len(self.clients)) if i not in self._failed_clients]
        if not available:
            return None

        n = len(self.clients)
        for _ in range(n):
            self._current_index = (self._current_index + 1) % n
            if self._current_index in self._failed_clients:
                continue
            return self.clients[self._current_index]
        return None  # không nên tới đây vì đã check `available` ở trên, nhưng an toàn
    
    def mark_failed(self, client: LLMClient) -> None:
        """Đánh dấu một client đã fail trong lần gọi hiện tại"""
        try:
            idx = self.clients.index(client)
            self._failed_clients.add(idx)
        except ValueError:
            pass
    
    def reset_failures(self) -> None:
        """Reset danh sách fail cho lần gọi tiếp theo"""
        self._failed_clients.clear()
    
    def size(self) -> int:
        return len(self.clients)
    
    def available_count(self) -> int:
        return len(self.clients) - len(self._failed_clients)


class LLMClientPool:
    """
    Hệ thống quản lý 3 pool LLM với cơ chế retry + fallback
    """
    
    def __init__(self):
        self.pools = {
            "strong": self._build_strong_pool(),
            "medium": self._build_medium_pool(),
            "easy": self._build_easy_pool(),
        }
        self._fallback_chain = {
            "strong": "medium",
            "medium": "easy",
            "easy": None  # Không có fallback cho easy
        }
        self._current_pool = "easy"
        
    def _build_strong_pool(self) -> LLMPool:
        """Pool mạnh - dùng cho các tác vụ phức tạp"""
        clients = []
        
        
            
        # Gemini Pro
        # Ab8RN6Kc91MkNjv5tJi-F128WBCSVs4M3T9tUndKgVehSjyjhw
        # JgVLFamVXoGdoYo72z912qNIWESit23DqTErJ2Q
        for key in [
            "AQ.Ab8RN6KAiSW-HPAF1F7kjMT6ppzn_b9mkxlAs1WyrrwUcR1G8w",
            "AQ.Ab8RN6L3kNC4onmtdJ7AmOm7CKl6TayJ4yA_YrxvK3WT-8CiAA",
            "AQ.Ab8RN6Kc91MkNjv5tJi-F128WBCSVs4M3T9tUndKgVehSjyjhw",
            "AQ.Ab8RN6LNJ--JgVLFamVXoGdoYo72z912qNIWESit23DqTErJ2Q"
        ]:
            client = GeminiClient()
            client.set_key(key)
            clients.append(client)

        # HuggingFace
        for key in [
            "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",
            "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",
            "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",
            "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",
            "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",
            "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",
            "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",
            "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",
            "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",
            "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",
            "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",
            "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",
            "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",
            "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",
            "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"
        ]:
            client = HuggingFaceClient()
            client.set_key(key)
            clients.append(client)
            
        return LLMPool(clients, name="strong")
    
    def _build_medium_pool(self) -> LLMPool:
        """Pool trung bình - dùng cho các tác vụ vừa"""
        clients = []
        
        # for key in [
        #     "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",
        #     "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",
        #     "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",
        #     "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",
        #     "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",
        #     "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",
        #     "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",
        #     "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",
        #     "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",
        #     "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",
        #     "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",
        #     "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",
        #     "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",
        #     "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",
        #     "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"
        # ]:
        #     client = HuggingFaceClient()
        #     client.set_key(key)
        #     clients.append(client)

        for key in [
            "cddf8a33515d41db9be8865766857242.DbhW7H2BQ0I4ZeuuSmJWWcFH",
        ]:
            client = OllamaCloudClient()
            client.set_key(key)
            clients.append(client)

        # for key in [
        #     "zOdGnRrBcexVQVyiNYf93EQnmDexfj4p",
        #     "6Ot17SCCFqvpLkRyXJhK4GtesKNsGSoM",
        #     "auD9UXqOOxlt8NSZu5AwcarENVrmIxDc",
        #     "cwfPFzdHI9ZkgIyowqUUPhBhZV300cuZ"
        # ]:
        #     client = MistralClient()
        #     client.set_key(key)
        #     clients.append(client)

        # for key in [
        #     "8e379acb806b4860b11d240afeb80e99.hqNBDQLe2Tt80Hpw",
        #     "8235770ba9e0458b8e13bf420df26b82.2MZTNOaxNQSoVvNd",
        #     "c1919aa8fe7847fb9230ab5857ab6950.hMlLFrE7wcTz8qOh",
        #     "8da4cf33300b49b69e6fef6f8b1238a8.DOU3yvkLyVIazi38",
        #     "69171e8442404a529c22e16d907ff4b6.10rOEhULansd4651",
        #     "48784ad0d8d1406bbbc64c397080884b.GEb71TExrjbYEZ6K",
        #     "02978e81026b4d1f989694538395d35c.kVOlzQgz9UifILc6"
        # ]:
        #     client = ZaiClient()
        #     client.set_key(key)
        #     clients.append(client)

        for key in [
            "alv2_NE2HmquNrfyK7Z5Y3O-AgrSq_VKgAorbIE_K9cGbzZk",
            "alv2_QvPl3WYZe0yBKMGZUTkzy2SzDETF8NLgKNNv_tOrW6E",
            "alv2_8kZ8hJQOr3eptNw2o0eDh9BXMtF3ju442zf4HkSQfr4",
            "alv2_dsHQhc-dAz3AYPtkz6kY4IwohJHxl18xLJlqu8FdQZE",
            "alv2_oxX03rPVDbHib1XN_YfWYJd2aXgrS5a1-5jDj77cc6c",
            "alv2_6Tg4rGHyoobzcqjXHz0-g6-sXn2aNugUhPF6uHaVWkw",
        ]:
            client = AionLabsClient()
            client.set_key(key)
            clients.append(client)

        # for key in [
        #     "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",
        #     "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",
        #     "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",
        #     "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",
        #     "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",
        #     "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"
        # ]:
        #     client = GroqClient()
        #     client.set_key(key)
        #     clients.append(client)
            
        

        for item  in [
                {"key": "cfut_SNmu13EO4A3ivczBpkA2mNwA3S6wcyNINhYlkIBr4837a3b6", "account_id": "be9f4d8e6e32b5db14e7f41424c51cae"},
                {"key": "cfut_AdnOFbxO3IaV6J4iMfB5llvcDODmXEmSaQBBOSi8b05e580e", "account_id": "f1bddd973672ce5f77f624e65e555ac4"},
                {"key": "cfut_MXhkWzTqegIgh8Gyn8QzOxc2RJd4027nbxTal6Ed4cecaedb", "account_id": "743b8d8cf8f37b53eb2c8912f385424f"},
                {"key": "cfut_vsEpW3dtG0GQMLunTNE0vCVKNzuUrstYTM0QPaFucb924430", "account_id": "0ec8964277597b60f346f5d66149c67f"},
                {"key": "cfut_xFrLfjh2ZOJMCZGbgmFniO2g2HprXsLqevD94kOl72e4764a", "account_id": "61d2adc7013a917885785d040c09ae4b"},
                {"key": "cfut_SpHibVDxGS0khDbPp6ly3GO1Mu9aAbRPue1SmZ42b45aeb99", "account_id": "733395684159b05856f88aa23795c8c7"},
                {"key": "cfut_MtUfWsQti1ODtOamjXskKo4seMZOYQgXKKjKuB5Maaee36e9", "account_id": "ea9fa13c4ac31810575ef339c08047f7"},
                {"key": "cfut_ES77hDj3zp2gETj8SagNGYU03XJFfg148uWk2Myza18226d2", "account_id": "e5f191a6dbe192572fbd42c8d30c7c35"},
            ]:
            client = CloudflareClient()
            client.set_key(key=item["key"], account_id=item["account_id"] )
            clients.append(client)
        
        for item  in [
                {"key": "sk-ws-H.DMHEMLL.6kr0.MEUCIQCP5saDdKDFVh4KbaaHL8lCiBgwI-8Xhn2GyhBqyRHNnwIgRQDsj73ccVAcP0WKx1w9m-OMI7PM0X60O5wCAEIuGlI", "workspace_id": "ws-kpde21wer5ix2ad6"},
                {"key": "sk-ws-H.DMHELLI.7Xhy.MEUCIQDAjJ3BMI1pkPogy1nDZB4g8D0P9gZmzEjy6kpfWd79fwIgfFtoZvXIF-QNm6FRjKsgOqJnXKEhGFdT-xp_WcJ_6_I", "workspace_id": "ws-dqg0mm1esvvjw43l"},
                {"key": "sk-ws-H.DMRMLEP.1POu.MEYCIQC4piSNMmmDJLsFjCqbPd3rfdTE_NAh3w2j8gUimb2eEAIhAIQ7tkvOlfLdzUVI2BCNf47wZyOXA0N_mmhnC1NeChFK", "workspace_id": "ws-zl75frmrb26bfp35"},
                {"key": "sk-ws-H.DMRMDHE.YgWp.MEQCIGlQCBr6B6Y0mYNOTiHk5z5DyT4uqLZIOhlLmi1u43slAiBATjrmsXpSDI5Iqp4DBgBkRDPrsiWfgfu-qgjyQumznw", "workspace_id": "ws-t3aktbli6v8g5dvb"},
                {"key": "sk-ws-H.DMLPREP.0lQT.MEUCIFxhTLeUMcDwdQ0ybPF6YDi60x8zFpTPa41re3DGvmbbAiEAw4xLNrR8p7g52CGZH8NqenVOlwLGH8aazPzMhrsNGJA", "workspace_id": "ws-7c3u3r6ndfpsue02"},
                {"key": "sk-ws-H.DMLPMXL.n9Qu.MEYCIQDhPAtDbbu2XbkxR1-HOhIH1IeVNlZuS8c4GKc49brJWwIhAN9RVU79oZ40P9DMW-wU8HAPLIVjxJqei1goZhwvpqo3", "workspace_id": "ws-r0xzoh40vcz25kux"},
                {"key": "sk-ws-H.DMLEHEM.aND5.MEUCIDvUJ0dxtc_TyK5W1bGp_aTmLi6WG7zzS3Ef1sAZimb2AiEA5Gh_36RWvEH9wkLFv40dEmK6F-BmfbjVGWYCIru3I5Q", "workspace_id": "ws-cerh9f2vfvc7xovi"},
            ]:
            client = AlibabaClient()
            client.set_key(key=item["key"], workspace_id=item["workspace_id"] )
            clients.append(client)
            
        return LLMPool(clients, name="medium")
    
    def _build_easy_pool(self) -> LLMPool:
        """Pool nhẹ - dùng cho các tác vụ đơn giản"""
        clients = []
        
        # Ollama (local, nếu có)
        try:
            client = OllamaClient()
            clients.append(client)
        except Exception:
            pass
            
        # Cerebras
        for key in [
            "csk-mkrwvckrernvexvwvh82ww52xte33ct3fp9c4mfcncpej3p8",
            "csk-xhm85jhw66vm2kmexjrfte38yx9dwwjhemh52mdd539pvc39",
            "csk-cyh6cfpyy3hrh3hnrvw6jt3mn6n54dnxtwwxjtr8n3yxr8vf",
            "csk-v4rrvww5856yn9devd4t2ep6dj4dwrtw3djj9hmph54fx3jv",
            "csk-p5cwcy98y4m4d94jk8fej8m6wrw3ymrm5mteetpmrr536n8x",
            "csk-9nvhrmj9nk3m2newkk6emvd5cev6mrexfdfdprfnhnc6mdth",
            "csk-486y9mx6ek55p4445cdkjjtewym6np3n9tf5x9fxrrhft45m",
            "csk-krwfnnd9d423dh4k433mm8ey92hxhyd4r5888wdp39exexnm",
            "csk-h6ecvccn5r4ef836rechw5dvmw6tjc6jmrejfm3vyvr2cfe6",
            "csk-p4y9f4j28cpf236vmrewetcw2n48c8nycfc4493pnkcj2hxh",
            "csk-rn6rhptjy6tnhn5nxe83ewere3x3cwf9cxrc3v2xy494jwn4"
        ]:
            client = CerebrasClient()
            client.set_key(key)
            clients.append(client)
            
        for key in [
            "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",
            "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",
            "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",
            "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",
            "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",
            "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",
            "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",
            "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",
        ]:
            client = OpenrouterClient()
            client.set_key(key)
            clients.append(client)
        
        return LLMPool(clients, name="easy")
    
    def get_client(self, tier: str = "easy") -> LLMClient:
        """
        Lấy một LLM client từ pool tương ứng với tier.
        Nếu pool hiện tại hết client, tự động fallback sang pool khác.
        """
        pool = self.pools.get(tier, self.pools["easy"])
        client = pool.get_next_client()
        
        # Nếu hết client trong pool hiện tại, thử fallback
        if client is None:
            # Reset failures để pool có cơ hội tự phục hồi ở lần gọi
            # get_client(tier) tiếp theo — cùng nguyên tắc đã áp dụng cho
            # generate_with_retry() ở trên, để hàm này (dùng bởi
            # get_llm_client_tiered(), đường gọi riêng, KHÔNG đi qua
            # generate_with_retry()) không bị "cạn vĩnh viễn" tương tự.
            pool.reset_failures()
            fallback_tier = self._fallback_chain.get(tier)
            if fallback_tier:
                logger.warning(f"Pool '{tier}' exhausted, resetting and falling back to '{fallback_tier}'")
                return self.get_client(fallback_tier)
            else:
                # Đã thử tất cả pool, báo lỗi
                raise RuntimeError(f"All LLM pools exhausted for tier '{tier}'")
        
        pool.reset_failures()  # Reset failures cho lần gọi mới
        return client
    
    def generate_with_retry(self, prompt: str, system: Optional[str] = None,
                            json_mode: bool = False, tier: str = "easy",
                            max_retries_per_client: int = 2) -> str:
        """
        Gọi LLM với cơ chế retry tự động.
        - Nếu client hiện tại bị lỗi, thử client tiếp theo trong pool.
        - Nếu hết client trong pool, fallback sang pool khác.
        - Mỗi client được thử tối đa `max_retries_per_client` lần.
        """
        pool = self.pools.get(tier, self.pools["easy"])
        attempted_clients = set()
        
        # Lưu các client đã thử để tránh lặp vô hạn
        all_clients_in_pool = set(pool.clients)
        
        while len(attempted_clients) < len(all_clients_in_pool):
            client = pool.get_next_client()
            if client is None:
                # Hết client trong pool hiện tại. Reset failures NGAY ở đây
                # (không phải trong get_client() — hàm đó KHÔNG nằm trên
                # đường gọi này, generate_with_retry() gọi trực tiếp
                # pool.get_next_client(), không qua self.get_client()) để
                # lần gọi generate_with_retry() TIẾP THEO (kể cả cùng tier
                # này) có cơ hội thử lại từ đầu toàn bộ client, thay vì pool
                # bị coi là "cạn vĩnh viễn" cho tới hết đời process.
                pool.reset_failures()
                fallback_tier = self._fallback_chain.get(tier)
                if fallback_tier:
                    logger.warning(f"Pool '{tier}' exhausted, resetting and falling back to '{fallback_tier}'")
                    return self.generate_with_retry(prompt, system, json_mode, fallback_tier, max_retries_per_client)
                else:
                    # Đã thử tất cả, báo lỗi
                    raise RuntimeError(f"All LLM pools exhausted for tier '{tier}'")
            
            if client in attempted_clients:
                continue
            attempted_clients.add(client)
            
            # Thử client này
            got_empty_after_all_retries = False
            for attempt in range(max_retries_per_client):
                try:
                    result = client.generate(prompt, system, json_mode, tier)
                    if result and result.strip():
                        # Thành công, reset failures và trả về kết quả
                        pool.reset_failures()
                        return result
                    else:
                        logger.warning(f"Client {client.__class__.__name__} returned empty response (attempt {attempt+1})")
                        # Fix Bug 1 — trước đây nhánh "rỗng nhưng không raise
                        # exception" không bao giờ gọi mark_failed(), khiến
                        # get_next_client() (vòng while bên ngoài) tiếp tục
                        # trả về CHÍNH client này (chưa nằm trong
                        # _failed_clients) -> attempted_clients không tăng
                        # -> lặp vô hạn, treo cứng chương trình. Giờ đánh
                        # dấu fail y hệt nhánh exception khi đã hết
                        # max_retries_per_client lần mà vẫn rỗng.
                        if attempt == max_retries_per_client - 1:
                            got_empty_after_all_retries = True
                except Exception as e:
                    logger.error(f"Client {client.__class__.__name__} failed (attempt {attempt+1}): {e}")
                    if attempt == max_retries_per_client - 1:
                        # Đã thử hết số lần cho client này, đánh dấu fail và chuyển client khác
                        pool.mark_failed(client)
                        break
                    # Còn retry, chờ một chút trước khi thử lại
                    import time
                    time.sleep(1 * (attempt + 1))

            if got_empty_after_all_retries:
                pool.mark_failed(client)
        
        # Nếu đến đây mà chưa return, tức là đã thử hết tất cả client trong
        # pool (attempted_clients == all_clients_in_pool). Reset để lần gọi
        # generate_with_retry() tiếp theo không bị coi là "cạn vĩnh viễn" —
        # cùng lý do như điểm reset ở trên (điểm thoát này KHÁC điểm
        # `client is None` phía trên: đây là trường hợp mọi client đều đã
        # được thử, còn kia là get_next_client() trả None giữa chừng).
        pool.reset_failures()
        fallback_tier = self._fallback_chain.get(tier)
        if fallback_tier:
            logger.warning(f"Pool '{tier}' exhausted, resetting and falling back to '{fallback_tier}'")
            return self.generate_with_retry(prompt, system, json_mode, fallback_tier, max_retries_per_client)
        else:
            raise RuntimeError(f"All LLM pools exhausted for tier '{tier}'")
    
    def embed(self, texts: list[str], tier: str = "easy") -> list[list[float]]:
        """Lấy embedding từ bất kỳ client nào trong pool (dùng LocalEmbedder)"""
        # Embedding không phụ thuộc vào provider, dùng LocalEmbedder chung
        from common.llm_client import LocalEmbedder
        return LocalEmbedder.encode(texts)


# Singleton instance
_llm_pool_instance = None

def get_llm_pool() -> LLMClientPool:
    """Lấy singleton instance của LLMClientPool"""
    global _llm_pool_instance
    if _llm_pool_instance is None:
        _llm_pool_instance = LLMClientPool()
    return _llm_pool_instance


# Hàm wrapper để tương thích với code cũ
def get_llm_client_tiered(tier: str = "easy") -> LLMClient:
    """
    Trả về một LLM client từ pool tương ứng.
    Dùng để thay thế các hàm get_objectllm(), get_objectllm1() trong code cũ.
    """
    pool = get_llm_pool()
    return RetryLLMClient(pool, tier)


def generate_with_retry(prompt: str, system: Optional[str] = None,
                        json_mode: bool = False, tier: str = "easy") -> str:
    """
    Wrapper cho generate_with_retry của pool.
    Dùng để thay thế các lệnh gọi llm.generate() trực tiếp.
    """
    pool = get_llm_pool()
    return pool.generate_with_retry(prompt, system, json_mode, tier)
