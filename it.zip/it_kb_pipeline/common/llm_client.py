"""
LLM client abstraction.

Every stage that needs an LLM (A3 cross-ref, A4 extraction, A5 merge, D rerank,
E answer generation) talks to `LLMClient.generate(...)` / `.embed(...)` only —
never to a specific provider SDK. That means swapping providers, or later
moving this file into its own "llm-gateway" microservice behind a REST/gRPC
call, requires touching only this file.

Free / low-cost providers wired in (pick with env var LLM_PROVIDER):

  - "ollama"  : fully free, runs locally (e.g. `ollama pull llama3.1`,
                `ollama pull qwen2.5:7b`). No API key, no rate limit.
                Good default for "light" tier and for offline dev.
  - "groq"    : free tier, very fast (llama-3.1-8b-instant, llama-3.3-70b).
                Needs GROQ_API_KEY.
  - "gemini"  : Google AI Studio free tier (gemini-1.5-flash / gemini-2.0-flash).
                Needs GOOGLE_API_KEY.
  - "mock"    : deterministic offline stub used by tests / demo, no network.

Embeddings: any provider above that exposes an embeddings endpoint can be
used; default is a local sentence-transformers model (also free, no API key)
so B1/B2/D work fully offline.
"""
from __future__ import annotations

import time
import random
from google import genai
from google.genai import types, errors
from gradio_client import Client
import hashlib
import json
import re
import os
import requests 
from json_repair import repair_json
from abc import ABC, abstractmethod
from typing import Optional
from cerebras.cloud.sdk import Cerebras
from .config import settings
import logging

from openai import OpenAI

logger = logging.getLogger(__name__)

def _strip_code_fences(text: str) -> str:
    """Some providers wrap JSON in ```json ... ``` even when asked not to."""
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    return text.strip()

def extract_and_parse_json(raw_string):
    """Trích xuất và chuyển đổi chuỗi thô từ API thành JSON chuẩn (hỗ trợ cả {} và [])."""
    if not raw_string:
        return None

    cleaned = raw_string.strip()

    # Regex mới: Tìm cặp dấu { ... } HOẶC [ ... ] ngoài cùng
    # (\[.*\]|\{.*\}) -> Khớp với chuỗi bắt đầu bằng [ và kết thúc bằng ], hoặc bắt đầu bằng { và kết thúc bằng }
    json_match = re.search(r"(\[.*\]|\{.*\})", cleaned, re.DOTALL)

    if json_match:
        json_string = json_match.group(1).strip()
        try:
            # Chuyển đổi thành Dict hoặc List trong Python
            json_string = repair_json(json_string)
            json_data = json.loads(json_string)
            return json_data
        except json.JSONDecodeError as e:
            print(f"Lỗi cú pháp JSON bên trong chuỗi: {e}")
            # co' 1 vai json loi phai sua cho duowc
            return None
    else:
        print("Lỗi: Không tìm thấy cấu trúc JSON {} hoặc [] hợp lệ trong chuỗi.")
        return None

class LLMClient(ABC):
    @abstractmethod
    def generate(self, prompt: str, system: Optional[str] = None,
                 json_mode: bool = False, tier: str = "light") -> str:
        """Return the raw text completion for `prompt`."""

    @abstractmethod
    def embed(self, texts: list[str]) -> list[list[float]]:
        """Return one embedding vector per input text."""


# -----------------------------------------------------------------------------
# Local embeddings (free, offline) — used regardless of which chat LLM is picked
# -----------------------------------------------------------------------------
class LocalEmbedder:
    _model = None

    @classmethod
    def encode(cls, texts: list[str]) -> list[list[float]]:
        if settings.embedding_mode == "hash":
            return [_hash_embedding(t) for t in texts]
        try:
            from sentence_transformers import SentenceTransformer
            if cls._model is None:
                cls._model = SentenceTransformer("BAAI/bge-m3")
            return cls._model.encode(texts, normalize_embeddings=True).tolist()
        except Exception:
            print(f"loi embedding --------")
            # Deterministic offline fallback so the pipeline still runs without
            # any model download (dev/demo only — NOT semantically meaningful).
            return [_hash_embedding(t) for t in texts]

# class LocalEmbedder:
#     _model = None

#     @classmethod
#     def encode(cls, texts: list[str]) -> list[list[float]]:
#         if settings.embedding_mode == "hash":
#             return [_hash_embedding(t) for t in texts]
#         try:
#             import requests
#             api_url = "https://march42-baai-bge-m3.hf.space/embeddings"
#             headers = {"Content-Type": "application/json"}
#             embeddings = []
#             with requests.Session() as session:
#                 # 2. Lặp qua từng văn bản trong danh sách để gọi API
#                 for text in texts:
#                     payload = {"text": text}
                    
#                     # Gọi API với timeout an toàn (ví dụ: 10 giây)
#                     response = session.post(
#                         api_url, 
#                         json=payload, 
#                         headers=headers, 
#                         timeout=35
#                     )
                    
#                     # Nếu API trả về lỗi (4xx, 5xx), hàm này sẽ raise lỗi để nhảy vào khối except fallback
#                     response.raise_for_status() 
                    
#                     # Giả định response trả về trực tiếp mảng vector: [0.12, -0.45, ...]
#                     # Nếu response bọc trong một key (vd: {"embedding": [...]}), bạn hãy sửa thành response.json()["embedding"]
#                     vector = response.json()
#                     embeddings.append(vector)

#             return embeddings
#         except Exception as e:
#             # Deterministic offline fallback so the pipeline still runs without
#             # any model download (dev/demo only — NOT semantically meaningful).
#             print(f"LocalEmbedder {e}")
#             return [_hash_embedding(t) for t in texts]



def _hash_embedding(text: str, dim: int = 768) -> list[float]:
    h = hashlib.sha256(text.encode("utf-8")).digest()
    vals = []
    while len(vals) < dim:
        h = hashlib.sha256(h).digest()
        vals.extend([b / 255.0 for b in h])
    return vals[:dim]

# -----------------------------------------------------------------------------
# cerebras — free, local
# -----------------------------------------------------------------------------
class CerebrasClient(LLMClient):
    def __init__(self):
        self.api_key = settings.cerebras_api_key
        
        self.base_url = settings.cerebras_base_url
        self.model_light = settings.cerebras_model_light
        self.model_strong = settings.cerebras_model_strong

    def set_key(self, key: str):
        """Hàm dùng để thiết lập hoặc thay đổi API key."""
        self.api_key = key
        self._requests = Cerebras(
            api_key=self.api_key,
        )

    def generate(self, prompt, system=None, json_mode=False, tier="light"):
        """
        Gọi LLM qua OpenAI-compatible endpoint trên Hugging Face Space
        """
        
        model = self.model_light if tier == "light" else self.model_strong
        print("CerebrasClient llm")
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        try:
            chat_completion = self._requests.chat.completions.create(
                messages=messages,
                model=model,
            )
            # print(chat_completion.choices[0].message.content)
            return chat_completion.choices[0].message.content

        except Exception as e:
            if 'r' in locals():
                print(f"Response: {r.text[:800]}")
            return ""

    def embed(self, texts):
        return LocalEmbedder.encode(texts)

# -----------------------------------------------------------------------------
# Ollama — free, local
# -----------------------------------------------------------------------------
class OllamaClient(LLMClient):
    def __init__(self):
        import requests  # local import so the dependency is optional
        self._requests = requests
        self.base_url = settings.ollama_base_url
        self.model_light = settings.ollama_model_light
        self.model_strong = settings.ollama_model_strong

    def generate(self, prompt, system=None, json_mode=False, tier="light"):
        """
        Gọi LLM qua OpenAI-compatible endpoint trên Hugging Face Space
        """
        model = self.model_light if tier == "light" else self.model_strong
        print("OllamaClient llm")
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        # print("prompt-------")
        # print(f"{messages}")
        # print("-------")
        payload = {
           "model":model,
            "messages": messages,
            "chat_template_kwargs": {
                "enable_thinking": False
            },
            "reasoning_control": True,
            "stream": False,
        }

        if json_mode:
            payload["response_format"] = {"type": "json_object"}

        try:

            r = self._requests.post(
                f"{self.base_url}/v1/chat/completions",
                json=payload,
                timeout=380,           # Tăng timeout vì HF Space có thể chậm
                headers={"Content-Type": "application/json"}
            )

            r.raise_for_status()
            response = r.json()
            content = response["choices"][0]["message"]["content"]
            # print("rs-------")
            # print(content)
            return content

        except Exception as e:
        
            if 'r' in locals():
                print(f"Response: {r.text[:800]}")
            return ""

    def embed(self, texts):
        return LocalEmbedder.encode(texts)


# -----------------------------------------------------------------------------
# Groq — free tier, OpenAI-compatible API
# -----------------------------------------------------------------------------
class GroqClient(LLMClient):
    def __init__(self):
        import requests
        self._requests = requests
        self.api_key = settings.groq_api_key
        self.model_light = settings.groq_model_light
        self.model_strong = settings.groq_model_strong

    def set_key(self, key: str):
        """Hàm dùng để thiết lập hoặc thay đổi API key."""
        self.api_key = key

    def generate(self, prompt, system=None, json_mode=False, tier="light"):
        model = self.model_strong if tier == "strong" else self.model_light
        messages = []
        print("GroqClient llm")
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        # print("prompt-------")
        # print(f"{messages}")
        # print("-------")
        body = {"model": model, "messages": messages, "temperature": 0.1}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        r = self._requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json=body, timeout=60,
        )
        r.raise_for_status()
        rs = r.json()["choices"][0]["message"]["content"]
        # print("rs-------")
        # print(rs)
        return rs

    def embed(self, texts):
        return LocalEmbedder.encode(texts)  # Groq has no embeddings endpoint


# -----------------------------------------------------------------------------
# Gemini — Google AI Studio free tier
# -----------------------------------------------------------------------------
RETRYABLE = {429, 500, 503, 504}
class GeminiClient(LLMClient):
    def __init__(self):
        
        self.model_light = settings.gemini_model_light
        self.model_strong = settings.gemini_model_strong
        self.models_light = [
            settings.gemini_model_light,   # vd: "gemini-3.5-flash-lite"
            "gemini-3.6-flash",
            "gemini-2.5-flash-lite",
            "gemini-3.1-flash-lite",
            "lyria-3-pro-preview"
        ]
        self.models_strong = [
            settings.gemini_model_strong,  # vd: "gemini-3.6-flash"
            "gemini-3.1-pro-preview",
            "gemini-3.6-flash-lite",
            "gemini-3.1-flash-lite",
            "lyria-3-pro-preview"
        ]

    def set_key(self, key: str):
        """Hàm dùng để thiết lập hoặc thay đổi API key."""
        self.api_key = key
        self.client = genai.Client(api_key=key)

    def generate(self, prompt, system=None, json_mode=False, tier="light",
                 max_retries_per_model=3):
        models = self.models_strong if tier == "strong" else self.models_light
        # loại bỏ trùng lặp nhưng vẫn giữ thứ tự
        models = list(dict.fromkeys(models))
        print(f"GeminiClient llm {self.api_key}")
        config = types.GenerateContentConfig(
            system_instruction=system if system else None,
            response_mime_type="application/json" if json_mode else None,
        )

        last_error = None

        for model in models:
            for attempt in range(max_retries_per_model):
                try:
                    print(f"dang dung model {model}")
                    response = self.client.models.generate_content(
                        model=model,
                        contents=prompt,
                        config=config,
                    )
                    if not response.candidates:
                        reason = getattr(response.prompt_feedback, "block_reason", "unknown")
                        raise RuntimeError(f"Model {model} không trả về candidate, blockReason={reason}")

                    if model != models[0]:
                        print(f"[GeminiClient] Đã fallback sang model: {model}")
                    return response.text

                except errors.ServerError as e:
                    # 500/503 -> lỗi tạm thời của model này, thử lại vài lần
                    last_error = e
                    if attempt < max_retries_per_model - 1:
                        delay = min(2 ** attempt, 15) + random.uniform(0, 1)
                        print(f"[GeminiClient] Model {model} lỗi {getattr(e, 'code', '?')}, "
                              f"thử lại sau {delay:.1f}s (attempt {attempt + 1})")
                        time.sleep(delay)
                        continue
                    # hết lượt retry cho model này -> break để sang model kế tiếp
                    print(f"[GeminiClient] Model {model} vẫn lỗi sau {max_retries_per_model} lần, "
                          f"chuyển sang model tiếp theo")
                    break

                except errors.ClientError as e:
                    status = getattr(e, "code", None)
                    if status == 429 and attempt < max_retries_per_model - 1:
                        # rate limit -> vẫn đáng thử lại model này trước khi bỏ
                        delay = min(2 ** attempt, 15) + random.uniform(0, 1)
                        time.sleep(delay)
                        continue
                    if status == 429:
                        # hết lượt cho model này -> sang model kế tiếp
                        last_error = e
                        break
                    # 400/401/403/404 -> lỗi cấu hình/model không tồn tại, không đáng retry
                    # nhưng vẫn có thể do model này không available -> thử model kế tiếp
                    last_error = e
                    break

        # Thử hết toàn bộ model trong danh sách mà vẫn lỗi
        raise RuntimeError(
            f"Tất cả model ({models}) đều lỗi. Lỗi cuối cùng: {last_error}"
        ) from last_error

    def embed(self, texts):
        return LocalEmbedder.encode(texts)

#---------------

# ------------------
class OpenrouterClient(LLMClient):
    def __init__(self):
        import requests
        self._requests = requests
        self.api_key = settings.openrouter_api_key          # API key của bạn
        self.model_light = settings.openrouter_model_light  # model nhẹ, VD: "openai/gpt-3.5-turbo"
        self.model_strong = settings.openrouter_model_strong # model mạnh, VD: "nvidia/nemotron-3-ultra-550b-a55b:free"

    def set_key(self, key: str):
        """Hàm dùng để thiết lập hoặc thay đổi API key."""
        self.api_key = key

    def generate(self, prompt, system=None, json_mode=False, tier="light"):
        model = self.model_strong if tier == "strong" else self.model_light
        messages = []
        print("OpenrouterClient llm")
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        body = {"model": model, "messages": messages, "temperature": 0.1}

        # Nếu cần JSON mode, bật response_format giống OpenAI
        if json_mode:
            body["response_format"] = {"type": "json_object"}

        # Nếu bạn muốn bật reasoning như trong ví dụ, có thể thêm:
        # body["reasoning"] = {"enabled": True}

        r = self._requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            },
            json=body,
            timeout=60,
        )
        r.raise_for_status()
        rs = r.json()["choices"][0]["message"]["content"]
        return rs

    def embed(self, texts):
        return LocalEmbedder.encode(texts)

# -----------

class HuggingFaceClient(LLMClient):
    """Client cho HuggingFace Inference API (qua router)."""

    def __init__(self):

        self.model_light = settings.hf_model_light  # Ví dụ: "Qwen/Qwen2.5-VL-7B-Instruct"
        self.model_strong = settings.hf_model_strong  # Có thể giống hoặc khác

    def set_key(self, key: str):
        """Hàm dùng để thiết lập hoặc thay đổi API key."""
        self.api_key = key
        self.client = OpenAI(
            base_url="https://router.huggingface.co/v1",
            api_key=key,  # Cần có trong settings
        )

    def generate(
        self,
        prompt: str,
        system: Optional[str] = None,
        json_mode: bool = False,
        tier: str = "light",
    ) -> str:
        """
        Gửi prompt tới HuggingFace Router và trả về nội dung phản hồi.
        """
        model = self.model_strong if tier == "strong" else self.model_light
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        
        print("HuggingFaceClient llm")

        kwargs = {
            "model": model,
            "messages": messages,
            "temperature": 0.1,
        }
        # Một số model trên HF hỗ trợ response_format, nhưng không bắt buộc
        if json_mode:
            kwargs["response_format"] = {"type": "json_object"}

        try:
            response = self.client.chat.completions.create(**kwargs)
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"HuggingFace generation failed: {e}")
            return ""

    def embed(self, texts: list[str]) -> list[list[float]]:
        """
        Sử dụng LocalEmbedder để tạo embedding (giống các client khác).
        """
        return LocalEmbedder.encode(texts)

# -----------------------------------------------------------------------------



class AlibabaClient(LLMClient):

    def set_key(self, key: str , workspace_id: str):
        """Hàm dùng để thiết lập hoặc thay đổi API key."""
        self.api_key = key
        self.base_url = f"https://{workspace_id}.ap-southeast-1.maas.aliyuncs.com/compatible-mode/v1"
        
        self.client = OpenAI(
            api_key=key,
            base_url=self.base_url,
            timeout=60.0,          # Timeout tổng (giây)
            max_retries=3,   
        )

    def __init__(self):
        self.model_light = settings.alibaba_model_light or "qwen-plus"
        self.model_strong = settings.alibaba_model_strong or "qwen-max"

    def generate(self, prompt: str, system: Optional[str] = None,
                 json_mode: bool = False, tier: str = "light") -> str:
        model = self.model_strong if tier == "strong" else self.model_light
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        print("AlibabaClient llm")
        extra_body = {}
        if json_mode:
            extra_body["response_format"] = {"type": "json_object"}

        try:
            completion = self.client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=0.1,
                extra_body=extra_body if extra_body else None,
            )
            return completion.choices[0].message.content
        except Exception as e:
            # Có thể log và raise, hoặc retry tùy ý
            raise RuntimeError(f"Alibaba API call failed: {e}") from e

    def embed(self, texts: list[str]) -> list[list[float]]:
        # Sử dụng LocalEmbedder (hoặc có thể gọi embedding API riêng nếu có)
        return LocalEmbedder.encode(texts)

# --------------------------

class CloudflareClient(LLMClient):

    def embed(self, texts: list[str]) -> list[list[float]]:
        """
        Sử dụng LocalEmbedder để tạo embedding (giống các client khác).
        """
        return LocalEmbedder.encode(texts)

    def __init__(self):
        import requests
        self._requests = requests
        self.account_id = settings.cloudflare_account_id
        self.api_token = settings.cloudflare_api_token
        # Các model theo định dạng "author/model" (ví dụ: "google/gemini-3.5-flash-lite")
        self.model_light = settings.cloudflare_model_light
        self.model_strong = settings.cloudflare_model_strong
        self.base_url = "https://api.cloudflare.com/client/v4/accounts"


    def set_key(self, key: str ,account_id: str ):
        """Hàm dùng để thiết lập hoặc thay đổi API key."""
        self.api_token = key
        self.account_id = account_id

    def generate(self, prompt, system=None, json_mode=False, tier="light"):
        model = self.model_strong if tier == "strong" else self.model_light
        url = f"{self.base_url}/{self.account_id}/ai/run/{model}"
        headers = {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json",
        }
        print("CloudflareClient llm")
        # Xây dựng payload theo định dạng Cloudflare
        if system:
            messages = [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ]
            payload = {"messages": messages}
        else:
            payload = {"prompt": prompt}

        # Cloudflare hiện chưa hỗ trợ json_mode, nhưng giữ tham số để tương thích
        # Có thể thêm vào payload nếu Cloudflare cập nhật sau này

        try:
            r = self._requests.post(url, headers=headers, json=payload, timeout=60)
            r.raise_for_status()
            data = r.json()
            if not data.get("success", False):
                errors = data.get("errors", [])
                raise RuntimeError(f"Cloudflare API error: {errors}")
            return data["result"]["response"]
        except Exception as e:
            raise RuntimeError(f"Cloudflare API request failed: {e}")

# -----------------------------------------------------------------------------
class MistralClient(LLMClient):

    def set_key(self, key: str ):
        """Hàm dùng để thiết lập hoặc thay đổi API key."""
        self.api_key = key

    def __init__(self):
        import requests
        self._requests = requests
        self.model_light = settings.mistral_model_light
        self.model_strong = settings.mistral_model_strong

    def generate(self, prompt, system=None, json_mode=False, tier="light"):
        model = self.model_strong if tier == "strong" else self.model_light
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        print("MistralClient llm")
        body = {
            "model": model,
            "messages": messages,
            "temperature": 0.1
        }
        # Mistral hỗ trợ response_format cho một số model (ví dụ: "mistral-large")
        if json_mode:
            body["response_format"] = {"type": "json_object"}

        try:
            r = self._requests.post(
                "https://api.mistral.ai/v1/chat/completions",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json=body,
                timeout=60,
            )
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]
        except Exception as e:
            # Ghi log hoặc raise lại
            raise RuntimeError(f"Mistral API call failed: {e}") from e

    def embed(self, texts):
        # Sử dụng LocalEmbedder (giống như GeminiClient)
        return LocalEmbedder.encode(texts)

# -------------------
class AionLabsClient(LLMClient):
    def set_key(self, key: str ):
        """Hàm dùng để thiết lập hoặc thay đổi API key."""
        self.api_key = key

    def __init__(self):
        import requests
        self._requests = requests
        self.model_light = settings.aion_model_light
        self.model_strong = settings.aion_model_strong

    def generate(
        self,
        prompt: str,
        system: Optional[str] = None,
        json_mode: bool = False,
        tier: str = "light",
        temperature: float = 0.1,
        max_tokens: int = 4096,
    ) -> str:
        """
        Send a chat completion request to AionLabs.
        Supports system prompt and optional JSON mode.
        """
        model = self.model_strong if tier == "strong" else self.model_light
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        print("AionLabsClient llm")
        body = {
            "model": model,
            "messages": messages,
            "temperature": temperature
        }
        if json_mode:
            # AionLabs likely supports response_format (OpenAI-compatible)
            body["response_format"] = {"type": "json_object"}

        try:
            r = self._requests.post(
                "https://api.aionlabs.ai/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json=body,
                timeout=60,
            )
            r.raise_for_status()
            data = r.json()
            return data["choices"][0]["message"]["content"]
        except Exception as e:
            logger.error(f"AionLabs API call failed: {e}")
            # Re-raise or return empty string depending on error handling strategy
            raise

    def embed(self, texts: list[str]) -> list[list[float]]:
        """
        Embeddings using local embedder (free/offline).
        AionLabs might not provide embeddings, so we use the same as other clients.
        """
        return LocalEmbedder.encode(texts)

# ---------------------

class ZaiClient(LLMClient):

    def embed(self, texts: list[str]) -> list[list[float]]:
        """
        Sử dụng LocalEmbedder để tạo embedding (giống các client khác).
        """
        return LocalEmbedder.encode(texts)

    def set_key(self, key: str ):
        """Hàm dùng để thiết lập hoặc thay đổi API key."""
        self.api_key = key

    def __init__(self):
        import requests
        self._requests = requests
        
        self.model_light = settings.zai_model_light  # vd: "GLM-4.7-Flash"
        self.model_strong = settings.zai_model_strong

    def generate(
        self,
        prompt: str,
        system: Optional[str] = None,
        json_mode: bool = False,
        tier: str = "light"
    ) -> str:
        model = self.model_strong if tier == "strong" else self.model_light
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        print("ZaiClient llm")
        body = {
            "model": model,
            "messages": messages,
            "temperature": 0.1,
            "thinking": {
                "type": "disabled"
            }
        }
        if json_mode:
            body["response_format"] = {"type": "json_object"}

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept-Language": "en-US,en",
        }

        r = self._requests.post(
            "https://api.z.ai/api/paas/v4/chat/completions",
            headers=headers,
            json=body,
            timeout=60,
        )
        r.raise_for_status()
        data = r.json()
        content = data["choices"][0]["message"].get("content", "")
        # Nếu server vẫn gửi reasoning_content, ta không dùng nó
        return content

# -----------------------------------------------------------------------------
class OllamaCloudClient(LLMClient):

    def set_key(self, key: str ):
        """Hàm dùng để thiết lập hoặc thay đổi API key."""
        self.api_key = key
        self._session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        })


    def __init__(self):
        
        self.model_light = settings.ollama_model_cloud_light  # e.g. "gpt-oss:20b"
        self.model_strong = settings.ollama_model_cloud_strong  # optionally different
        self.base_url = settings.ollama_cloud_base_url or "https://ollama.com/api/chat"
        self._session = requests.Session()
        

    def generate(
        self,
        prompt: str,
        system: Optional[str] = None,
        json_mode: bool = False,
        tier: str = "light"
    ) -> str:
        """
        Send a chat completion request to Ollama Cloud.

        Args:
            prompt: User's message.
            system: Optional system instruction (will be prepended as a system message).
            json_mode: If True, we attempt to ask the model to output JSON.
                       (Ollama does not have native JSON mode; we add a system instruction.)
            tier: "light" or "strong" – selects the model.

        Returns:
            The assistant's response as a string.
        """
        model = self.model_strong if tier == "strong" else self.model_light
        print("OllamaCloudClient llm")
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        # If JSON mode is requested, we add an explicit instruction.
        # You can also try adding "format": "json" if the API supports it,
        # but Ollama Cloud's /api/chat does not currently accept that field.
        if json_mode:
            # Append a system-like instruction to the user message or as a separate system message
            messages.append({
                "role": "system",
                "content": "You must respond with valid JSON only. Do not include any extra text."
            })

        payload = {
            "model": model,
            "messages": messages,
            "stream": False,
            # Optionally adjust temperature
            "temperature": 0.1,
        }

        try:
            resp = self._session.post(self.base_url, json=payload, timeout=60)
            resp.raise_for_status()
            data = resp.json()

            # Ollama /api/chat returns: {"message": {"role": "assistant", "content": "..."}}
            # Some versions may return just "response" field; we handle both.
            if "message" in data and "content" in data["message"]:
                return data["message"]["content"]
            elif "response" in data:
                return data["response"]
            else:
                # Fallback: try to extract any text
                return data.get("content", str(data))
        except requests.exceptions.RequestException as e:
            # Log or re-raise as needed
            raise RuntimeError(f"OllamaCloud API request failed: {e}") from e

    def embed(self, texts: list[str]) -> list[list[float]]:
        """
        Sử dụng LocalEmbedder để tạo embedding (giống các client khác).
        """
        return LocalEmbedder.encode(texts)

# -----------------------------------------------------------------------------
_PROVIDER_CLASSES = {
    "ollama": OllamaClient,
    "groq": GroqClient,
    "gemini": GeminiClient,
    "cerebras": CerebrasClient
}


def _build_client(provider: str) -> LLMClient:
    return _PROVIDER_CLASSES.get(provider)()


class TieredLLMClient(LLMClient):
    """Routes `tier="light"` and `tier="strong"` calls to (optionally)
    different provider clients.

    Root-cause fix: both `ollama_base_url` and `cerebras_base_url` in
    config.py point at the same small Gemma-3 1B demo endpoint, so every
    multi-hop reasoning call that's supposed to use the "strong" tier (A3
    cross-reference detection, A4's LLM-review arbitration, A5 global
    merge) was silently getting the same 1B model as cheap "light" calls
    like per-sentence extraction. Setting STRONG_TIER_PROVIDER (e.g. "groq"
    or "gemini") in the environment routes tier="strong" to that provider's
    client instead, with zero changes needed in any stage — they all just
    call `llm.generate(..., tier="strong")` already.
    """

    def __init__(self, light_client: LLMClient, strong_client: LLMClient):
        self._light = light_client
        self._strong = strong_client

    def generate(self, prompt: str, system: Optional[str] = None,
                 json_mode: bool = False, tier: str = "light") -> str:
        client = self._strong if tier == "strong" else self._light
        return client.generate(prompt, system=system, json_mode=json_mode, tier=tier)

    def embed(self, texts: list[str]) -> list[list[float]]:
        # Embeddings are provider-agnostic here (LocalEmbedder underneath
        # every client) — just delegate to the light client.
        return self._light.embed(texts)


def get_llm_client() -> LLMClient:
    light = _build_client(settings.llm_provider)
    strong_provider = settings.strong_tier_provider or settings.llm_provider
    if strong_provider == settings.llm_provider:
        return light
    return TieredLLMClient(light, _build_client(strong_provider))


# Khởi tạo Client bên ngoài hàm (hoặc bên trong tùy kiến trúc ứng dụng của bạn)
# Việc để ngoài giúp tránh khởi tạo lại kết nối mạng liên tục mỗi khi gọi hàm
try:
    gradio_rerank_client = Client("militarybearz/bge")
except Exception as e:
    logger.warning("Không thể kết nối tới Gradio Rerank API: %s", e)
    gradio_rerank_client = None

_RERANK_IDX_RE = re.compile(r"@@IDX_(\d+)@@")
_RERANK_SCORE_OR_IDX_RE = re.compile(r"\(Score:\s*([-\d.]+)\)|@@IDX_(\d+)@@")

def rerank(query_text: str, candidates: list[RetrievedCandidate], top_k: int) -> list[RetrievedCandidate]:
    """D.5 — cross-encoder reranker sử dụng Gradio API từ Hugging Face Space.

    FIX (xem phan_tich_it_kb_pipeline.md mục 5/2): xem docstring/comment
    trong khối try bên dưới — 2 lỗi chính đã sửa: (1) newline nội tại của
    từng candidate làm vỡ ranh giới document khi join bằng "\n", (2) match
    kết quả trả về bằng so-sánh-chuỗi-y-hệt khiến candidate dài dễ rơi vào
    fallback -99.0 một cách oan uổng.
    """
    if not candidates:
        return []
    if gradio_rerank_client is None:
        logger.warning("Gradio rerank client không sẵn sàng, giữ nguyên thứ tự/điểm hiện có.")
        return candidates[:top_k]

    # Điểm gốc (dense/RRF) trước khi rerank — dùng làm fallback CHO TỪNG
    # candidate nếu nó không match được kết quả trả về, thay vì ép về -99.0.
    fallback_scores = {id(c): c.relevance_score for c in candidates}

    try:
        # 1. Chuẩn bị văn bản: khử newline NỘI TẠI của từng candidate thành
        #    space trước khi join, để "\n" chỉ còn đóng vai trò ranh giới
        #    giữa các candidate (không bị nhầm với newline bên trong 1
        #    candidate, ví dụ parent chunk = breadcrumb + "\n" + body).
        #    Gắn marker "@@IDX_i@@" duy nhất vào đầu mỗi candidate để tra
        #    cứu lại kết quả theo VỊ TRÍ thay vì theo nội dung text.
        tagged_docs = []
        for i, c in enumerate(candidates):
            flat_text = " ".join(c.raw.strip().split())
            tagged_docs.append(f"@@IDX_{i}@@ {flat_text}")
        documents = "\n".join(tagged_docs)

        # 2. Gọi API Gradio (lấy điểm cho TOÀN BỘ candidate, tự cắt top_k
        #    ở bước 6 sau khi đã sort theo điểm thật — tránh Space tự ý bỏ
        #    bớt candidate trước khi ta kịp gán điểm ngược lại).
        api_response = gradio_rerank_client.predict(
            query_text,
            documents,
            top_k=len(candidates),
		    api_name="/gradio_rerank"
        )

        # 3. Lấy chuỗi chứa danh sách kết quả (phần tử số 0 của tuple trả về)
        text_data = api_response[0]

        # 4. Duyệt tuần tự qua text trả về: mỗi khi gặp "(Score: x)" thì nhớ
        #    lại điểm hiện hành, khi gặp "@@IDX_i@@" thì gán điểm hiện hành
        #    đó cho candidate thứ i. Không phụ thuộc việc Space có giữ
        #    nguyên định dạng block/markdown hay không — chỉ cần Score xuất
        #    hiện trước marker của item đó trong luồng text, đúng như cách
        #    Space vốn hiển thị "**n. (Score: x)**\n <nội dung>".
        score_by_idx: dict[int, float] = {}
        current_score: Optional[float] = None
        for m in _RERANK_SCORE_OR_IDX_RE.finditer(text_data):
            if m.group(1) is not None:
                current_score = float(m.group(1))
            elif m.group(2) is not None and current_score is not None:
                score_by_idx[int(m.group(2))] = current_score

        if not score_by_idx:
            # Không parse được marker nào -> định dạng response không như kỳ
            # vọng. Giữ nguyên thứ tự/điểm cũ thay vì ép toàn bộ về -99.0.
            logger.warning("Rerank API trả về nhưng không parse được marker nào, giữ nguyên thứ tự cũ.")
            return candidates[:top_k]

        unmatched = 0
        for i, c in enumerate(candidates):
            if i in score_by_idx:
                c.relevance_score = score_by_idx[i]
            else:
                # Không tìm thấy marker của candidate này trong response
                # (ví dụ Space cắt bớt do quá dài) -> giữ điểm dense/RRF gốc
                # thay vì -99.0, để nó vẫn còn cơ hội qua được các bước lọc
                # phía sau thay vì bị loại oan.
                unmatched += 1
        if unmatched:
            logger.info("Rerank: %d/%d candidate không match được marker, giữ điểm gốc cho các candidate đó.",
                        unmatched, len(candidates))

        candidates = sorted(candidates, key=lambda c: c.relevance_score, reverse=True)

    except Exception as e:
        # Nếu API lỗi: khôi phục đúng điểm gốc (đề phòng lỗi xảy ra giữa
        # chừng, sau khi một phần candidate đã bị ghi đè điểm) rồi fallback
        # về thứ tự RRF/dense cũ.
        print("Gradio API rerank lỗi, fallback về điểm/thứ tự trước rerank: %s", e)
        for c in candidates:
            c.relevance_score = fallback_scores[id(c)]

    return candidates[:top_k]