"""
Shared text canonicalization.

Both A3.5 (section hashing) and A4 (verbatim/fuzzy verification) need to
decide whether two pieces of text are "the same content" — but for
different purposes, so they get two different functions rather than one
that's a compromise for both:

  - `normalize_for_comparison` (used by A4, and A5's evidence check) is
    aggressive: NFC-fold, lowercase, strip punctuation/markdown noise down
    to bare tokens. Meant to feed rapidfuzz, where we WANT surface noise
    (bullets, **bold**, extra punctuation, case) to stop mattering.

  - `normalize_for_hashing` (used by A3.5) is deliberately gentler: it only
    removes normalization-form / whitespace drift that different parser
    runs introduce for a document whose content hasn't actually changed
    (NFC vs NFD diacritics, `\r\n` vs `\n`, incidental trailing spaces). It
    does NOT lowercase or strip punctuation, because a genuine edit to a
    section (a changed number, a flipped comparison operator, a
    case-sensitive constant) must still change the hash — that's the one
    thing A3.5 exists to detect.
"""
from __future__ import annotations

import re
import unicodedata


def normalize_for_comparison(text: str) -> str:
    """Canonicalize before any exact/fuzzy comparison (A4.verify_element,
    A5._verify_evidence). NFC-normalizes Vietnamese/other diacritics so a
    precomposed and a combining-mark encoding of the same visible text
    compare equal, then lowercases and collapses everything that isn't a
    unicode letter/digit into single spaces (markdown emphasis markers,
    punctuation runs, bullets, backticks, pipes, ...)."""
    if not text:
        return ""
    text = unicodedata.normalize("NFC", text)
    text = text.strip().lower()
    text = re.sub(r"[^\w\s]|_", " ", text, flags=re.UNICODE)
    return re.sub(r"\s+", " ", text).strip()


def normalize_for_hashing(text: str) -> str:
    """Canonicalize before SHA-256 hashing (A3.5). Only removes encoding /
    whitespace noise that isn't a real content change; case and punctuation
    are left intact on purpose so a real edit still flips the hash."""
    if not text:
        return ""
    text = unicodedata.normalize("NFC", text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)          # collapse intra-line whitespace runs
    text = re.sub(r"[ \t]+\n", "\n", text)        # drop trailing spaces before newlines
    text = re.sub(r"\n{3,}", "\n\n", text)        # collapse 3+ blank lines to 1
    return text.strip()
