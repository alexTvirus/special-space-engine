import os
from dataclasses import dataclass


@dataclass
class Settings:
    # --- Postgres (Storage Layer C) ---
    database_url: str = os.getenv(
        "DATABASE_URL", "postgresql://postgres:postgres@127.0.0.1:5432/it_kb"
    )
       # Fail fast instead of hanging forever on a dead connection or a lock
    # held by a stuck/killed previous run. Override via env if a query
    # legitimately needs more time (e.g. bulk backfill).
    db_connect_timeout_seconds: int = int(os.getenv("DB_CONNECT_TIMEOUT_SECONDS", "10"))
    db_statement_timeout_ms: int = int(os.getenv("DB_STATEMENT_TIMEOUT_MS", "30000"))


    # --- LLM provider selection: mock | ollama | groq | gemini | cerebras---
    llm_provider: str = os.getenv("LLM_PROVIDER", "ollama")

    openrouter_api_key: str = os.getenv("openrouter_API_KEY", "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")
    openrouter_model_light: str = os.getenv("GROQ_MODEL_LIGHT", "meta-llama/llama-3.2-1b-instruct")
    openrouter_model_strong: str = os.getenv("GROQ_MODEL_STRONG", "meta-llama/llama-3.2-1b-instruct")

    openrouter_api_key1: str = os.getenv("openrouter_API_KEY", "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")
    openrouter_model_light: str = os.getenv("GROQ_MODEL_LIGHT", "meta-llama/llama-3.2-1b-instruct")
    openrouter_model_strong: str = os.getenv("GROQ_MODEL_STRONG", "meta-llama/llama-3.2-1b-instruct")
    # nvidia/nemotron-3-super-120b-a12b:free

    openrouter_api_key2: str = os.getenv("openrouter_API_KEY", "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")
    openrouter_model_light: str = os.getenv("GROQ_MODEL_LIGHT", "meta-llama/llama-3.2-1b-instruct")
    openrouter_model_strong: str = os.getenv("GROQ_MODEL_STRONG", "meta-llama/llama-3.2-1b-instruct")


     # cerebras (free, local)
    cerebras_base_url: str = os.getenv("cerebras_BASE_URL", "")
    cerebras_model_light: str = os.getenv("cerebras_MODEL_LIGHT", "gemma-4-31b")
    cerebras_model_strong: str = os.getenv("cerebras_MODEL_STRONG", "gemma-4-31b")
    cerebras_api_key: str = os.getenv("cerebras_API_KEY", "csk-mkrwvckrernvexvwvh82ww52xte33ct3fp9c4mfcncpej3p8")

    # Ollama (free, local)
    ollama_base_url: str = os.getenv("OLLAMA_BASE_URL", "https://dumamai-gemma-3-1b-it.hf.space")
    ollama_model_light: str = os.getenv("OLLAMA_MODEL_LIGHT", "llama3.1:8b")
    ollama_model_strong: str = os.getenv("OLLAMA_MODEL_STRONG", "qwen2.5:32b")

    ollama_cloud_base_url: str = "https://ollama.com/api/chat"
    ollama_model_cloud_light: str = "gpt-oss:20b"
    ollama_model_cloud_strong: str = "gpt-oss:20b"

    mistral_api_key = os.getenv("MISTRAL_API_KEY", "")
    mistral_model_light = os.getenv("MISTRAL_MODEL_LIGHT", "ministral-3b-2512")   # hoặc model phù hợp
    mistral_model_strong = os.getenv("MISTRAL_MODEL_STRONG", "ministral-3b-2512") # hoặc model mạnh hơn

    zai_api_key = os.getenv("MISTRAL_API_KEY", "")
    zai_model_light = os.getenv("MISTRAL_MODEL_LIGHT", "GLM-4.7-Flash")   # hoặc model phù hợp
    zai_model_strong = os.getenv("MISTRAL_MODEL_STRONG", "GLM-4.7-Flash") # hoặc model mạnh hơn

    aion_api_key: str = os.getenv("AION_API_KEY", "")  # hoặc để trống
    aion_model_light: str = "aion-labs/aion-3.0"
    aion_model_strong: str = "aion-labs/aion-3.0"

    # Groq (free tier)
    groq_api_key: str = os.getenv("GROQ_API_KEY", "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")
    groq_model_light: str = os.getenv("GROQ_MODEL_LIGHT", "llama-3.1-8b-instant")
    groq_model_strong: str = os.getenv("GROQ_MODEL_STRONG", "llama-3.3-70b-versatile")

      # Groq (free tier)
    groq_api_key2: str = os.getenv("GROQ_API_KEY", "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")
    groq_model_light2: str = os.getenv("GROQ_MODEL_LIGHT", "llama-3.1-8b-instant")
    groq_model_strong2: str = os.getenv("GROQ_MODEL_STRONG", "llama-3.3-70b-versatile")

      # Groq (free tier)
    groq_api_key3: str = os.getenv("GROQ_API_KEY", "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")
    groq_model_light3: str = os.getenv("GROQ_MODEL_LIGHT", "llama-3.1-8b-instant")
    groq_model_strong3: str = os.getenv("GROQ_MODEL_STRONG", "llama-3.3-70b-versatile")

    groq_api_key4: str = os.getenv("GROQ_API_KEY", "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")
    groq_model_light4: str = os.getenv("GROQ_MODEL_LIGHT", "llama-3.1-8b-instant")
    groq_model_strong4: str = os.getenv("GROQ_MODEL_STRONG", "llama-3.3-70b-versatile")

    # Gemini (Google AI Studio free tier) li35
    google_api_key: str = os.getenv("GOOGLE_API_KEY", "AQ.Ab8RN6KAiSW-HPAF1F7kjMT6ppzn_b9mkxlAs1WyrrwUcR1G8w")
    gemini_model_light: str = os.getenv("GEMINI_MODEL_LIGHT", "gemini-3.5-flash")
    gemini_model_strong: str = os.getenv("GEMINI_MODEL_STRONG", "gemini-3.5-flash-lite")

     # Gemini (Google AI Studio free tier) p10
    google_api_key1: str = os.getenv("GOOGLE_API_KEY", "AQ.Ab8RN6L3kNC4onmtdJ7AmOm7CKl6TayJ4yA_YrxvK3WT-8CiAA")
    gemini_model_light1: str = os.getenv("GEMINI_MODEL_LIGHT", "gemini-3.5-flash")
    gemini_model_strong1: str = os.getenv("GEMINI_MODEL_STRONG", "gemini-3.5-flash-lite")

    # AQ.Ab8RN6Kc91MkNjv5tJi-F128WBCSVs4M3T9tUndKgVehSjyjhw
   
    google_api_key2: str = os.getenv("GOOGLE_API_KEY", "AQ.Ab8RN6Kc91MkNjv5tJi-F128WBCSVs4M3T9tUndKgVehSjyjhw")

    hf_token="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"
    hf_model_light="Qwen/Qwen3-Coder-480B-A35B-Instruct"
    hf_model_strong="Qwen/Qwen3-Coder-480B-A35B-Instruct"

    cloudflare_account_id ="be9f4d8e6e32b5db14e7f41424c51cae"
    cloudflare_api_token ="cfut_SNmu13EO4A3ivczBpkA2mNwA3S6wcyNINhYlkIBr4837a3b6"
    cloudflare_model_light ="@cf/meta/llama-3.3-70b-instruct-fp8-fast"
    cloudflare_model_strong = "@cf/meta/llama-3.3-70b-instruct-fp8-fast"

    alibaba_api_key="sk-ws-H.DMHELLI.7Xhy.MEUCIQDAjJ3BMI1pkPogy1nDZB4g8D0P9gZmzEjy6kpfWd79fwIgfFtoZvXIF-QNm6FRjKsgOqJnXKEhGFdT-xp_WcJ_6_I"
    alibaba_workspace_id = "ws-dqg0mm1esvvjw43l"
    alibaba_model_light="qwen3.8-max"
    alibaba_model_strong="qwen3.8-max"

    # Root-cause fix: `ollama_base_url` and `cerebras_base_url` above both
    # point at the same small (Gemma-3 1B) demo endpoint regardless of
    # `llm_tier`, so every "strong" call in A3 (cross-ref), A4 (LLM review),
    # and A5 (global merge) — the multi-hop reasoning steps that actually
    # need a capable model — was silently getting the same 1B model as the
    # cheap "light" calls. Set STRONG_TIER_PROVIDER (e.g. "groq" or
    # "gemini") to route tier="strong" calls to a different, stronger
    # provider without touching any stage code. Leave unset to keep the old
    # behavior (same provider for both tiers).
    strong_tier_provider: str = os.getenv("STRONG_TIER_PROVIDER", "")

    # Embeddings (local, free, offline — sentence-transformers)
    # embedding_mode: "st"   -> use sentence-transformers, downloads the model
    #                           from Hugging Face Hub on first run (needs network
    #                           once, then cached in ~/.cache/huggingface)
    #                 "hash" -> skip Hugging Face entirely, use a deterministic
    #                           offline hash-based fallback (no network, no
    #                           semantic meaning — fine for demos/CI, not for
    #                           real retrieval quality)
    embedding_mode: str = os.getenv("EMBEDDING_MODE", "st")
    embedding_model_name: str = os.getenv(
        "EMBEDDING_MODEL_NAME", "sentence-transformers/all-mpnet-base-v2"  # 768-dim
    )
    # HF_TOKEN (optional, only speeds up model downloads / avoids rate-limit
    # warnings): set it in the environment, never hardcode it here.
    # Previous version *unconditionally* overwrote os.environ["HF_TOKEN"]
    # with a hard-coded demo token on every import — even if the user had
    # already set a real one — because the assignment ran regardless of the
    # `if` above. Just read it; don't write it back at all.
    hf_token: str = os.getenv("HF_TOKEN", "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")
    os.getenv("HF_TOKEN", "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")
    # Slack/email webhook for batch monitoring (stage C)
    monitoring_webhook_url: str = os.getenv("MONITORING_WEBHOOK_URL", "")

   # File store (stage C) — local dir standing in for S3/bucket
    file_store_dir: str = os.getenv("FILE_STORE_DIR", "./data/files")
    wiki_git_dir: str = os.getenv("WIKI_GIT_DIR", "./data/wiki")

    # Thresholds used across stages (kept in one place on purpose)
    reading_order_diff_threshold: float = 0.15
    fuzzy_match_threshold: float = 91.0
    dedup_similarity_threshold: float = 0.91
    a4_confidence_done_threshold: float = 0.56
    d_min_confidence: float = 0.03
    d_relevance_threshold: float = 0.09 # tang thi se tang do chinh xac
    a4_human_review_enabled = False
    a4_llm_review_enabled = False
    a4_fuzzy_match_threshold_high: float = 80.0
    a4_fuzzy_match_threshold_low: float = 30.0
    d_retrieval_PARENT_FALLBACK_THRESHOLD = 0.47 # neu score cua parent cao thi cho lam sugesst , mang nay cos kha nang tham gia vao answer
    e_query_out_PARENT_FALLBACK_THRESHOLD = 0.47 # neu score cua parent cao thi cho lam sugesst , suggest nay co the ko tham gia answer , la mang cac context sau khi build answer xong muon hien suggest cho ng dung

    # --- A1: multi-column detection + parser tie-break (referenced by the
    # fixed stages/a1_parser.py) ---
    a1_multi_column_min_gap_ratio: float = float(os.getenv("A1_MULTI_COLUMN_MIN_GAP_RATIO", "0.06"))
    a1_prefer_heading_bearing_parser: bool = os.getenv("A1_PREFER_HEADING_BEARING_PARSER", "true").lower() == "true"
    # Kill switch for the "docling" tool: docling's own layout/table models
    # download from the HF Hub on first use. Set to false to skip straight
    # to the pdfplumber/pymupdf-heuristic stub (e.g. while HF is
    # rate-limiting) instead of paying retry/timeout cost on every document.
    a1_docling_enabled: bool = os.getenv("A1_DOCLING_ENABLED", "true").lower() == "true"

    # --- A2: pdfplumber bbox backfill + fuzzy table-header merge (referenced
    # by the fixed stages/a2_reading_order.py) ---
    a2_bbox_backfill_enabled: bool = os.getenv("A2_BBOX_BACKFILL_ENABLED", "true").lower() == "true"
    a2_bbox_match_score_threshold: float = float(os.getenv("A2_BBOX_MATCH_SCORE_THRESHOLD", "80"))
    a2_table_header_fuzzy_threshold: float = float(os.getenv("A2_TABLE_HEADER_FUZZY_THRESHOLD", "90"))

    # --- A3: cross-reference LLM call backoff + entity resolution
    # (referenced by the A3 fix below) ---
    a3_llm_max_retries: int = int(os.getenv("A3_LLM_MAX_RETRIES", "3"))
    a3_llm_backoff_base_seconds: float = float(os.getenv("A3_LLM_BACKOFF_BASE_SECONDS", "2.0"))
    a3_entity_resolution_enabled: bool = os.getenv("A3_ENTITY_RESOLUTION_ENABLED", "true").lower() == "true"
    a3_entity_embed_similarity_threshold: float = float(os.getenv("A3_ENTITY_EMBED_SIMILARITY_THRESHOLD", "0.86"))
    a3_token_count_model: str = os.getenv("A3_TOKEN_COUNT_MODEL", "cl100k_base")
    # NER backend for extract_entities_gliner: "auto" (gliner -> spacy ->
    # regex), "gliner" (downloads from HF Hub), "spacy" (pip-installed
    # model, no HF dependency at all), or "regex" (zero downloads).
    a3_ner_backend: str = os.getenv("A3_NER_BACKEND", "spacy")

    # --- A4: LLM call pacing + order-sensitivity guard (referenced by the
    # fixed stages/a4_constraint_extraction.py) ---
    a4_llm_rate_limit_seconds: float = float(os.getenv("A4_LLM_RATE_LIMIT_SECONDS", "5.0"))
    a4_order_sensitivity_drop_threshold: float = float(os.getenv("A4_ORDER_SENSITIVITY_DROP_THRESHOLD", "15.0"))

    # --- A5: LLM call pacing (referenced by the A5 fix below) ---
    a5_llm_rate_limit_seconds: float = float(os.getenv("A5_LLM_RATE_LIMIT_SECONDS", "5.0"))

      # --- Anti-hallucination controls (stage D coverage + stage E grounding) ---
    # Fraction of extracted key terms/entities from the query that must be
    # lexically present in the retrieved candidate pool for the context to be
    # considered "sufficient". This catches the case where the *topic asked
    # about* simply isn't in the corpus, even though some tangentially
    # related atoms score above d_relevance_threshold.
    d_coverage_min_ratio: float = float(os.getenv("D_COVERAGE_MIN_RATIO", "0.06")) # tang thi se tang do chinh xac tinh insufficient_coverage
    # "full_corpus" (default): a term missing from the retrieved pool gets one
    # extra cheap ILIKE check against the *whole* corpus before being reported
    # as "uncovered" — fixes the false positive where retrieval simply failed
    # to surface an atom that does contain the term (recall miss), which
    # would otherwise get the LLM explicitly told to treat real content as
    # if it doesn't exist. Set to "pool_only" to restore the old, stricter,
    # faster (no extra DB round-trip) behavior.
    d_coverage_check_scope: str = os.getenv("D_COVERAGE_CHECK_SCOPE", "full_corpus")
    # Jaccard token-overlap floor between a cited sentence and the atom text
    # it cites. Below this, the citation is treated as unsupported/fabricated.
    e_grounding_min_overlap: float = float(os.getenv("E_GROUNDING_MIN_OVERLAP", "0.03"))
    # Run a second, cheap LLM call to double-check each citation actually
    # entails its claim before returning the answer to the user.
    e_grounding_llm_check_enabled: bool = os.getenv("E_GROUNDING_LLM_CHECK", "false").lower() == "true"

    # =========================================================================
    # A4.5 — Entity Consolidation (stages/a4_5_entity_consolidation.py)
    # =========================================================================
    # Hybrid dedupe (lexical + embedding) threshold — higher than
    # dedup_similarity_threshold because entity *names* are short strings,
    # which are much more prone to embedding false-positives than full
    # sentences ("MySQL" vs "PostgreSQL" can still look deceptively close).
    a4_5_entity_embed_threshold: float = float(os.getenv("A4_5_ENTITY_EMBED_THRESHOLD", "0.90"))
    a4_5_entity_lexical_threshold: float = float(os.getenv("A4_5_ENTITY_LEXICAL_THRESHOLD", "85.0"))
    # Weights for the hybrid lexical+embedding score (w1*lex + w2*emb).
    a4_5_entity_lex_weight: float = float(os.getenv("A4_5_ENTITY_LEX_WEIGHT", "0.5"))
    a4_5_entity_emb_weight: float = float(os.getenv("A4_5_ENTITY_EMB_WEIGHT", "0.5"))
    # An entity appearing in MORE than this many distinct sections is
    # "common"/topic-level noise for candidate-pair purposes (A5) — still
    # kept for MENTIONS edges (B2), just excluded from driving candidate_pairs.
    a4_5_entity_common_cutoff: int = int(os.getenv("A4_5_ENTITY_COMMON_CUTOFF", "15"))

    # =========================================================================
    # A4.8 — Vector Candidate Pre-filter (stages/a4_8_vector_candidates.py)
    # =========================================================================
    a4_8_vector_candidate_threshold: float = float(os.getenv("A4_8_VECTOR_CANDIDATE_THRESHOLD", "0.80"))
    a4_8_top_k_neighbors: int = int(os.getenv("A4_8_TOP_K_NEIGHBORS", "10"))

    # =========================================================================
    # A5 — candidate-pairs cost cap (stages/a5_global_merge.py)
    # =========================================================================
    a5_max_candidate_pairs_per_source: int = int(os.getenv("A5_MAX_CANDIDATE_PAIRS_PER_SOURCE", "2000"))

    # =========================================================================
    # B2.5 — Community Detection + Lazy Summary (stages/b2_5_community_detection.py)
    # =========================================================================
    b2_5_min_community_size: int = int(os.getenv("B2_5_MIN_COMMUNITY_SIZE", "1"))

    # =========================================================================
    # D — seed-then-expand soft-score (stages/d_retrieval.py)
    # =========================================================================
    d_retrieval_expansion_max_per_seed: int = int(os.getenv("D_RETRIEVAL_EXPANSION_MAX_PER_SEED", "7"))
    d_retrieval_expansion_weight_edge: float = float(os.getenv("D_RETRIEVAL_EXPANSION_WEIGHT_EDGE", "0.6"))
    d_retrieval_expansion_weight_hop: float = float(os.getenv("D_RETRIEVAL_EXPANSION_WEIGHT_HOP", "0.15"))
    d_retrieval_graph_max_depth: int = int(os.getenv("D_RETRIEVAL_GRAPH_MAX_DEPTH", "3"))
    d_retrieval_community_top_k: int = int(os.getenv("D_RETRIEVAL_COMMUNITY_TOP_K", "4"))
    d_max_children_per_section: int = int(os.getenv("D_MAX_CHILDREN_PER_SECTION", "30"))
    # Weight on cross-encoder(anchor_seed, candidate) when scoring
    # section_expansion candidates (see _score_expanded_against_anchor).
    # (1 - this) stays on the candidate's prior inherited seed_score_by_parent
    # score, which acts as a brake so an unrelated atom that merely shares a
    # section with a strong seed can't outrank atoms that are actually
    # textually close to that seed. 0.0 reproduces the old flat-inheritance
    # behavior exactly; 1.0 ignores the inherited floor entirely.
    d_expansion_anchor_weight: float = float(os.getenv("D_EXPANSION_ANCHOR_WEIGHT", "0.7"))

    a4_intra_section_relations_enabled: bool = True
    b2_enable_same_section_edges: bool = False

    embedding_max_retries: int = int(os.getenv("EMBEDDING_MAX_RETRIES", "3"))
    embedding_backoff_base_seconds: float = float(os.getenv("EMBEDDING_BACKOFF_BASE_SECONDS", "1.0"))

    d_top_k_per_source_recall: int = 40      # "40" — Phase 1 #4: tăng recall trước rerank
    d_rrf_top_n: int = 60                     # "60" — nới top_n của RRF cho khớp
    d_coverage_semantic_check_enabled: bool = True  # "true" — Phase 1 #3: bật hybrid coverage check
    d_coverage_semantic_threshold: float = 0.75 # "0.75" — ngưỡng cosine similarity coverage
    d_rrf_weight_dense: float = 0.7           # "0.7"  — Phase 3 #7: trọng số dense trong RRF
    d_rrf_weight_bm25: float = 0.3           # "0.3"  — trọng số bm25 trong RRF
    d_hyde_enabled: bool = True                # "true" — Phase 2 #5: bật HyDE
    b2_chunk_enrichment_enabled: bool = False   # "false" — Phase 2 #6: bật chunk enrichment lúc ingest (tắt mặc định, đúng như doc ghi "không bắt buộc làm ngay")
    
    d_ppr_blend_weight: float = float(os.getenv("D_PPR_BLEND_WEIGHT", "0.5"))
    d_max_total_candidates_for_answer: int = 40  #so candidat se lay cho cau tra lơi

    d_ppr_max_graph_nodes=3000       # hạ xuống nếu tài liệu rất lớn / muốn ego-subgraph kích hoạt sớm hơn
    d_ppr_ego_radius=3
    d_ppr_max_iter=50
    d_ppr_tol: float = float(os.getenv("D_PPR_TOL", "1e-4"))
    d_ppr_graph_cache_ttl_seconds=0  # đặt 0 để tắt cache hoàn toàn (luôn đọc DB mới nhất)
    e_answer_max_relation_lines=15
    
    d_fisrt_rerank_blend_weight=0.45
    d_expanded_rerank_blend_weight=0.5   # hạ xuống (vd 0.3) để nghiêng hẳn về điểm kế thừa section
    d_final_rerank_blend_weight=0.6      # hạ xuống nếu vẫn thấy atom làm giàu bị cắt ở bước cuối
    d_max_expanded_candidates_for_answer=8  # tăng nếu section thường có nhiều atom bổ trợ hơn
    d_final_rerank_blend_weight_expansion: float = float(
        os.getenv("D_FINAL_RERANK_BLEND_WEIGHT_EXPANSION", "0.3")
    )


    # --- Key term extraction với LLM fallback ---
    # Bật/tắt tính năng gọi LLM khi coverage thấp
    d_llm_keyterm_fallback_enabled: bool = os.getenv("D_LLM_KEYTERM_FALLBACK_ENABLED", "true").lower() == "true"
    # Ngưỡng coverage (0-1) dưới mức này sẽ kích hoạt LLM fallback
    d_llm_keyterm_fallback_coverage_threshold: float = float(os.getenv("D_LLM_KEYTERM_FALLBACK_COVERAGE_THRESHOLD", "0.4"))
    # Số lượng key terms tối đa LLM có thể trả về (để tránh tràn)
    d_llm_keyterm_max_terms: int = int(os.getenv("D_LLM_KEYTERM_MAX_TERMS", "20"))

    # === A5.5 — Fact extraction, entity-entity với relation_type tự do ===
    a5_5_max_entity_pairs_per_source: int = int(os.getenv("A5_5_MAX_ENTITY_PAIRS_PER_SOURCE", "800"))
    a5_5_llm_rate_limit_seconds: float = float(os.getenv("A5_5_LLM_RATE_LIMIT_SECONDS", "5.0"))

    # === D — Entity-path retrieval channel (Giai đoạn 2) ===
    d_entity_path_enabled: bool = True
    d_entity_path_max_depth: int = 3
    d_entity_path_coverage_threshold: float = 0.7
    d_entity_path_max_gap_rounds: int = 2
    d_entity_path_top_k: int = 10


    d_entity_path_query_weight_hop1: float = float(os.getenv("D_ENTITY_PATH_QUERY_WEIGHT_HOP1", "0.65"))
    d_entity_path_query_weight_decay: float = float(os.getenv("D_ENTITY_PATH_QUERY_WEIGHT_DECAY", "0.15"))
    d_entity_path_query_weight_floor: float = float(os.getenv("D_ENTITY_PATH_QUERY_WEIGHT_FLOOR", "0.15"))
    d_entity_path_query_weight_floor_unconverged: float = float(
    os.getenv("D_ENTITY_PATH_QUERY_WEIGHT_FLOOR_UNCONVERGED", "0.35"))

    d_entity_fallback_sample_limit: int = 5          # top N atom dense
    d_entity_fallback_min_score: float = 0.49        # ngưỡng điểm
    d_entity_fallback_max_entities: int = 5          # số entity tối đa lấy ra

    # === D — Entity linking fallback qua embedding (đề xuất #2) ===
    # Ngưỡng cosine similarity tối thiểu để chấp nhận 1 kết quả ANN search
    # trên entity_map.name_embedding làm entity-link hợp lệ — thấp hơn mức
    # này bị bỏ qua thay vì trả về một linking sai lệch với độ tin cậy thấp.
    d_entity_link_embed_min_similarity: float = float(
        os.getenv("D_ENTITY_LINK_EMBED_MIN_SIMILARITY", "0.75"))

    # === D — PPR trên kg_facts, fallback cho entity_path_search khi BFS
    # depth-capped không đủ (đề xuất #6) ===
    d_entity_path_ppr_fallback_enabled: bool = True
    d_entity_path_ppr_top_k: int = 10

    # === D — chain_coverage gate cho self_verify (đề xuất #8/#9) ===
    # Ngưỡng nhị phân, GIỐNG CÁCH d_coverage_min_ratio đang gate
    # insufficient_coverage — không phải 1 trọng số trong công thức tổng
    # hợp nhiều tín hiệu (xem cảnh báo "không nên làm" ở đề xuất #9). Dưới
    # ngưỡng này -> self_verify coi là "chain suy luận bị đứt", bất kể
    # coverage_ratio (term-presence trên toàn pool) có cao hay không.
    d_chain_coverage_min_ratio: float = float(
        os.getenv("D_CHAIN_COVERAGE_MIN_RATIO", "0.5"))

    # =========================================================================
    # D — đề xuất #11: tách traversal_seed_ids (ngưỡng lỏng, điểm vào graph
    # traversal) khỏi seed (ngưỡng chặt, evidence câu trả lời cuối cùng).
    # =========================================================================
    d_traversal_seed_enabled: bool = os.getenv("D_TRAVERSAL_SEED_ENABLED", "true").lower() == "true"
    # Cap TUYỆT ĐỐI số atom entity-matched-nhưng-similarity-thấp được thêm
    # vào traversal_seed_ids — không chỉ dựa vào ngưỡng điểm, để tránh
    # personalization vector của PPR phình to làm traversal nhiễu hơn (đánh
    # đổi recall/độ sạch đã nêu trong đề xuất #11).
    d_traversal_seed_max_extra_atoms: int = int(os.getenv("D_TRAVERSAL_SEED_MAX_EXTRA_ATOMS", "15"))
    # Mỗi anchor entity chỉ lấy tối đa N atom MENTIONS nó (tránh 1 entity
    # xuất hiện ở rất nhiều atom chiếm hết ngân sách extra atom ở trên).
    d_traversal_seed_max_atoms_per_entity: int = int(
        os.getenv("D_TRAVERSAL_SEED_MAX_ATOMS_PER_ENTITY", "5"))
    # relevance_score gán cho atom chỉ vào traversal_seed_ids qua entity
    # match (không qua dense similarity) — cố tình THẤP và KHÔNG dùng làm
    # evidence câu trả lời (all_candidates chỉ nhận từ seed gốc, không nhận
    # từ traversal_seed_ids) — giá trị này chỉ ảnh hưởng heading/section
    # expansion score kế thừa qua _expand_atom_seeds, không hiển thị cho
    # người dùng.
    d_traversal_seed_entity_match_score: float = float(
        os.getenv("D_TRAVERSAL_SEED_ENTITY_MATCH_SCORE", "0.3"))

    # =========================================================================
    # D — đề xuất #12: tỷ lệ trọng số anchor entity (lexical match) so với
    # dense seed atom trong personalization vector của graph_search_ppr.
    # Giữ 0.5 (giá trị cũ) làm mặc định để backward-compatible — chỉ tăng
    # dần lên 1.0 sau khi A/B test thật, KHÔNG đổi thẳng lên 1:1 (rủi ro hub
    # entity kéo PPR lệch quá mức, xem đề xuất #12).
    # =========================================================================
    d_ppr_anchor_weight_ratio: float = float(os.getenv("D_PPR_ANCHOR_WEIGHT_RATIO", "0.5"))

    # =========================================================================
    # D — đề xuất #13: PPR riêng theo từng cụm seed trên fact-graph
    # (graph_ppr_facts_multi), cộng tín hiệu "connector node" cho entity lọt
    # top-K ở >=2 lần chạy độc lập. CHỈ áp dụng cho graph_ppr_facts (kg_facts,
    # nhỏ) — KHÔNG áp dụng cho graph_search_ppr (graph atom hỗn hợp lớn hơn).
    # =========================================================================
    d_graph_ppr_facts_multi_enabled: bool = os.getenv(
        "D_GRAPH_PPR_FACTS_MULTI_ENABLED", "true").lower() == "true"
    # Số cụm seed tối đa để chạy multi-run — vượt quá mức này, chi phí N lần
    # pagerank không còn "chấp nhận được" như đã phân tích trong đề xuất #13,
    # fallback về graph_ppr_facts gộp 1 lần như cũ.
    d_graph_ppr_facts_multi_max_clusters: int = int(
        os.getenv("D_GRAPH_PPR_FACTS_MULTI_MAX_CLUSTERS", "5"))

    d_entity_paths_max_hops_for_prompt= 15
    d_entity_fallback_freq_bonus: float  = 0.1

    # =========================================================================
    # D/E — đề xuất #14: vòng lặp retrieve-reason-retrieve Ở TẦNG NGOÀI
    # retrieve() (khác gap-fill nội bộ của entity_path_search — bù 1 cạnh cụ
    # thể trong 1 path đã biết). BẮT BUỘC giới hạn cứng 1 vòng, xem
    # stages/e_query_output.py::answer_query / _retry_with_retrieval_gap.
    # =========================================================================
    d_gap_retry_enabled: bool = os.getenv("D_GAP_RETRY_ENABLED", "true").lower() == "true"
    a4_pass_heading_to_extraction = True
    a4_include_heading_in_intra_section_relations = True



    d_merge_min_ratio_seed: float = float(os.getenv("D_MERGE_MIN_RATIO_SEED", "0.01"))
    d_merge_min_ratio_expanded: float = float(os.getenv("D_MERGE_MIN_RATIO_EXPANDED", "0.01"))
    d_merge_min_ratio_community: float = float(os.getenv("D_MERGE_MIN_RATIO_COMMUNITY", "0.005"))
    d_merge_min_ratio_entity_path: float = float(os.getenv("D_MERGE_MIN_RATIO_ENTITY_PATH", "0.3"))
    # Đề xuất — lọc candidate trùng NGỮ NGHĨA (atom_id khác nhau nhưng nội
    # dung gần như 1) trong tập candidate CUỐI CÙNG, dùng embedding cosine
    # similarity đã có sẵn (không tính embedding mới). threshold cao (0.93)
    # để tránh lọc nhầm 2 atom liên quan nhưng KHÔNG trùng ý.
    d_merge_near_dup_similarity_threshold: float = float(
        os.getenv("D_MERGE_NEAR_DUP_SIMILARITY_THRESHOLD", "0.93")
    )
    d_merge_near_dup_max_passes: int = int(os.getenv("D_MERGE_NEAR_DUP_MAX_PASSES", "5"))

    d_exclude_heading_from_dense_evidence: bool = os.getenv("D_EXCLUDE_HEADING_FROM_DENSE_EVIDENCE", "true").lower() == "true"
    d_exclude_heading_fetch_multiplier: int = int(os.getenv("D_EXCLUDE_HEADING_FETCH_MULTIPLIER", "2"))

    d_entity_fallback_bm25_enabled: bool = os.getenv("D_ENTITY_FALLBACK_BM25_ENABLED", "true").lower() == "true"
    d_entity_fallback_bm25_limit_per_term: int = int(os.getenv("D_ENTITY_FALLBACK_BM25_LIMIT_PER_TERM", "5"))
    d_entity_fallback_bm25_max_extra_entities: int = int(os.getenv("D_ENTITY_FALLBACK_BM25_MAX_EXTRA_ENTITIES", "5"))

    d_entity_path_bidirectional: bool = True

settings = Settings()
