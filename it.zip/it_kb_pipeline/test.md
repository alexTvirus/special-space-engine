# Tài liệu vận hành: Hệ thống Backend OrderCore

## 2. Cấu hình cơ sở dữ liệu PostgreSQL

PostgreSQL phiên bản 15 được triển khai phía sau pgbouncer, chạy ở chế độ
transaction pooling. Tham số `max_connections` của PostgreSQL được đặt là
200, nhưng pgbouncer giới hạn `pool_size` chỉ 50 kết nối cho mỗi service
phía sau nó.

Order-API và Auth-Service dùng chung một instance PostgreSQL vật lý, nhưng
tách biệt database logic: `orders_db` cho Order-API và `auth_db` cho
Auth-Service.

Khi `pool_size` của pgbouncer bị chiếm dụng hết (100% connection đang bận),
mọi truy vấn mới gửi tới sẽ phải xếp hàng chờ, và mặc định sẽ bị timeout
sau 30 giây nếu không có connection nào được giải phóng.

## 3. Dịch vụ xác thực (Auth-Service)

Auth-Service phát hành access token dạng JWT có thời hạn 15 phút, kèm theo
refresh token có thời hạn 7 ngày.

Khi xác thực một access token, Auth-Service luôn kiểm tra Redis trước tiên
để xem token đó đã có trong session cache hay chưa. Chỉ khi cache miss,
Auth-Service mới truy vấn tới `auth_db` trên PostgreSQL để xác minh token,
sau đó ghi kết quả vào lại Redis cho lần sau.

Nếu truy vấn tới PostgreSQL mất hơn 2 giây để phản hồi, Auth-Service coi
đây là timeout và trả về mã lỗi 503 cho toàn bộ request — bất kể Order-API
phía sau có đang hoạt động bình thường hay không.


## 5. Giám sát và cảnh báo

Prometheus lấy mẫu (scrape) metrics từ tất cả các service mỗi 15 giây, bao
gồm chỉ số `pgbouncer_pool_used_percent`.

Một cảnh báo mức "critical" được kích hoạt nếu `pgbouncer_pool_used_percent`
vượt quá 80% và duy trì liên tục trong 5 phút; cảnh báo này được gửi qua
PagerDuty tới đội on-call.

Một cảnh báo khác, độc lập, theo dõi chỉ số `redis_connected_clients`. Nếu
giá trị này về 0 (Redis mất kết nối hoàn toàn), cảnh báo "critical" được
gửi ngay lập tức, không cần chờ đủ 5 phút như cảnh báo của pgbouncer.

## 6. Chính sách sao lưu

PostgreSQL được sao lưu tự động bằng `pg_dump` vào lúc 2:00 sáng mỗi ngày.
File backup được nén rồi tải lên S3 bucket có tên `ordercore-backups`.

Các bản backup được giữ lại trong 30 ngày, sau đó tự động bị xoá theo chính
sách lifecycle của bucket.

Đội vận hành thực hiện diễn tập khôi phục (restore drill) mỗi quý một lần,
nhằm đảm bảo các file backup thực sự có thể dùng để khôi phục dữ liệu khi
cần, không chỉ tồn tại trên S3.

## 7. Quy trình xử lý sự cố

Khi đội on-call nhận được cảnh báo `pgbouncer_pool_used_percent` vượt 80%,
bước đầu tiên trong quy trình là kiểm tra log của Auth-Service xem có phải
nguyên nhân đến từ việc Redis vừa khởi động lại hoặc mất kết nối, gây ra
làn sóng xác thực lại hàng loạt hay không.

Nếu đúng là do Redis, giải pháp tạm thời là tăng `pool_size` của pgbouncer
lên 100 trong lúc chờ Redis ổn định trở lại và session cache được làm đầy
lại tự nhiên — nhằm tránh Auth-Service phải trả lỗi 503 hàng loạt cho người
dùng trong lúc đó.

Nếu nguyên nhân không liên quan tới Redis, bước tiếp theo là kiểm tra các
truy vấn chậm (slow query) đang chạy trong `orders_db` thông qua view
`pg_stat_activity` của PostgreSQL.

## 8. Triển khai (Deployment)

OrderCore áp dụng chiến lược blue-green deployment: phiên bản mới được
triển khai song song với phiên bản cũ, sau đó 10% traffic được chuyển sang
bản mới (canary) trong 15 phút đầu tiên để theo dõi.

Nếu trong giai đoạn canary, Prometheus phát ra bất kỳ cảnh báo mức
"critical" nào liên quan tới service vừa được triển khai, pipeline CI/CD sẽ
tự động rollback về phiên bản cũ ngay lập tức mà không cần con người can
thiệp.

Script khởi động của Auth-Service, mỗi khi được deploy phiên bản mới, luôn
chạy lệnh xoá toàn bộ dữ liệu Redis (FLUSHDB) trước khi khởi động — mục
đích là tránh việc dùng nhầm các session token đã được cache theo định dạng
cũ, không tương thích với phiên bản mới.
