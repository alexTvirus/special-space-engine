"""
VÍ DỤ ĐẦY ĐỦ: xây dựng Knowledge Base từ 1 file, chạy qua TOÀN BỘ pipeline
A1 -> A2 -> A3 -> A3.5 -> A4 (queue Postgres) -> B1 -> A4.5 -> A4.8 -> A5 ->
B2 -> C -> B2.5 -> D -> E.

(A4.5 entity consolidation, A4.8 vector candidate pre-filter, và B2.5
community detection là 3 stage mới — xem thiet_ke_cai_tien_kb_pipeline_final.md.
Chúng chạy SAU B1, không phải trước A5 như sơ đồ tổng quan mục 0 của tài liệu
thiết kế gợi ý: A4.5/A4.8 cần `KnowledgeAtom.embedding`, vốn chỉ tồn tại sau
khi B1 đã dedup+embed — xem comment trong create_kb_from_file.py::main() tại
điểm gọi A4.5 để biết chi tiết thứ tự phụ thuộc thực tế.)

Khác với `run_pipeline_demo.py` (chỉ chạy A1-A3, offline, không cần Postgres),
file này chạy được TRỌN VẸN — cần Postgres đã apply db/schema.sql.

Ở mỗi bước, script in ra rõ: INPUT nhận từ đâu, OUTPUT là gì, và output đó
được truyền làm input cho bước kế tiếp như thế nào — đúng như luồng dữ liệu
mô tả trong README.md / common/schemas.py.

LLM: ví dụ này dùng `DemoRuleBasedLLM` — một LLMClient rule-based, 100% free,
chạy offline, không cần API key, chỉ để CHỨNG MINH pipeline chạy được đầu-cuối
ngay lập tức. Khi dùng thật, chỉ cần đổi 1 dòng:

    llm = DemoRuleBasedLLM()          # demo
    llm = get_llm_client()            # thật, đọc LLM_PROVIDER=ollama|groq|gemini từ .env

...vì mọi stage chỉ phụ thuộc vào interface `LLMClient.generate()/.embed()`
(common/llm_client.py), không phụ thuộc implementation cụ thể nào.

Chạy:
    export DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/it_kb
    python examples/create_kb_from_file.py
"""
from __future__ import annotations

import json
import os
import re
import sys

from itertools import cycle
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from nanoid import generate
from common import db
import sys
from common.llm_client import LLMClient, LocalEmbedder ,AlibabaClient
from common.llm_client import get_llm_client,CloudflareClient,OllamaCloudClient,MistralClient,ZaiClient,AionLabsClient
from common.llm_client import CerebrasClient,GroqClient,GeminiClient , OpenrouterClient,HuggingFaceClient
from common.schemas import RetrievalQuery , ElementType , UnifiedDoc ,CrossLink
from common.llm_pool import get_llm_client_tiered
from stages import (
    a1_parser, a2_reading_order, a3_global_index, a3_5_hashing,
    a4_constraint_extraction, a4_5_entity_consolidation, a4_8_vector_candidates,
    a5_global_merge, a5_5_fact_extraction, a5_8_relation_type_consolidation,
    b1_dedup, b2_wiki_graph_chunking,
    b2_5_community_detection, c_storage, d_retrieval, e_query_output,
)

alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
# =============================================================================
# LLM rule-based dùng cho demo — free, offline, không cần API key.
# Dispatch theo nội dung của `system` prompt để biết stage nào đang gọi mình.
# =============================================================================

def step(title: str) -> None:
    print(f"\n{'=' * 70}\n{title}\n{'=' * 70}")



def main() -> None:
    file_path = "test.md"
    ##with open(file_path, "w", encoding="utf-8") as f:
    ##    f.write(SAMPLE_DOC)
    random_string = generate(alphabet, 3)
    source_id = "abc1"
    # llm = get_llm_client()        
    # llm_strong1 = GroqClient()
    # llm_strong1.set_key("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")
    # llm_strong2 = GroqClient()
    # llm_strong2.set_key("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")
    # llm_strong3 = GroqClient()
    # llm_strong3.set_key("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")
    # llm_strong4 = GroqClient()
    # llm_strong4.set_key("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")
    # llm_strong5 = GroqClient()
    # llm_strong5.set_key("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")
    # llm_strong6 = GroqClient()
    # llm_strong6.set_key("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")
    # llm_strong7 = CerebrasClient()
    # llm_strong7.set_key("csk-mkrwvckrernvexvwvh82ww52xte33ct3fp9c4mfcncpej3p8")
    # llm_strong8 = CerebrasClient()
    # llm_strong8.set_key("csk-xhm85jhw66vm2kmexjrfte38yx9dwwjhemh52mdd539pvc39")
    # llm_strong9 = CerebrasClient()
    # llm_strong9.set_key("csk-cyh6cfpyy3hrh3hnrvw6jt3mn6n54dnxtwwxjtr8n3yxr8vf")
    # llm_strong10 = CerebrasClient()
    # llm_strong10.set_key("csk-v4rrvww5856yn9devd4t2ep6dj4dwrtw3djj9hmph54fx3jv")
    # llm_strong11 = CerebrasClient()
    # llm_strong11.set_key("csk-p5cwcy98y4m4d94jk8fej8m6wrw3ymrm5mteetpmrr536n8x")
    # llm_strongc12 = CerebrasClient()
    # llm_strongc12.set_key("csk-9nvhrmj9nk3m2newkk6emvd5cev6mrexfdfdprfnhnc6mdth")

    # llm_hf_1 = HuggingFaceClient()
    # llm_hf_1.set_key("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")
    # llm_hf_2 = HuggingFaceClient()
    # llm_hf_2.set_key("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")
    # llm_hf_3 = HuggingFaceClient()
    # llm_hf_3.set_key("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")
    # llm_hf_4 = HuggingFaceClient()
    # llm_hf_4.set_key("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")
    # llm_hf_5 = HuggingFaceClient()
    # llm_hf_5.set_key("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")
    # llm_hf_6 = HuggingFaceClient()
    # llm_hf_6.set_key("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")
    # llm_hf_7 = HuggingFaceClient()
    # llm_hf_7.set_key("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")
    # llm_hf_8 = HuggingFaceClient()
    # llm_hf_8.set_key("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")
    # llm_hf_9 = HuggingFaceClient()
    # llm_hf_9.set_key("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")
    # llm_hf_10 = HuggingFaceClient()
    # llm_hf_10.set_key("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")
    # llm_hf_11 = HuggingFaceClient()
    # llm_hf_11.set_key("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")
    
    
    
    # llm_ali_1 = AlibabaClient()
    # llm_ali_1.set_key(
    #     key="sk-ws-H.DMHEMLL.6kr0.MEUCIQCP5saDdKDFVh4KbaaHL8lCiBgwI-8Xhn2GyhBqyRHNnwIgRQDsj73ccVAcP0WKx1w9m-OMI7PM0X60O5wCAEIuGlI",
    # workspace_id= "ws-kpde21wer5ix2ad6")

    # llm_ali_2 = AlibabaClient()
    # llm_ali_2.set_key(
    #     key="sk-ws-H.DMHELLI.7Xhy.MEUCIQDAjJ3BMI1pkPogy1nDZB4g8D0P9gZmzEjy6kpfWd79fwIgfFtoZvXIF-QNm6FRjKsgOqJnXKEhGFdT-xp_WcJ_6_I",
    # workspace_id= "ws-dqg0mm1esvvjw43l")
    
    # # lisa
    # llm_cf_1 = CloudflareClient()
    # llm_cf_1.set_key(key="cfut_SNmu13EO4A3ivczBpkA2mNwA3S6wcyNINhYlkIBr4837a3b6",
    # account_id="be9f4d8e6e32b5db14e7f41424c51cae")

    # llm_cf_2 = CloudflareClient()
    # llm_cf_2.set_key(key="cfut_AdnOFbxO3IaV6J4iMfB5llvcDODmXEmSaQBBOSi8b05e580e",
    # account_id="f1bddd973672ce5f77f624e65e555ac4")

    # llm_cf_3 = CloudflareClient()
    # llm_cf_3.set_key(key="cfut_MXhkWzTqegIgh8Gyn8QzOxc2RJd4027nbxTal6Ed4cecaedb",
    # account_id="743b8d8cf8f37b53eb2c8912f385424f")

    # llm_Openrouter_1 = OpenrouterClient()
    # llm_Openrouter_1.set_key("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")
    # llm_Openrouter_2 = OpenrouterClient()
    # llm_Openrouter_2.set_key("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")
    # llm_Openrouter_3 = OpenrouterClient()
    # llm_Openrouter_3.set_key("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")

    # object_list = [llm_strong1,llm_strong2,llm_strong3,llm_strong4,llm_strong5,llm_strong6]
    # pool = cycle(object_list)

    # def get_objectllm():
    #     return next(pool)


    # object_list2 = [llm_strong7,llm_strong8,llm_strong9,llm_strong10]
    # pool2 = cycle(object_list2)

    # def get_objectllm_weak():
    #     return next(pool2)
    
    # llm_genemi2=GeminiClient()
    # llm_genemi2.set_key("AQ.Ab8RN6L3kNC4onmtdJ7AmOm7CKl6TayJ4yA_YrxvK3WT-8CiAA")
    # llm_genemi1=GeminiClient()
    # llm_genemi1.set_key("AQ.Ab8RN6KAiSW-HPAF1F7kjMT6ppzn_b9mkxlAs1WyrrwUcR1G8w")
    # # llm_genemi3=GeminiClient()
    # # llm_genemi3.set_key("AQ.Ab8RN6Kc91MkNjv5tJi-F128WBCSVs4M3T9tUndKgVehSjyjhw")
    # # llm_genemi4=GeminiClient()
    # # llm_genemi4.set_key("AQ.Ab8RN6LNJ--JgVLFamVXoGdoYo72z912qNIWESit23DqTErJ2Q")
    
    # # object_list1 = [llm_genemi1,llm_genemi2]
    # object_list1 = [llm_genemi1,llm_genemi2,llm_hf_11,llm_hf_10,llm_hf_9,llm_hf_8,llm_hf_7,llm_hf_6,llm_hf_5,llm_hf_4,llm_ali_1,llm_ali_2,llm_cf_1,llm_cf_2,llm_cf_3]
    # pool1 = cycle(object_list1)

    # def get_objectllm1():
    #     return next(pool1)    

    def get_llm_easy():
        return get_llm_client_tiered("easy")

    def get_llm_medium():
        return get_llm_client_tiered("medium")

    def get_llm_strong():
        return get_llm_client_tiered("strong")

    # -------------------------------------------------------------------
    # A1 — INPUT: file_path, source_id  ->  OUTPUT: UnifiedDoc
    # -------------------------------------------------------------------
    step("A1 — parse_document(file_path, source_id) -> UnifiedDoc")
    doc = a1_parser.parse_document(file_path, source_id)
    print(f"parser_used={doc.parser_used}  parse_confidence={doc.parse_confidence:.2f}")
    print(f"elements={len(doc.elements)}  sections={sorted(set(e.section_id for e in doc.elements))}")

    # -------------------------------------------------------------------
    # A2 — INPUT: UnifiedDoc (từ A1)  ->  OUTPUT: UnifiedDoc (đã annotate)
    # -------------------------------------------------------------------
    step("A2 — verify_and_fix(doc) -> UnifiedDoc (annotated)")
    doc = a2_reading_order.verify_and_fix(doc)
    print(f"issues={len(doc.issues)}  needs_review={doc.needs_review}")

    # -------------------------------------------------------------------
    # A3 — INPUT: UnifiedDoc (từ A2)  ->  OUTPUT: GlobalIndex
    #      GlobalIndex sẽ được dùng làm context cho A4 và A5 bên dưới
    # -------------------------------------------------------------------
    step("A3 — build_global_index(doc, llm) -> GlobalIndex")
    global_index = a3_global_index.build_global_index(doc, get_llm_strong)
    for node in global_index.heading_tree:
        print(f"  [{node.section_id}] {'  ' * (node.level - 1)}{node.text}")
    print(f"entities: {[e.canonical_name for e in global_index.entity_map][:10]}")

    # -------------------------------------------------------------------
    # A3.5 — INPUT: UnifiedDoc + source_id  ->  OUTPUT: SectionHashReport
    #        .sections_to_process là input cho bước enqueue A4 ngay dưới đây
    # -------------------------------------------------------------------
    step("A3.5 — compute_section_hash_report(doc, source_id) -> SectionHashReport")
    hash_report = a3_5_hashing.compute_section_hash_report(doc, source_id)
    print(f"new_sections={hash_report.new_sections}")
    print(f"changed_sections={hash_report.changed_sections}")
    print(f"-> sections_to_process (input cho A4) = {hash_report.sections_to_process}")

    # -------------------------------------------------------------------
    # Incremental cleanup (thiet_ke_cai_tien_kb_pipeline_final.md mục 6,
    # bước 1) — CHỈ áp dụng cho changed_sections (new_sections chưa từng có
    # dữ liệu gì để dọn). Phải chạy TRƯỚC khi enqueue lại các section này
    # vào A4, nếu không dữ liệu cũ (atom/edge/chunk) sẽ tồn tại song song
    # với dữ liệu mới thay vì được thay thế.
    # -------------------------------------------------------------------
    if hash_report.changed_sections:
        step("Incremental cleanup — dọn atom/kg_edge/chunk cũ của changed_sections")
        old_atom_ids = db.get_atom_ids_for_sections(source_id, hash_report.changed_sections)
        db.delete_kg_edges_touching_atoms(old_atom_ids)
        db.delete_knowledge_atoms(old_atom_ids)
        db.delete_chunk_records_for_sections(source_id, hash_report.changed_sections)
        # BUG FIX (was missing entirely): also strip the changed sections'
        # stale references out of entity_map BEFORE A4.5 reconsolidates —
        # otherwise save_entity_map's additive merge (see common/db.py) would
        # union the freshly re-extracted section_ids back on top of the
        # pre-edit ones instead of replacing them, permanently accumulating
        # stale section_ids on every edit of a section that mentions the
        # same entity.
        db.strip_section_ids_from_entity_map(source_id, hash_report.changed_sections)
        print(f"  đã xoá {len(old_atom_ids)} atom cũ + kg_edge/chunk liên quan + entity_map stale refs")

    # -------------------------------------------------------------------
    # Enqueue A4 jobs — mỗi section mới/đổi thành 1 row trong bảng section_jobs
    # (thay Celery+Redis, xem common/db.py:enqueue_section_job)
    # -------------------------------------------------------------------
    step("Enqueue A4 jobs vào bảng section_jobs (Postgres, thay Celery+Redis)")
    text_by_section: dict[str, list[str]] = {}
    for el in doc.elements:
        if el.type != ElementType.HEADING:   # chỉ lấy element không phải heading
            text_by_section.setdefault(el.section_id, []).append(el.content_raw)

    batch_id = db.start_batch(total_documents=1)

    def build_section_heading_map(unified_doc: UnifiedDoc) -> dict[str, str]:
        heading_map = {}
        for el in unified_doc.elements:
            if el.type == ElementType.HEADING and el.section_id:
                heading_map[el.section_id] = el.content_display  # Lấy text heading
        return heading_map

    heading_map = build_section_heading_map(doc)

    for section_id in hash_report.sections_to_process:
        section_text = "\n".join(text_by_section.get(section_id, []))
        heading = heading_map.get(section_id)
        job_id = db.enqueue_section_job(batch_id, source_id, section_id, section_text,heading)
        print(f"  enqueued job={job_id[:8]}...  section={section_id}")

    # -------------------------------------------------------------------
    # A4 + B1 — rút job từ hàng đợi (giống worker.py nhưng chạy hữu hạn ở đây
    # để demo dừng khi hết việc thay vì chạy vô hạn như worker thật)
    #
    #   INPUT của A4:  SectionJobInput (1 job)      -> OUTPUT: SectionExtractionResult
    #   INPUT của B1:  result.verified (list[ExtractedElement]) -> OUTPUT: DedupReport
    #                  (B1 lưu thẳng KnowledgeAtom đã dedup vào bảng knowledge_atoms)
    # -------------------------------------------------------------------
    step("A4 (extract+verify) -> B1 (dedup+store), rút job bằng FOR UPDATE SKIP LOCKED")
     # MỚI — gom intra_links (quan hệ nội-section, từ A4) của TẤT CẢ section
    # trong batch này lại, để remap qua bảng merges của B1 rồi gộp vào
    # merge_result.cross_links (A5) trước khi B2 build_kg — xem đoạn remap
    # ngay dưới vòng while.
    all_intra_links: list[CrossLink] = []
    while True:
        job = db.claim_next_job()
        if job is None:
            break
        result = a4_constraint_extraction.process_section(job, get_llm_medium)
        print(f"  section={job.section_id}  elements={len(result.elements)}  "
              f"verified={len(result.verified)}  confidence={result.confidence:.2f}  "
              f"outcome={result.outcome}")

        if result.outcome == "DONE":
            db.mark_job_done(job.job_id)
            dedup_report = b1_dedup.dedup_and_store(job.source_id, job.section_id, result.verified, get_llm_easy())
            print(f"    -> B1 dedup: kept={len(dedup_report.kept)} atoms, "
                  f"dropped={len(dedup_report.dropped_ids)} (trùng)")
            if result.intra_links:
                # element.id == KnowledgeAtom.id CHỈ khi B1 không dedup nó vào
                # 1 atom đã tồn tại — nếu bị dedup, id thật nằm trong
                # dedup_report.merges[i]["merged_into"]. Follow chain vì 1
                # element có thể bị merge 2 lần (tier1 exact_dedup rồi tier2/3
                # vector-dedup) trước khi có id cuối cùng.
                merge_map = {m["dropped"]: m["merged_into"] for m in dedup_report.merges}

                def _resolve(atom_id: str, _seen: set[str] | None = None) -> str:
                    _seen = _seen or set()
                    while atom_id in merge_map and atom_id not in _seen:
                        _seen.add(atom_id)
                        atom_id = merge_map[atom_id]
                    return atom_id

                for link in result.intra_links:
                    from_id = _resolve(link.from_id)
                    to_id = _resolve(link.to_id)
                    if from_id == to_id:
                        continue  # cả 2 bị merge chung vào 1 atom -> quan hệ tự-trỏ, vô nghĩa
                    all_intra_links.append(CrossLink(
                        from_id=from_id, to_id=to_id, relation=link.relation, evidence_raw=link.evidence_raw,
                    ))

        elif result.outcome == "RETRY":
            new_attempt = job.attempt + 1
            db.mark_job_retry(job.job_id, new_attempt, a4_constraint_extraction.upgrade_tier(job.llm_tier),
                               backoff_seconds=1)
        else:
            db.mark_job_manual_review(job.job_id, error="confidence too low after max attempts")

    # sys.exit()
    #assert db.all_section_jobs_done(source_id), "còn job chưa xong — chờ worker chạy tiếp"
    # -------------------------------------------------------------------
    # A5 — INPUT: list[KnowledgeAtom] (tất cả atom vừa lưu ở B1) + GlobalIndex
    #      OUTPUT: MergeResult (cross_links xuyên section)
    # -------------------------------------------------------------------
    step("A4.5 — consolidate_entities(source_id, atoms, llm) -> entity_map")
    all_atoms = db.get_atoms_by_source(source_id)
    print(f"tổng số KnowledgeAtom đã lưu cho '{source_id}': {len(all_atoms)}")
    # Chi phí incremental: entity consolidation + candidate-pairs generation
    # chỉ cần chạy trên atom của section MỚI/ĐỔI trong lần chạy này — atom
    # của section KHÔNG đổi giữ nguyên entity_id/candidate_pairs đã có từ
    # trước (thiet_ke_cai_tien_kb_pipeline_final.md mục 6, nguyên tắc cốt lõi:
    # chi phí tỉ lệ với phần thay đổi, không phải toàn tài liệu).
    changed_or_new = set(hash_report.sections_to_process)
    new_atoms = [a for a in all_atoms if a.section_id in changed_or_new] or all_atoms
    entity_map = a4_5_entity_consolidation.consolidate_entities(source_id, new_atoms, get_llm_medium())
    print(f"entity_map: {[e.canonical_name for e in entity_map][:10]} (tổng {len(entity_map)})")

    step("A4.8 — build_vector_candidates(new_atoms) -> SIMILAR_TO edges + vector_pairs")
    vector_pairs = a4_8_vector_candidates.build_vector_candidates(new_atoms)
    print(f"vector_pairs (SIMILAR_TO, đã ghi thẳng vào kg_edges): {len(vector_pairs)}")

    step("A5 — build_candidate_pairs + global_merge(...) -> MergeResult")
    candidate_pairs = a5_global_merge.build_candidate_pairs(new_atoms, entity_map, vector_pairs)
    print(f"candidate_pairs cho A5 (entity + vector, đã lọc common_cutoff): {len(candidate_pairs)}")
    # BUG FIX: A4.8's ANN search (build_vector_candidates) legitimately finds
    # vector_pairs that cross new_atoms <-> pre-existing atoms from UNCHANGED
    # sections (db.ann_search_atoms queries the whole knowledge_atoms table,
    # scoped only by source_id — see stages/a4_8_vector_candidates.py). But
    # global_merge() builds `atoms_by_id` from whatever atom list it's given,
    # and _build_pairs_payload silently drops any pair where either id isn't
    # in that dict. Passing only `new_atoms` here meant every cross-corpus
    # candidate pair (new atom <-> old atom) was silently discarded before
    # the LLM ever saw it — so DEFINES/EXTENDS/CONTRADICTS/RELATED_TO could
    # never be established between newly-ingested content and the existing
    # corpus on an incremental update, only among new_atoms themselves. Pass
    # `all_atoms` (already fetched above) as the lookup set instead — this
    # does NOT increase LLM call volume (still bounded by candidate_pairs,
    # which is unchanged), it only makes old-atom ids resolvable.
    merge_result = a5_global_merge.global_merge(all_atoms, entity_map, candidate_pairs,
                                                  get_llm_strong, source_id=source_id)
    print(f"cross_links={len(merge_result.cross_links)}")
    for cl in merge_result.cross_links:
        print(f"  {cl.from_id} --{cl.relation}--> {cl.to_id}  (evidence: {cl.evidence_raw!r})")

    # MỚI — gộp intra_links (quan hệ nội-section, từ A4, đã remap qua B1) vào
    # cross_links của A5 (cross-section) TRƯỚC KHI B2 build_kg đọc
    # merge_result.cross_links — build_kg không phân biệt nguồn gốc cạnh,
    # chỉ cần đúng schema CrossLink. Dedupe (from,to,relation) đề phòng
    # trùng lặp, dù về lý thuyết A5 không bao giờ tạo cặp cùng section
    # (xem a5_global_merge.build_candidate_pairs: `if a.section_id ==
    # b.section_id: continue`) nên trùng thật sự không nên xảy ra.
    if all_intra_links:
        seen_link_keys = {(cl.from_id, cl.to_id, cl.relation) for cl in merge_result.cross_links}
        added = 0
        for link in all_intra_links:
            key = (link.from_id, link.to_id, link.relation)
            if key in seen_link_keys:
                continue
            seen_link_keys.add(key)
            merge_result.cross_links.append(link)
            added += 1
        print(f"intra_links (nội-section, từ A4, đã remap qua B1): +{added} cross_links "
              f"(tổng cross_links={len(merge_result.cross_links)})")

    step("A5.5 — extract_facts(all_atoms, merge_result, entity_map, llm) -> (facts, fact_evidence)")
    entity_label = {e.entity_id: e.canonical_name for e in entity_map}
    a55_facts, a55_fact_evidence = a5_5_fact_extraction.extract_facts(
        all_atoms, merge_result, entity_label,  get_llm_strong, source_id=source_id,
    )
    print(f"facts (domain-specific, A5.5)={len(a55_facts)}  fact_evidence={len(a55_fact_evidence)}")

    step("A5.8 — consolidate_relation_types(a55_facts, a55_fact_evidence, llm) -> canonical relation_type")
    a55_facts, a55_fact_evidence = a5_8_relation_type_consolidation.consolidate_relation_types(
        a55_facts, a55_fact_evidence,  get_llm_medium(),
    )
    print(f"facts sau A5.8 (relation_type đã canonical hoá)={len(a55_facts)}  fact_evidence={len(a55_fact_evidence)}")

    # -------------------------------------------------------------------
    # B2 — INPUT: list[KnowledgeAtom] + MergeResult (từ A5) + GlobalIndex
    #      OUTPUT: B2Output (chunk_records, kg_nodes/edges, wiki_pages)
    # -------------------------------------------------------------------
    step("B2 — build_wiki_kg_chunks(new_atoms, merge_result, llm, global_index, sections) -> B2Output")
    b2_output = b2_wiki_graph_chunking.build_wiki_kg_chunks(
        new_atoms, merge_result, get_llm_strong, global_index=global_index, sections=changed_or_new,
    )
    # Gộp facts của A5.5 (domain-specific) vào cùng B2Output với facts của
    # B2 (generic-relation projection) để stage C persist trong 1 lần.
    b2_output.facts.extend(a55_facts)
    b2_output.fact_evidence.extend(a55_fact_evidence)
    print(f"chunk_records={len(b2_output.chunk_records)} "
          f"(parent={sum(1 for c in b2_output.chunk_records if c.type=='parent')}, "
          f"child={sum(1 for c in b2_output.chunk_records if c.type=='child')})")
    print(f"kg_nodes={len(b2_output.kg_nodes)}  kg_edges={len(b2_output.kg_edges)}")
    print(f"wiki_pages={[p.section_id for p in b2_output.wiki_pages]}")

    # -------------------------------------------------------------------
    # C — INPUT: B2Output  ->  OUTPUT: none (side effect: Postgres + Git)
    # -------------------------------------------------------------------
    step("C — persist_b2_output(b2_output) -> ghi Postgres + git commit wiki")
    c_storage.persist_b2_output(b2_output)
    batch_stats = c_storage.finish_batch(batch_id)
    print(f"batch {batch_id[:8]}... hoàn tất: total_sections={batch_stats.total_sections}  "
          f"failed={batch_stats.failed_sections}  manual_review={batch_stats.manual_review_sections}")
    print(f"wiki markdown đã commit vào: {os.path.abspath('./data/wiki')}")

    # -------------------------------------------------------------------
    # B2.5 — INPUT: source_id (đọc kg_nodes/kg_edges vừa persist ở C)
    #        OUTPUT: list[ChunkRecord] (type=community), tự persist bên trong
    #        Lịch chạy thật: batch job định kỳ, không phải mỗi lần ingest —
    #        ở đây gọi ngay sau C chỉ để demo end-to-end chạy được.
    # -------------------------------------------------------------------
    # step("B2.5 — build_community_summaries(source_id, llm) -> list[ChunkRecord]")
    community_records = b2_5_community_detection.build_community_summaries(source_id, get_llm_strong)
    print(f"community summaries: {len(community_records)}")
    for c in community_records:
        print(f"  [{c.id}] {c.content[:100]!r}  (members={len(c.children)})")

    # =====================================================================
    # KNOWLEDGE BASE ĐÃ SẴN SÀNG — bây giờ thử truy vấn (D -> E)
    # =====================================================================
    step("TRUY VẤN KNOWLEDGE BASE VỪA TẠO")
    query_text = "Hỗ trợ học viên."
    print(f"query: {query_text!r}")

    # D — INPUT: RetrievalQuery  ->  OUTPUT: RetrievalResult (dense+bm25+graph, RRF, rerank, self-verify)
    # retrieval_query = RetrievalQuery(query_text=query_text, top_k_final=10, source_id=source_id)
    # retrieval = d_retrieval.retrieve(retrieval_query, get_objectllm())
    # print(f"\nD — retrieve(): insufficient_context={retrieval.insufficient_context}  "
    #       f"candidates={len(retrieval.candidates)}")
    # for c in retrieval.candidates:
    #     print(f"  [{c.source}/{c.origin}] score={c.relevance_score:.3f}  "
    #           f"relation={c.relation}  {c.raw[:80]!r}")

    # E — INPUT: RetrievalResult  ->  OUTPUT: AnswerWithCitations (câu trả lời cuối)
    # original_query=retrieval_query (đề xuất #14) bật retry retrieve() 1 lượt
    # bằng retrieval_gap_terms nếu insufficient_context=True — bỏ qua tham số
    # này (None) để giữ hành vi cũ, không retry.
    # answer = e_query_output.answer_query(query_text, retrieval, get_objectllm(),
    #                                       original_query=retrieval_query)
    # print(f"\nE — answer_query():")
    # print(f"answer: {answer.answer}")
    # print(f"citations:")
    # for c in answer.citations:
    #     print(f"  [#{c.atom_id}] {c.raw!r}  ({c.location})")


if __name__ == "__main__":
    main()
