"""
A4 — Pass 1: Constraint Extraction (per-section, queued)

INPUT:  common.schemas.SectionJobInput (one row popped from `section_jobs`)
OUTPUT: common.schemas.SectionExtractionResult
        -> `.verified` elements are what feed into A5 / B1

Queue: Postgres `section_jobs` table + `FOR UPDATE SKIP LOCKED`
       (replaces Celery + Redis — see common/db.py claim_next_job / mark_job_*)

Run `python worker.py` (repo root) to start 1..N workers pulling from the
queue; see `worker_loop()` below for the core loop (mã giả #11b).
"""
from __future__ import annotations

import json
import time
from rapidfuzz import fuzz

from common import db
from common.config import settings
from common.llm_client import LLMClient, get_llm_client,extract_and_parse_json
from common.text_norm import normalize_for_comparison
from common.schemas import (
    SectionJobInput, SectionExtractionResult, ExtractedElement, ElementLabel,
    VerificationResult,CrossLink
)

INTRA_SECTION_RELATION_SYSTEM_PROMPT = """Bạn là hệ thống phân tích quan hệ nội-section giữa các đoạn tri thức.
Bạn sẽ nhận một danh sách các đoạn
văn bản (element) đã được trích xuất từ CÙNG MỘT section (đoạn/mục) của một tài liệu, kèm văn bản gốc đầy đủ của
section đó để làm ngữ cảnh.

Nhiệm vụ: tìm các CẶP element trong danh sách có quan hệ tri thức thật sự với nhau (không phải mọi cặp đều có quan
hệ — hầu hết các cặp có thể không có quan hệ đáng ghi nhận nào cả).

HEADING (nếu có 1 element với label="heading" trong danh sách): đây là TIÊU ĐỀ của section, nêu chủ thể/đơn vị/phạm
vi mà các element khác có thể đang mô tả — ví dụ heading "Khối IT". Với các cặp (heading, element khác), KHÔNG áp
dụng mức độ hoài nghi mặc định "hầu hết không có quan hệ" ở trên — hầu hết element trong 1 section THƯỜNG có ít nhất
1 quan hệ với heading của chính section đó, vì heading chính là chủ đề bao trùm. Chỉ bỏ qua cặp (heading, element)
khi element đó rõ ràng đang nói về 1 chủ thể/chủ đề KHÁC, không phụ thuộc heading. Phân loại quan hệ heading-element
theo đúng 2 mức sau (from LUÔN là heading, to LUÔN là element kia):
  - MẠNH -> relation="DEFINES": element là phần tiếp nối trực tiếp của heading (heading nêu chủ ngữ, element là vị
    ngữ/thuộc tính của đúng chủ ngữ đó). Ví dụ: heading "Khối IT", element "Trưởng khối: Trần A".
  - YẾU -> relation="RELATED_TO": element không tiếp nối trực tiếp cấu trúc câu của heading, nhưng rõ ràng đang nói
    về chủ thể của heading. Ví dụ: heading "Khối IT", element "Số lượng nhân sự là 20" (số 20 là thuộc tính của
    Khối IT dù câu không lặp lại chữ "Khối IT").
  - KHÔNG quan hệ: element nói về chủ đề hoàn toàn khác, không phụ thuộc heading — bỏ qua, không báo cáo cặp này.
evidence_raw cho 1 quan hệ heading-element có thể trích từ CHÍNH VĂN BẢN HEADING (không chỉ từ section_text) — heading
cũng là văn bản gốc thật, được hệ thống verify riêng, không cần evidence_raw phải nằm trong section_text nếu nó đúng
là 1 chuỗi con của heading.

Với các cặp element-element (không có heading), tiếp tục giữ nguyên mức độ hoài nghi mặc định ở trên. Với mỗi cặp có
quan hệ thật, trả về:
{"from": <idx của element nguồn, vd "E1">, "to": <idx của element đích, vd "E2">,
 "relation": "DEFINES" | "EXTENDS" | "CONTRADICTS" | "RELATED_TO",
 "evidence_raw": <cụm từ NGUYÊN VĂN xuất hiện trong văn bản gốc section (hoặc trong heading, xem mục HEADING ở
 trên), làm bằng chứng cho quan hệ này>}

Định nghĩa các loại quan hệ:
- DEFINES: element này định nghĩa/giải thích khái niệm được nhắc tới ở element kia (hoặc: heading định danh chủ thể
  mà element là vị ngữ/thuộc tính trực tiếp — xem mục HEADING).
- EXTENDS: element này bổ sung chi tiết/mở rộng cho thông tin ở element kia (không định nghĩa, không mâu thuẫn).
- CONTRADICTS: hai element đưa ra thông tin/yêu cầu trái ngược nhau về cùng 1 đối tượng.
- RELATED_TO: liên quan rõ ràng nhưng không thuộc 3 loại trên (hoặc: element chỉ liên quan YẾU tới chủ thể của
  heading — xem mục HEADING).

QUY TẮC BẮT BUỘC:
1. from/to CHỈ được là idx đã xuất hiện trong danh sách gửi lên (E1, E2, ...) — không tự tạo idx mới, không dùng lại
   cùng 1 idx cho cả from và to.
2. evidence_raw PHẢI là chuỗi con nguyên văn (không diễn giải, không dịch, không tóm tắt) của văn bản gốc section
   (hoặc của heading, nếu quan hệ đó là quan hệ heading-element — xem mục HEADING).
3. KHÔNG báo cáo quan hệ SAME_SECTION — quan hệ đó đã được hệ thống tự động ghi nhận cho mọi cặp cùng section rồi,
   không cần bạn xác nhận lại; chỉ báo cáo 4 loại quan hệ ngữ nghĩa cụ thể ở trên.
4. Nếu không chắc chắn có quan hệ thật, KHÔNG trả — thà bỏ sót còn hơn báo sai (NGOẠI TRỪ cặp heading-element, xem
   mục HEADING: ở đó mặc định là CÓ quan hệ YẾU trừ khi rõ ràng không liên quan).
5. Chỉ trả JSON, không thêm lời dẫn, không thêm markdown code fence.

Định dạng output: {"relations": [ {...}, {...} ]}
"""

EXTRACTION_SYSTEM_PROMPT = (
    "You extract knowledge elements from one section of an IT document. "
    "For every important sentence/fact, output an element with:\n"
    "  - label: one of FACT, DEFINITION, CONSTRAINT, EXAMPLE, WARNING, OTHER\n"
    "  - raw: the EXACT verbatim substring copied from the section text (no paraphrasing here)\n"
    "  - normalized: a SELF-CONTAINED rewrite of the same fact that can be read and "
    "understood on its own, with NO surrounding context. Pull in whatever subject, "
    "heading, or antecedent the raw excerpt depends on (e.g. if the section says "
    "'Nha may cam ket: dam bao luong dung han, cung cap bao ho lao dong' and raw is "
    "'dam bao luong dung han', normalized must be 'Nha may cam ket dam bao luong dung "
    "han.', not the bare clause). normalized MAY paraphrase and MAY reuse wording found "
    "elsewhere in the section (an earlier clause, the subject of the sentence) to make "
    "the fact stand alone, but must NOT introduce any fact, number, or entity that is "
    "not present anywhere in the section text or the section heading (see HEADING "
    "RELATION rule below for the one exception: reusing the heading itself).\n"
    "HEADING RELATION (if a 'Section heading' is provided separately above the section "
    "text): for EACH element, first decide what relation the element has with the heading:\n"
    "  - STRONG/DIRECT relation: the raw is a direct continuation of the heading (heading provides "
    "the subject, raw provides the predicate/attribute of that exact subject) — e.g. heading 'IT Department', "
    "raw 'Head: Tran A' => normalized MUST incorporate the subject from the heading: 'Head of IT Department is Tran A.'\n"
    "  - WEAK relation: the raw does not directly continue the heading's sentence structure, but clearly "
    "talks about the SUBJECT of the heading — e.g. heading 'IT Department', raw 'Number of staff is 20' => normalized MUST "
    "incorporate the subject from the heading: 'IT Department has 20 staff.', NOT leave it as 'Number of staff is 20' (dangling, unclear which unit it belongs to if taken out of the section).\n"
    "  - NO relation: the raw discusses a completely different subject/topic, not dependent on the heading "
    "(e.g., a company-wide regulation mentioned within this section, not specific to the heading's subject) => KEEP normalized "
    "according to the usual self-contained rule above, DO NOT force the heading into it — do not invent a relation "
    "that does not really exist just because a heading is provided.\n"
    "Heading text provided to you is REAL text from the document (not a guess), so reusing it in normalized in the above two cases "
    "is NOT considered 'inventing' — but ONLY when the element genuinely has a strong or weak relation to the heading.\n"
    "IMPORTANT - While you may paraphrase and rephrase the sentence for clarity, "
    "you MUST preserve ALL of the following types of information from the original `raw`: "
    "numbers, quantities, dates, percentages, names of entities, values, thresholds, "
    "versions, conditions, and any technical details. You may NOT omit, change, or "
    "generalize any of these elements. The paraphrase must be a faithful representation "
    "of the original, containing the same factual content. If a paraphrase would lose "
    "even one of these key details, you must instead use the exact raw text.\n"
    "Example: raw='The server must have at least 16GB RAM' -> normalized='Server requirement: must have at least 16GB RAM' (keeping '16GB RAM').\n"
    "Example: raw='Timeout should be 30 seconds' -> normalized='Timeout must be 30 seconds' (same value).\n"
     "IMPORTANT - do not shred a single idea: if a sentence is a comma-separated list "
    "of clauses that all express ONE point (e.g. 'phai nhe, ben, va chong tham' "
    "describing one requirement), output that as ONE element, not one element per "
    "clause. Only split into separate elements when the clauses are genuinely "
    "distinct, independently-citable facts (e.g. separate obligations in a list of "
    "commitments), and even then normalized must carry the shared subject into EVERY "
    "resulting element so none of them reads as a dangling fragment.\n"
    "  - entities: a list of the important named things (technologies, standards, "
    "organizations, people, products, protocols, machines/equipment, regulations, "
    "locations, or any other domain-specific named entity actually relevant to THIS "
    "document's domain — do not restrict yourself to IT/tech terms, use whatever "
    "types genuinely fit the document) that this specific element mentions. Each "
    "entity is {\"name\": <verbatim name as it appears in raw>, \"type\": <short "
    "free-text type label you choose, e.g. \"technology\", \"organization\", "
    "\"regulation\", \"equipment\">}. Only include entities that are genuinely "
     "important to identify/link this element to others — skip incidental words. If "
    "the HEADING RELATION rule above made you fold the heading's subject into "
    "normalized (strong or weak relation), also add that subject to `entities` if it "
    "is a genuine named entity (e.g. \"Khối IT\") — it is fine for entities to be an "
    "empty list otherwise.\n"
    "  - COREFERENCE: if `raw` refers to an entity only via a pronoun or vague "
    "reference (\"nó\", \"hệ thống này\", \"thiết bị đó\", \"cái này\"...) instead of "
    "its name, and you already resolved that reference to a real name when writing "
    "`normalized` (per the antecedent-pulling rule above), ALSO include that "
    "resolved entity in THIS element's `entities` list — using the literal name it "
    "was called when first introduced in the section, exactly as you wrote it in "
    "`normalized`, not the pronoun itself. This only applies to references you can "
    "resolve with a NAMED antecedent already introduced earlier in THIS SAME "
    "section; if you can't confidently resolve it, leave it out — do not guess.\n"
    "CRITICAL RULE FOR normalized:\n"
    "- normalized MUST CONTAIN ALL WORDS from the original `raw` text, in the same order, verbatim.\n"
    "- You may ONLY ADD extra words (subject, heading, context) at the BEGINNING or the END of the sentence to make it self-contained.\n"
    "- You MUST NOT REMOVE, OMIT, REPHRASE, or REPLACE any word that appears in `raw` — even if it seems unimportant or redundant.\n"
    "- If you need to add context, do it like this: \"[Added subject] + [exact raw text]\".\n"
    "- Example: raw=\"phải nhẹ, bền, và chống thấm\" → normalized=\"[Yêu cầu sản phẩm] phải nhẹ, bền, và chống thấm\" (keeps ALL words).\n"
    "- Example: raw=\"timeout=30s\" → normalized=\"[Cấu hình] timeout=30s\" (keeps 'timeout=30s').\n"
    "- If you cannot add context without breaking this rule, use the exact raw text as normalized.\n"
    "Return ONLY JSON: {\"elements\": [{\"label\":..., \"raw\":..., \"normalized\":..., "
    "\"entities\": [{\"name\":..., \"type\":...}]}, ...]}. "
    "Never invent text that is not present in the section (or, per the HEADING "
    "RELATION rule, the heading), and never invent an entity name that doesn't "
    "actually appear (verbatim, as an obvious short form/abbreviation, OR as a "
    "resolved coreference per the COREFERENCE rule above) anywhere in the section "
    "text or heading.\n"
    "IMPORTANT: normalized MUST be written in Vietnamese, regardless of the original. \n"
    "IMPORTANT: You MUST extract the ENTIRE text from the section; you are not allowed to skip any part. Every sentence or paragraph must be represented in an element (they may be split or merged), but the total of all raw fields from all elements must fully cover the original content. If a piece of text does not fit any of the labels FACT, DEFINITION, CONSTRAINT, EXAMPLE, or WARNING, assign it the label OTHER."
)

# FIX: this constant was referenced in call_llm_verify_equivalence() but never
# defined anywhere in the file. That raised a NameError on every call, which
# the surrounding `except Exception: return None` swallowed silently — so
# whenever settings.a4_llm_review_enabled was True, the borderline-score LLM
# arbitration step was a complete no-op (always fell through to the
# human-review / strict-reject path) with no visible error.
LLM_EQUIVALENCE_SYSTEM_PROMPT = (
    "You are a strict fact-checker. You will be given an ORIGINAL section of "
    "text and a CANDIDATE excerpt that an extraction model claims is a "
    "verbatim (or near-verbatim) substring of the ORIGINAL.\n"
    "Decide whether the CANDIDATE is faithfully supported by the ORIGINAL: "
    "same meaning, same entities, same direction of any comparison/constraint "
    "(do not accept a candidate that reverses which side of a comparison is "
    "larger/required/preferred, even if the same words appear on both sides).\n"
    "Minor paraphrasing, reordering, or dropped connector words are OK as "
    "long as the meaning is unchanged.\n"
    "Return ONLY JSON: {\"equivalent\": true or false}."
)




def _safe_entities(raw_entities) -> list[dict]:
    """Tolerant parse of the LLM's per-element `entities` list — untrusted
    input, so a malformed item (wrong type, missing key) is skipped rather
    than crashing the whole element. Verification that each entity name
    actually appears in `raw` happens later, at consolidation time (A4.5),
    not here — this stage only needs to not crash on garbage."""
    if not isinstance(raw_entities, list):
        return []
    out = []
    for item in raw_entities:
        if not isinstance(item, dict):
            continue
        name = item.get("name")
        if not name or not isinstance(name, str):
            continue
        etype = item.get("type")
        etype = str(etype).strip() if isinstance(etype, str) and etype.strip() else "OTHER"
        out.append({"name": name.strip(), "type": etype})
    return out


def call_llm_extract(llm: LLMClient, section_text: str, tier: str, heading: str | None = None) -> list[ExtractedElement]:
    if heading and settings.a4_pass_heading_to_extraction:
        prompt = (f"Section heading:\n\"\"\"\n{heading}\n\"\"\"\n\n"
                  f"Section text:\n\"\"\"\n{section_text}\n\"\"\"")
    else:
        prompt = f"Section text:\n\"\"\"\n{section_text}\n\"\"\""
    
    # print(section_text)
    if settings.a4_llm_rate_limit_seconds > 0:
        time.sleep(settings.a4_llm_rate_limit_seconds)
    raw = llm.generate(prompt, system=EXTRACTION_SYSTEM_PROMPT, json_mode=True, tier=tier)
    try:
        data = extract_and_parse_json(raw)
        # print(f"data {data}")
        items = data.get("elements", []) if isinstance(data, dict) else data
        # print(f"items {items}")
        out = []
        for item in items:
            label = item.get("label", "OTHER")
            if label not in ElementLabel.__members__:
                label = "OTHER"
            normalized = item.get("normalized")
            if isinstance(normalized, str):
                normalized = normalized.strip() or None
            else:
                normalized = None
            entities = _safe_entities(item.get("entities"))
            out.append(ExtractedElement(
                label=ElementLabel(label), raw=item.get("raw", ""), normalized=normalized,
                entities=entities,
            ))
        return out
    except Exception as e:
        print(f"Exception: {e}")
        return []

# `_normalize` moved to common.text_norm.normalize_for_comparison (shared
# with A3.5 hashing so both stages canonicalize text the exact same way).
# Kept as a thin alias here so nothing else in this file needs to change.
_normalize = normalize_for_comparison


def call_llm_verify_equivalence(llm: "LLMClient | None", element_raw: str, original_section_text: str) -> bool | None:
    """Layer 3b — ask the LLM to arbitrate a borderline score.

    Only ever called when settings.a4_llm_review_enabled is True. Returns
    True/False when the LLM gives a clear verdict, or None if the call fails
    or the response can't be parsed (caller treats None as "still
    inconclusive", not as either verdict).
    """
    if llm is None:
        return None
    prompt = (
        f"ORIGINAL section text:\n\"\"\"\n{original_section_text}\n\"\"\"\n\n"
        f"CANDIDATE excerpt:\n\"\"\"\n{element_raw}\n\"\"\""
    )
    try:
        raw = llm.generate(prompt, system=LLM_EQUIVALENCE_SYSTEM_PROMPT, json_mode=True, tier="strong")
        data = extract_and_parse_json(raw)
        verdict = data.get("equivalent") if isinstance(data, dict) else None
        return verdict if isinstance(verdict, bool) else None
    except Exception:
        return None

# Mã giả #10 — verification 2 tầng
def verify_element(element_raw: str, original_section_text: str, llm: "LLMClient | None" = None) -> VerificationResult:
    raw_norm = _normalize(element_raw)
    orig_norm = _normalize(original_section_text)
 
    if raw_norm and (raw_norm in orig_norm or orig_norm in raw_norm):
        return VerificationResult(status="VERIFIED", method="exact")

    # token_set_ratio compares the *set of tokens* on each side rather than
    # a strict character-by-character sequence, so it tolerates word
    # reordering and extra connector words the LLM might insert/drop —
    # things plain fuzz.ratio penalizes even when meaning is unchanged.
    similarity = fuzz.token_set_ratio(raw_norm, orig_norm)

    # print(f"simi {similarity}")

    if similarity >= settings.a4_fuzzy_match_threshold_high:
        # token_set_ratio being high only proves the same *bag of words* is
        # present on both sides — it is blind to order, so "A exceeds B" and
        # "B exceeds A" score identically. For a technical CONSTRAINT that
        # asymmetry can flip the meaning entirely. As a cheap guard, check
        # the order-sensitive token_sort_ratio too; if it drops sharply
        # relative to token_set_ratio, don't rubber-stamp VERIFIED — route
        # it into the same borderline handling as a true fuzzy match instead
        # of silently accepting a possibly meaning-reversed excerpt.
        order_sensitive = fuzz.token_sort_ratio(raw_norm, orig_norm)
        if (similarity - order_sensitive) < settings.a4_order_sensitivity_drop_threshold:
            return VerificationResult(status="VERIFIED", method="fuzzy", similarity=similarity)
        similarity = order_sensitive  # fall through to borderline handling below

    if similarity >= settings.a4_fuzzy_match_threshold_low:
        # Borderline band. Do nothing special unless a review path is on.
        if settings.a4_llm_review_enabled:
            verdict = call_llm_verify_equivalence(llm, element_raw, original_section_text)
            if verdict is True:
                return VerificationResult(
                    status="VERIFIED", method="llm_review", similarity=similarity, review_route="llm_review",
                )
            if verdict is False:
                return VerificationResult(
                    status="REJECTED", flag="hallucination_suspected", similarity=similarity, review_route="llm_review",
                )
            # verdict is None: the LLM check itself was inconclusive/failed —
            # fall through to the human-review switch below.

        if settings.a4_human_review_enabled:
            return VerificationResult(
                status="NEEDS_REVIEW", flag="borderline_score", similarity=similarity, review_route="human_review",
            )

        # Neither escalation switch is on -> preserve the old, strict
        # behavior so this is fully backward-compatible by default.
        return VerificationResult(status="REJECTED", flag="hallucination_suspected", similarity=similarity)

    return VerificationResult(status="REJECTED", flag="hallucination_suspected", similarity=similarity)


def upgrade_tier(tier: str) -> str:
    return "strong" if tier == "light" else tier


# Mã giả #11 — quyết định retry
def decide_job_outcome(job: SectionJobInput, result: SectionExtractionResult) -> str:
    confidence = (len(result.verified) / len(result.elements)) if result.elements else 0.0
    result.confidence = confidence
    if confidence >= settings.a4_confidence_done_threshold:
        return "DONE"
    if job.attempt < job.max_attempts:
        return "RETRY"
    return "MANUAL_REVIEW"


def process_section(job: SectionJobInput, func_get_llm: Callable[[], Any]) -> SectionExtractionResult:
    """Entry point for stage A4 — pure function, no DB side effects, so it can
    be lifted into its own microservice endpoint `POST /extract` untouched."""
    elements = []
    llm = func_get_llm()
    if job.section_text.strip():
        elements = call_llm_extract(llm, job.section_text, tier=job.llm_tier, heading=job.heading)

    if job.heading:
        # Kiểm tra xem heading đã tồn tại trong elements chưa (so sánh raw)
        exists = any(e.raw.strip() == job.heading.strip() for e in elements)
        if not exists:
            heading_element = ExtractedElement(
                label=ElementLabel.HEADING,
                raw=job.heading,
                normalized=f"{job.heading}"
            )
            # Chèn vào đầu danh sách
            elements.insert(0, heading_element)
            print(f"[A4] Added heading from parse for section {job.section_id}: {job.heading[:50]}...")

    verified, rejected, needs_review = [], [], []

    for el in elements:
        if el.label == ElementLabel.HEADING:
        # Heading đến từ A1 parser, không phải LLM trích xuất -> không cần
        # verify chống-hallucination. job.section_text cố ý không chứa
        # heading nên verify_element sẽ luôn/gần luôn REJECTED một cách
        # giả tạo nếu áp dụng cho heading.
            verified.append(el)
            continue
        v = verify_element(el.raw, job.section_text)
        if v.status == "VERIFIED":
            verified.append(el)
        elif v.status == "NEEDS_REVIEW":
            # Distinct from REJECTED on purpose: this is what
            # a4_human_review_enabled escalates borderline-score elements
            # to. Previously these were bucketed with `rejected` downstream,
            # which made the human-review switch a no-op (same outcome as
            # a hard reject either way).
            needs_review.append(el)
        else:
            rejected.append(el)

     
            
    print(f"[A4-DEBUG] After heading injection: {len(elements)} elements:")
    for i, el in enumerate(elements):
        print(f"  [{i}] label={el.label}, raw={el.raw[:80]!r}")

    # MỚI — call LLM thứ 2 (tier "light"), chỉ chạy trên `verified` (không
    # bao giờ trỏ tới element bị reject). Tìm quan hệ ngữ nghĩa giữa các
    # element CÙNG section — phần A4.8/A5 chủ động bỏ qua (chỉ xử lý cặp
    # khác section), xem docstring extract_intra_section_relations().
    intra_links: list[CrossLink] = []
    llm = func_get_llm()
    if settings.a4_intra_section_relations_enabled:
        intra_links = extract_intra_section_relations(llm, job.section_text, verified)
        if intra_links:
            print(f"[A4] intra_links (cùng section {job.section_id}): {len(intra_links)}")
            for cl in intra_links:
                print(f"  {cl.from_id} --{cl.relation}--> {cl.to_id}  (evidence: {cl.evidence_raw!r})")

    result = SectionExtractionResult(
        job_id=job.job_id, source_id=job.source_id, section_id=job.section_id,
        elements=elements, verified=verified, rejected=rejected, needs_review=needs_review,intra_links=intra_links,
    )
    result.outcome = decide_job_outcome(job, result)
    return result





def _persist_verified_elements(job: SectionJobInput, result: SectionExtractionResult) -> None:
    """Hand verified elements onward to B1 (dedup). Kept as a separate,
    replaceable function: in a microservice split this becomes an outbound
    call (queue message / API POST) to the "dedup-service" instead of a
    direct in-process import."""
    from stages.b1_dedup import dedup_and_store
    dedup_and_store(job.source_id, job.section_id, result.verified)

def _verify_evidence_in_section(evidence_raw: str, section_text: str, heading_text: str | None = None) -> bool:
    """Cùng triết lý 2 tầng như verify_element()/A5._verify_evidence(): exact
    substring trước, fuzzy match làm phương án dự phòng cho việc LLM gõ lại
    hơi khác — không bao giờ tin evidence_raw một cách mù quáng, đây là cách
    ngăn cạnh KG bị hallucinate."""
    if not evidence_raw:
        return False
    combined = f"{heading_text}\n{section_text}" if heading_text else section_text
    if evidence_raw in combined:
        return True
    return fuzz.partial_ratio(evidence_raw, combined) >= settings.fuzzy_match_threshold


def extract_intra_section_relations(llm: "LLMClient | None", section_text: str,
                                     verified_elements: list[ExtractedElement]) -> list[CrossLink]:
    """A4 — bước phụ (call LLM thứ 2, tier "light"), chạy SAU verify_element().

    Tìm quan hệ DEFINES/EXTENDS/CONTRADICTS/RELATED_TO giữa các element VERIFIED
    trong CÙNG 1 section — phần mà A4.8/A5 chủ động bỏ qua (chỉ xử lý cặp KHÁC
    section). Vì chỉ chạy trên `verified_elements` (đã qua verify_element), một
    quan hệ được trả về không bao giờ có thể trỏ tới 1 element bị REJECTED.

    Trả về [] (không raise) nếu: <2 element hợp lệ, LLM lỗi, hoặc response
    không parse được — không để lỗi ở bước phụ này làm hỏng cả job A4 chính.
    """
    

    eligible = list(verified_elements) if settings.a4_include_heading_in_intra_section_relations \
        else [e for e in verified_elements if e.label != ElementLabel.HEADING]
    
    if len(eligible) < 2 or llm is None:
        return []

    heading_el = next((e for e in eligible if e.label == ElementLabel.HEADING), None)
    heading_text = heading_el.raw if heading_el else None

    idx_to_id = {f"E{i+1}": e.id for i, e in enumerate(eligible)}
    payload = {
        "section_text": section_text,
        "elements": [{"idx": f"E{i+1}", "raw": e.raw, "label": e.label.value}
                     for i, e in enumerate(eligible)],
    }

    if settings.a4_llm_rate_limit_seconds > 0:
        time.sleep(settings.a4_llm_rate_limit_seconds)
    try:
        raw = llm.generate(json.dumps(payload, ensure_ascii=False),
                            system=INTRA_SECTION_RELATION_SYSTEM_PROMPT, json_mode=True, tier="light")
        data = extract_and_parse_json(raw)
        items = data.get("relations", []) if isinstance(data, dict) else []
    except Exception as e:
        print(f"[A4] extract_intra_section_relations lỗi, bỏ qua: {e}")
        return []

    links: list[CrossLink] = []
    seen: set[tuple[str, str, str]] = set()
    for item in items:
        if not isinstance(item, dict):
            continue
        from_id = idx_to_id.get(str(item.get("from", "")).strip())
        to_id = idx_to_id.get(str(item.get("to", "")).strip())
        evidence_raw = (item.get("evidence_raw") or "").strip()
        relation = str(item.get("relation", "")).strip().upper()

        if not from_id or not to_id or from_id == to_id:
            continue  # idx không hợp lệ / tự trỏ tới chính nó
        if relation not in {"DEFINES", "EXTENDS", "CONTRADICTS", "RELATED_TO"}:
            relation = "RELATED_TO"  # evidence vẫn được verify bên dưới; hạ cấp nhãn thay vì bỏ hẳn 1 quan hệ thật
        if not _verify_evidence_in_section(evidence_raw, section_text, heading_text):
            continue  # không có bằng chứng nguyên văn -> không tạo cạnh (chống hallucination)

        key = (from_id, to_id, relation)
        if key in seen:
            continue
        seen.add(key)
        links.append(CrossLink(from_id=from_id, to_id=to_id, relation=relation, evidence_raw=evidence_raw))

    return links