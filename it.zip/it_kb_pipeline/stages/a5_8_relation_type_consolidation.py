"""
A5.8 — Relation-type consolidation (đề xuất cải tiến #5, ưu tiên THẤP)

VẤN ĐỀ: stages/a5_5_fact_extraction.py::_canonical_relation_type chỉ fold
`upper().strip()` — "TĂNG_TẢI" và "INCREASES_LOAD" là 2 relation_type khác
nhau trong kg_facts dù cùng nghĩa. Với multi-hop, điều này có thể tách 1
cạnh lẽ ra nối liền thành 2 Fact riêng biệt (không cộng dồn evidence/
confidence cho nhau — xem A5.5's min(evidence_count/3, 1.0) sau khi sửa mục
3 — và nếu entity_path_search build sub-query gap-fill dùng đúng chuỗi
relation_type, có thể sinh câu hỏi phụ bằng 1 trong 2 tên mà tài liệu chỉ
dùng tên còn lại).

CÁCH SỬA: sau khi A5.5 chạy xong TOÀN BỘ atom của 1 document (không phải
per-batch — cần thấy hết mọi relation_type distinct mới cluster đúng), thêm
1 bước dedupe-candidates-style (lexical fuzzy + embedding, union-find) áp
cho tập relation_type distinct — CÙNG cơ chế a4_5_entity_consolidation đã
làm cho entity name, chỉ đổi input từ tên entity sang relation_type string.
Sau khi có canonical_map, các Fact có cùng (source_entity_id,
target_entity_id, canonical_relation_type) được GỘP lại thành 1 Fact
(evidence hợp nhất, confidence tính lại bằng cùng công thức
min(distinct_evidence_count / 3.0, 1.0) đã dùng ở A5.5/B2 — xem mục 3).

INPUT:  list[Fact], list[FactEvidence] — TOÀN BỘ facts + evidence mà A5.5
        vừa tạo cho 1 source_id, cùng LLMClient (dùng để embed, tái sử dụng
        client đã truyền cho A5.5, không cần client riêng).
OUTPUT: (list[Fact], list[FactEvidence]) — cùng shape, relation_type đã
        canonical hoá, facts trùng lặp sau canonical hoá đã được gộp.

VỊ TRÍ CHẠY: trong create_kb_from_file.py, ngay sau bước "A5.5 —
extract_facts(...)", TRƯỚC khi facts/fact_evidence được ghi vào kg_facts (ở
B2/C storage) — xem create_kb_from_file.py::step("A5.8 — ...").
"""
from __future__ import annotations

import logging
import math
from collections import defaultdict
from typing import Optional

from rapidfuzz import fuzz

from common.config import settings
from common.llm_client import LLMClient
from common.schemas import Fact, FactEvidence

logger = logging.getLogger(__name__)


class _UnionFind:
    """Giống hệt stages/a4_5_entity_consolidation.py::_UnionFind — copy nhỏ
    tại đây thay vì import chéo giữa 2 stage cùng cấp (A5.5/A5.8), tránh
    tạo phụ thuộc ngược không cần thiết giữa các file stage độc lập."""

    def __init__(self, n: int):
        self.parent = list(range(n))

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[ra] = rb


def _cosine(u: list[float], v: list[float]) -> float:
    dot = sum(x * y for x, y in zip(u, v))
    nu = math.sqrt(sum(x * x for x in u))
    nv = math.sqrt(sum(y * y for y in v))
    if nu == 0 or nv == 0:
        return 0.0
    return dot / (nu * nv)


def cluster_relation_types(relation_types: list[str], llm: LLMClient) -> dict[str, str]:
    """Trả về map relation_type_gốc -> relation_type_canonical.

    Cùng công thức a4_5_entity_consolidation.entity_similarity: lexical
    (rapidfuzz.fuzz.token_sort_ratio) OR blend(lexical, embedding) vượt
    ngưỡng -> union. Khác 1 chỗ: relation_type là slug UPPER_SNAKE_CASE
    (INCREASES_LOAD), không phải câu tự nhiên — de-slug thành từ có khoảng
    trắng trước khi embed, để "TĂNG_TẢI" và "INCREASES_LOAD" (khác ngôn ngữ,
    cùng nghĩa) có cơ hội nằm gần nhau trong embedding space thay vì so
    khớp 2 chuỗi ký tự không liên quan về mặt chữ cái.
    """
    uniq = list(dict.fromkeys(r for r in relation_types if r))
    if len(uniq) <= 1:
        return {r: r for r in uniq}

    embeddings: list[Optional[list[float]]] = [None] * len(uniq)
    try:
        readable = [r.replace("_", " ").strip().lower() for r in uniq]
        embeddings = llm.embed(readable)
    except Exception:
        pass  # fall back to lexical-only, same graceful-degrade as A4.5

    n = len(uniq)
    uf = _UnionFind(n)
    for i in range(n):
        for j in range(i + 1, n):
            lex_pct = fuzz.token_sort_ratio(uniq[i].lower(), uniq[j].lower())
            emb_sim = 0.0
            if embeddings[i] is not None and embeddings[j] is not None:
                emb_sim = _cosine(embeddings[i], embeddings[j])
            combined = (settings.a4_5_entity_lex_weight * (lex_pct / 100.0)
                        + settings.a4_5_entity_emb_weight * emb_sim)
            if lex_pct >= settings.a4_5_entity_lexical_threshold or combined >= settings.a4_5_entity_embed_threshold:
                uf.union(i, j)

    groups: dict[int, list[int]] = defaultdict(list)
    for i in range(n):
        groups[uf.find(i)].append(i)

    canonical_map: dict[str, str] = {}
    for idxs in groups.values():
        # Canonical = chuỗi NGẮN NHẤT trong nhóm — khác entity name (nơi
        # tên DÀI hơn thường mô tả rõ hơn), 1 relation_type ngắn thường là
        # dạng động từ tổng quát hơn (TRIGGERS thay vì
        # TRIGGERS_IMMEDIATELY_AFTER); tie-break theo thứ tự xuất hiện đầu
        # tiên để deterministic.
        canonical = min((uniq[i] for i in idxs), key=lambda r: (len(r), r))
        for i in idxs:
            canonical_map[uniq[i]] = canonical
    return canonical_map


def consolidate_relation_types(facts: list[Fact], fact_evidence: list[FactEvidence],
                                llm: LLMClient) -> tuple[list[Fact], list[FactEvidence]]:
    """Entry point cho stage A5.8. Không raise — trường hợp xấu nhất (embed
    lỗi, hoặc 0 facts) trả lại facts/fact_evidence y nguyên."""
    if not facts:
        return facts, fact_evidence

    relation_types = [f.relation_type for f in facts]
    canonical_map = cluster_relation_types(relation_types, llm)
    if all(canonical_map.get(r, r) == r for r in relation_types):
        return facts, fact_evidence  # không có cụm nào cần gộp — không đổi gì

    evidence_by_fact: dict[str, list[FactEvidence]] = defaultdict(list)
    for ev in fact_evidence:
        evidence_by_fact[ev.fact_id].append(ev)

    # key = (source_entity_id, target_entity_id, canonical_relation_type)
    merged: dict[tuple[str, str, str], dict] = {}
    for f in facts:
        canonical_relation = canonical_map.get(f.relation_type, f.relation_type)
        key = (f.source_entity_id, f.target_entity_id, canonical_relation)
        bucket = merged.setdefault(key, {"source_id": f.source_id, "evidence": []})
        existing_pairs = {(e.atom_id, e.evidence_raw) for e in bucket["evidence"]}
        for ev in evidence_by_fact.get(f.id, []):
            pair = (ev.atom_id, ev.evidence_raw)
            if pair not in existing_pairs:
                existing_pairs.add(pair)
                bucket["evidence"].append(ev)

    new_facts: list[Fact] = []
    new_evidence: list[FactEvidence] = []
    for (src, tgt, relation), bucket in merged.items():
        # Cùng công thức min(count/3, 1.0) đã thống nhất ở mục 3 — gộp
        # relation_type không nên có công thức confidence riêng.
        confidence = min(len(bucket["evidence"]) / 3.0, 1.0) if bucket["evidence"] else 0.0
        fact_id = f"fact58_{src}_{tgt}_{relation}"
        new_facts.append(Fact(id=fact_id, source_id=bucket["source_id"], source_entity_id=src,
                               target_entity_id=tgt, relation_type=relation, confidence=confidence))
        for ev in bucket["evidence"]:
            new_evidence.append(FactEvidence(fact_id=fact_id, atom_id=ev.atom_id,
                                              evidence_raw=ev.evidence_raw, confidence=ev.confidence))

    n_distinct_before = len(set(relation_types))
    n_distinct_after = len(set(canonical_map.values()))
    logger.info(
        "A5.8: %d facts (%d relation_type distinct) -> %d facts (%d relation_type distinct sau gộp)",
        len(facts), n_distinct_before, len(new_facts), n_distinct_after,
    )
    return new_facts, new_evidence
