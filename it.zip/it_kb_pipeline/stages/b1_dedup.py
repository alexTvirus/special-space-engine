"""
B1 — Dedup 3 tầng

INPUT:  list[ExtractedElement] (verified elements for one section, from A4)
        + implicit context: everything already stored in `knowledge_atoms`
OUTPUT: common.schemas.DedupReport
        -> `.kept` atoms are what get embedded/persisted and later chunked by B2

Tier 1 (exact hash) and Tier 2 (pgvector similarity) are pure code / SQL.
Tier 3 (LLM judge) only runs on the handful of *candidates* tier 2 flagged.
"""
from __future__ import annotations

import hashlib
import time
from common import db
from common.llm_client import LLMClient, get_llm_client , extract_and_parse_json
from common.config import settings
from common.schemas import ExtractedElement, KnowledgeAtom, DedupReport, MergeDecision


# Mã giả #12 — tầng 1
def exact_dedup(elements: list[ExtractedElement]) -> tuple[list[dict], list[ExtractedElement]]:
    hash_map: dict[str, ExtractedElement] = {}
    merges, remaining = [], []
    for e in elements:
        h = hashlib.sha256(e.raw.encode("utf-8")).hexdigest()
        if h in hash_map:
            merges.append({"kept": hash_map[h].id, "dropped": e.id, "merged_into": hash_map[h].id})
        else:
            hash_map[h] = e
            remaining.append(e)
    return merges, remaining


# Mã giả #12b — tầng 2, dùng pgvector qua common/db.find_similar_atoms
def vector_candidates(embedding: list[float], label: str | None = None) -> list[dict]:
    # label filter is critical: two CONSTRAINT/FACT atoms about the same topic
    # but different concrete values (e.g. "timeout = 30s" vs "timeout = 60s"),
    # or a CONSTRAINT vs a WARNING on the same topic, must never be compared
    # as dedup candidates just because their embeddings are close.
    return db.find_similar_atoms(embedding, settings.dedup_similarity_threshold, label=label)


# Tầng 3 — LLM judge
JUDGE_SYSTEM_PROMPT = (
    "Two text snippets were flagged as semantically similar. Decide if they express "
    "the SAME concept and the SAME concrete details (should be merged), or are only "
    "superficially/topically similar (must stay separate).\n"
    "Rules:\n"
    "- If they differ in any concrete value — numbers, thresholds, versions, "
    "  names, dates, units, file paths, config keys — they are NOT the same "
    "  concept, even if the sentence structure is nearly identical.\n"
    "- Only mark same_concept=true if merging would lose no information: every "
    "  specific detail in A is also present in B (or a strict superset/subset "
    "  of the same fact), and vice versa.\n"
    "- When unsure, prefer same_concept=false with low confidence — a missed "
    "  merge is cheap, an incorrect merge silently destroys information.\n"
    'Return ONLY JSON: {"same_concept": true|false, "confidence": 0.0-1.0}'
)


def llm_judge_duplicate(llm: LLMClient, raw_a: str, raw_b: str) -> tuple[bool, float]:
    import json
    prompt = f"Snippet A:\n{raw_a}\n\nSnippet B:\n{raw_b}"
    time.sleep(5)
    raw = llm.generate(prompt, system=JUDGE_SYSTEM_PROMPT, json_mode=True, tier="light")
    try:
        data = extract_and_parse_json(raw)
        return bool(data.get("same_concept", False)), float(data.get("confidence", 0.0))
    except Exception:
        return False, 0.0


def dedup_and_store(source_id: str, section_id: str, verified_elements: list[ExtractedElement],
                     llm: LLMClient | None = None) -> DedupReport:
    """Entry point for stage B1. Called by the A4 worker after each section
    job finishes; equally callable as a standalone `POST /dedup` endpoint."""
    merges, remaining = exact_dedup(verified_elements)

    kept: list[KnowledgeAtom] = []
    dropped_ids = [m["dropped"] for m in merges]
    if remaining:
        # Prefer `normalized` (self-contained, context-restored text produced
        # by A4) as the embedding input; `raw` is kept only for verbatim
        # verification/citation, not for semantic search. Falls back to
        # `raw` for any element an older A4 run left `normalized=None` on.
        embeddings = llm.embed([e.normalized or e.raw for e in remaining])
    else:
        embeddings = []

    for element, embedding in zip(remaining, embeddings):
        candidates = vector_candidates(embedding, label=element.label.value)
        is_duplicate = False
        for cand in candidates:
            same, confidence = llm_judge_duplicate(llm, element.raw, cand["raw"])
            # DEBUG: remove once the drop-rate issue is confirmed fixed.
            # Prints the actual similarity score pgvector returned + what the
            # LLM judge decided, so you can see WHY something got dropped
            # instead of guessing.
            print(
                f"[B1 DEBUG] element={element.id} label={element.label.value} "
                f"vs cand={cand['id']} pgvector_sim={cand.get('similarity'):.4f} "
                f"judge_same={same} judge_confidence={confidence:.2f}\n"
                f"    A: {element.raw[:80]!r}\n    B: {cand['raw'][:80]!r}"
            )
            if same and confidence >= 0.9:
                merges.append({"kept": cand["id"], "dropped": element.id, "merged_into": cand["id"]})
                dropped_ids.append(element.id)
                is_duplicate = True
                break
        if is_duplicate:
            continue

        atom = KnowledgeAtom(
            id=element.id, source_id=source_id, section_id=section_id,
            label=element.label, raw=element.raw, normalized=element.normalized,
            confidence=1.0, embedding=embedding,
            entities=element.entities,   # ← A4.5/B2 MENTIONS depend on this being copied forward
        )

        print(f"[B1-DEBUG] Creating atom:")
        print(f"  id={atom.id}")
        print(f"  section_id={atom.section_id}")
        print(f"  label={atom.label}")
        print(f"  raw={atom.raw[:100]!r}")
        print(f"  normalized={atom.normalized[:100] if atom.normalized else 'None'}")
        print(f"  entities={atom.entities}")
        print(f"  embedding_dim={len(atom.embedding) if atom.embedding else 0}")
        print("-" * 50)

        db.upsert_knowledge_atom(atom)
        kept.append(atom)

    return DedupReport(source_id=source_id, kept=kept, dropped_ids=dropped_ids, merges=merges)
