"""
A5 — Pass 2: Global Merge (candidate-pairs design)

INPUT:  list[KnowledgeAtom] (everything B1 has stored for a source_id)
        + list[EntityMention] (A4.5's persisted, consolidated entity_map)
        + vector_pairs: list[(atom_id, atom_id, score)] (A4.8's ANN output)
OUTPUT: common.schemas.MergeResult
        -> cross_links become kg_edges (B2); CONTRADICTS pairs set
           knowledge_atoms.contradicts_flag (stage C / B2)

DESIGN CHANGE vs previous version (see thiet_ke_cai_tien_kb_pipeline_final.md
§4-5 and mdu1.md): instead of blindly batching ALL atoms sequentially
150-at-a-time (which meant two related atoms sitting in different batches,
purely because of where they happen to appear in the document, were NEVER
seen together by the LLM), this stage now only sends the LLM PAIRS of atoms
that some cheap, non-LLM signal already flagged as plausibly related:
  - "entity" reason: the pair shares a rare entity (section_count below
    a4_5_entity_common_cutoff — see A4.5) that's a genuine cross-section
    "bridge", not tracking-noise from an entity so common it appears
    everywhere.
  - "vector" reason: A4.8's ANN search found them within cosine-similarity
    range, cross-section, cross-position in the document.

The LLM's ONE remaining job here (see mdu1.md §3) is exactly the thing a pure
vector-similarity signal structurally cannot do: tell CONTRADICTS apart from
agreement/elaboration on the same topic (two sentences about the same
entity, opposite in polarity, still embed as "similar" and share the same
entities — only semantic reading distinguishes them).
"""
from __future__ import annotations
import time
import json
import itertools
import logging
from typing import NamedTuple, Optional

from rapidfuzz import fuzz

from common.config import settings
from common.llm_client import LLMClient, extract_and_parse_json
from common.schemas import KnowledgeAtom, MergeResult, CrossLink, EntityMention

logger = logging.getLogger(__name__)

VALID_RELATIONS = {"DEFINES", "EXTENDS", "CONTRADICTS", "RELATED_TO"}

# How many pairs go into a single merge LLM call. Pairs (not whole atoms) are
# the unit here, so this can be considerably larger than the old
# MAX_ATOMS_PER_MERGE_CALL=150 for the same prompt-size budget — each pair
# payload item is much smaller than a full atom list entry duplicated N ways.
MAX_PAIRS_PER_CALL = 80


class CandidatePair(NamedTuple):
    a_id: str
    b_id: str
    reason: str              # 'entity' | 'vector'
    score: float = 0.0        # vector cosine score — only meaningful when reason == 'vector'
    section_count: int = 0    # the bridging entity's section_count — only meaningful when reason == 'entity'


def build_candidate_pairs(atoms: list[KnowledgeAtom], entity_map: list[EntityMention],
                           vector_pairs: list[tuple[str, str, float]]) -> list[CandidatePair]:
    """Builds the deduplicated set of (atom_a, atom_b) pairs A5's LLM call
    should look at — from two independent, cheap (non-LLM) sources.

    NOTE: this reads `entity.entity_id in {e["entity_id"] for e in a.entities}`
    on each atom's `.entities` — those dicts only HAVE an "entity_id" key
    after A4.5 (stages/a4_5_entity_consolidation.py::resolve_atom_entities)
    has run. Calling this before A4.5 silently yields zero entity-based
    pairs (KeyError-safe via .get), not a crash — see the .get() below.
    """
    pairs: dict[tuple[str, str], CandidatePair] = {}

    # 1. Pairs sharing a RARE entity (already IDF-filtered by A4.5's
    #    section_count; a4_5_entity_common_cutoff re-checked here too in case
    #    entity_map was computed with a different threshold than is
    #    currently configured).
    atoms_by_entity: dict[str, list[KnowledgeAtom]] = {}
    for atom in atoms:
        for ent in (atom.entities or []):
            eid = ent.get("entity_id")
            if eid:
                atoms_by_entity.setdefault(eid, []).append(atom)

    entity_by_id = {e.entity_id: e for e in entity_map}
    for entity_id, entity_atoms in atoms_by_entity.items():
        entity = entity_by_id.get(entity_id)
        section_count = entity.section_count if entity else len({a.section_id for a in entity_atoms})
        if section_count > settings.a4_5_entity_common_cutoff:
            continue
        for a, b in itertools.combinations(entity_atoms, 2):
            if a.section_id == b.section_id:
                continue
            key = tuple(sorted([a.id, b.id]))
            if key not in pairs:
                pairs[key] = CandidatePair(a_id=key[0], b_id=key[1], reason="entity",
                                            section_count=section_count)

    # 2. Pairs from A4.8's vector pre-filter — always added/overwrites with
    #    the (usually more informative, score-bearing) vector reason so the
    #    cost-cap sort below prioritizes correctly even if a pair matched on
    #    both signals.
    for a_id, b_id, score in vector_pairs:
        key = tuple(sorted([a_id, b_id]))
        pairs[key] = CandidatePair(a_id=key[0], b_id=key[1], reason="vector", score=score)

    return list(pairs.values())


def cap_candidate_pairs(candidate_pairs: list[CandidatePair]) -> list[CandidatePair]:
    """Design-doc §5.2 cost cap — without this, a document with a very
    "hub-like" common entity structure (even after the common_cutoff filter)
    or a low vector threshold could blow up candidate_pairs count and thus
    A5's LLM cost unboundedly. Priority: vector pairs by score desc, then
    entity pairs by rarity (lower section_count = more informative bridge).
    """
    if len(candidate_pairs) <= settings.a5_max_candidate_pairs_per_source:
        return candidate_pairs
    ranked = sorted(
        candidate_pairs,
        key=lambda p: (p.reason != "vector", -p.score if p.reason == "vector" else p.section_count),
    )
    kept = ranked[:settings.a5_max_candidate_pairs_per_source]
    logger.warning(
        "candidate_pairs vượt trần (%d > %d), cắt còn %d, ưu tiên theo điểm/rarity",
        len(candidate_pairs), settings.a5_max_candidate_pairs_per_source, len(kept),
    )
    return kept


MERGE_SYSTEM_PROMPT_PAIRS = """Bạn là hệ thống phân tích quan hệ tri thức. Bạn sẽ nhận một danh sách các CẶP đoạn văn bản
(atom), mỗi cặp đã được hệ thống nghi ngờ có liên quan (do chia sẻ cùng 1 thực thể, hoặc có độ tương đồng vector cao).
Nhiệm vụ: với MỖI cặp, xác nhận xem chúng có thực sự tồn tại quan hệ tri thức hay không, và nếu có thì thuộc loại nào.

Với mỗi cặp (atom_a, atom_b), trả về MỘT trong hai loại kết quả:
- Nếu có quan hệ thật: {"from_id": <id của atom nguồn>, "to_id": <id của atom đích>,
    "relation": "DEFINES" | "EXTENDS" | "CONTRADICTS" | "RELATED_TO",
    "evidence_raw": <cụm từ NGUYÊN VĂN, phải xuất hiện y hệt trong raw của from_id HOẶC to_id, làm bằng chứng>}
- Nếu không có quan hệ thật (chỉ tình cờ giống chủ đề, không có giá trị tri thức thật): bỏ qua cặp đó, không trả gì.

Định nghĩa các loại quan hệ:
- DEFINES: atom này định nghĩa/giải thích khái niệm được nhắc tới ở atom kia.
- EXTENDS: atom này bổ sung chi tiết/mở rộng cho thông tin ở atom kia (không định nghĩa, không mâu thuẫn).
- CONTRADICTS: hai atom đưa ra thông tin/yêu cầu trái ngược nhau về cùng 1 đối tượng.
- RELATED_TO: liên quan rõ ràng nhưng không thuộc 3 loại trên.

QUY TẮC BẮT BUỘC:
1. from_id và to_id CHỈ được là id đã xuất hiện trong danh sách cặp gửi lên — không được tự tạo id mới.
2. evidence_raw PHẢI là chuỗi con nguyên văn (không diễn giải, không dịch, không tóm tắt) của raw thuộc from_id hoặc to_id.
3. Nếu không chắc chắn có quan hệ thật, KHÔNG trả — thà bỏ sót còn hơn báo sai.
4. Chỉ trả JSON, không thêm lời dẫn, không thêm markdown code fence.

Định dạng output: {"cross_links": [ {...}, {...} ]}
"""


def _verify_evidence(evidence_raw: str, from_atom: KnowledgeAtom, to_atom: KnowledgeAtom) -> bool:
    """Same 2-tier verification philosophy as A4's verify_element(): exact
    substring first, fuzzy match as a fallback for minor LLM re-typing —
    never trust evidence_raw blindly (that's how hallucinated edges sneak
    into the knowledge graph)."""
    if not evidence_raw:
        return False
    for atom in (from_atom, to_atom):
        if evidence_raw in atom.raw:
            return True
        if fuzz.partial_ratio(evidence_raw, atom.raw) >= settings.fuzzy_match_threshold:
            return True
    return False


def _safe_cross_link(item: dict, atoms_by_id: dict[str, KnowledgeAtom]) -> Optional[CrossLink]:
    if not isinstance(item, dict):
        return None

    from_id = item.get("from_id") or item.get("source_id") or item.get("from")
    to_id = item.get("to_id") or item.get("target_id") or item.get("to")
    evidence_raw = (item.get("evidence_raw") or item.get("evidence") or "").strip()
    relation = str(item.get("relation", "")).strip().upper()

    if not from_id or not to_id or from_id == to_id:
        return None
    from_atom = atoms_by_id.get(from_id)
    to_atom = atoms_by_id.get(to_id)
    if from_atom is None or to_atom is None:
        return None  # references an id we never sent — reject, don't guess

    if relation not in VALID_RELATIONS:
        relation = "RELATED_TO"  # evidence is still verified below; degrade the label rather than drop a real link

    if not _verify_evidence(evidence_raw, from_atom, to_atom):
        return None  # design-doc rule: no verifiable evidence -> no edge

    try:
        return CrossLink(from_id=from_id, to_id=to_id, relation=relation, evidence_raw=evidence_raw)
    except Exception:
        return None


def _build_pairs_payload(batch: list[CandidatePair], atoms_by_id: dict[str, KnowledgeAtom]) -> list[dict]:
    return [
        {"pair_id": i,
         "atom_a": {"id": p.a_id, "raw": atoms_by_id[p.a_id].raw, "label": atoms_by_id[p.a_id].label.value},
         "atom_b": {"id": p.b_id, "raw": atoms_by_id[p.b_id].raw, "label": atoms_by_id[p.b_id].label.value},
         "reason": p.reason}
        for i, p in enumerate(batch)
        if p.a_id in atoms_by_id and p.b_id in atoms_by_id
    ]


def _merge_one_batch_pairs(batch: list[CandidatePair], atoms_by_id: dict[str, KnowledgeAtom],
                            llm: LLMClient) -> list[CrossLink]:
    if settings.a5_llm_rate_limit_seconds > 0:
        time.sleep(settings.a5_llm_rate_limit_seconds)
    payload = _build_pairs_payload(batch, atoms_by_id)
    if not payload:
        return []
    raw = llm.generate(json.dumps(payload, ensure_ascii=False),
                        system=MERGE_SYSTEM_PROMPT_PAIRS, json_mode=True, tier="strong")
    try:
        data = extract_and_parse_json(raw)
        if not isinstance(data, dict):
            data = {}
    except Exception:
        data = {}

    links = []
    for link in data.get("cross_links", []) or []:
        verified = _safe_cross_link(link, atoms_by_id)
        if verified:
            links.append(verified)
    return links


def global_merge(atoms: list[KnowledgeAtom], entity_map: list[EntityMention],
                  candidate_pairs: list[CandidatePair], func_get_llm: Callable[[], Any],
                  source_id: Optional[str] = None) -> MergeResult:
    """Entry point for stage A5. Never raises on malformed LLM output —
    worst case it returns a MergeResult with fewer links than the LLM
    attempted, not a crashed batch.

    `candidate_pairs` should already be the FULL set from
    a5_global_merge.build_candidate_pairs(...) — this function only applies
    the cost cap and batches, it doesn't build pairs itself, so callers
    driving an incremental update can pass in a much smaller candidate_pairs
    list (new/changed atoms only) without this function needing to know the
    difference.
    """
    source_id = source_id or (atoms[0].source_id if atoms else "")
    if not atoms or not candidate_pairs:
        return MergeResult(source_id=source_id, resolved_entities=entity_map)

    atoms_by_id = {a.id: a for a in atoms}
    capped_pairs = cap_candidate_pairs(candidate_pairs)

    all_cross_links: list[CrossLink] = []
    seen_link_keys: set[tuple[str, str, str]] = set()

    for start in range(0, len(capped_pairs), MAX_PAIRS_PER_CALL):
        llm = func_get_llm()
        batch = capped_pairs[start:start + MAX_PAIRS_PER_CALL]
        batch_links = _merge_one_batch_pairs(batch, atoms_by_id, llm)
        for link in batch_links:
            key = (link.from_id, link.to_id, link.relation)
            if key not in seen_link_keys:
                seen_link_keys.add(key)
                all_cross_links.append(link)

    return MergeResult(
        source_id=source_id,
        cross_links=all_cross_links,
        resolved_entities=entity_map,
        # Community summaries are now produced by the dedicated B2.5 stage
        # (Louvain partition + lazy LLM summary over the persisted graph),
        # not here — see stages/b2_5_community_detection.py. Kept as [] for
        # schema backward-compat.
        community_summaries=[],
    )
