"""
A3 — Global Index Generation

INPUT:  UnifiedDoc (output of A2)
OUTPUT: common.schemas.GlobalIndex — consumed as context by A4 and A5.

FIX LOG (vs previous version):
  - `detect_cross_references` had a hard-coded `time.sleep(30)` before every
    single LLM call, paid unconditionally regardless of whether the
    provider was actually rate-limiting. Replaced with `_call_llm_with_backoff`,
    which only backs off (with exponential delay) when the response actually
    looks rate-limited, and retries a bounded number of times instead of
    guessing a fixed wait on every call.
  - `verify_fits_context` estimated tokens as `len(text) // 4`, which is
    inaccurate for Vietnamese (multi-byte diacritics, different
    tokenization) and can silently over/under-estimate whether the index
    fits the model's context window. Now uses `tiktoken` when available,
    falling back to the old heuristic only if it isn't installed.
  - `normalize_entity` / `ALIAS_MAP` was a 7-entry static dict — it can't
    catch spelling/casing variants it wasn't told about ("Kubernetes" vs
    "K8s Cluster" vs "kubernetes"). `resolve_entities_by_embedding` now runs
    after the alias pass and merges any remaining near-duplicate entities by
    embedding cosine similarity (using the same local sentence-transformers
    embedder B1/B2/D already depend on — no new dependency).
"""
from __future__ import annotations

import json
import re
import time
from typing import Optional
from common.config import settings
from common.llm_client import LLMClient, extract_and_parse_json
from common.schemas import UnifiedDoc, DocElement, ElementType, GlobalIndex, OutlineNode, \
    EntityMention, CrossReference

ALIAS_MAP = {
    "js": "JavaScript", "ts": "TypeScript", "k8s": "Kubernetes", "py": "Python",
    "db": "Database", "api": "API", "os": "Operating System",
}


_RATE_LIMIT_MARKERS = ("rate limit", "rate-limit", "429", "too many requests", "quota exceeded")


def _looks_rate_limited(raw: str) -> bool:
    lowered = (raw or "").lower()
    return any(marker in lowered for marker in _RATE_LIMIT_MARKERS)


def _call_llm_with_backoff(func_get_llm: Callable[[], Any], prompt: str, system: str, tier: str = "light") -> str:
    """Replaces the previous unconditional `time.sleep(30)` before this
    stage's one LLM call. Only pays a delay when a call actually looks
    rate-limited (rather than every single time regardless of provider),
    and retries with exponential backoff up to `a3_llm_max_retries` times."""
    max_retries = settings.a3_llm_max_retries
    base_delay = settings.a3_llm_backoff_base_seconds
    raw = ""
    for attempt in range(max_retries + 1):
        llm = func_get_llm()
        raw = llm.generate(prompt, system=system, json_mode=True, tier=tier)
        if raw and not _looks_rate_limited(raw):
            return raw
        if attempt < max_retries:
            time.sleep(base_delay * (2 ** attempt))
    return raw


_tiktoken_encoder = None
_tiktoken_unavailable = False


def _count_tokens(text: str) -> int:
    """Real tokenization via tiktoken when available (cached encoder so we
    only pay the load cost once per process); falls back to the old
    chars/4 heuristic — which is especially inaccurate for Vietnamese —
    only if tiktoken isn't installed."""
    global _tiktoken_encoder, _tiktoken_unavailable
    if not _tiktoken_unavailable:
        try:
            if _tiktoken_encoder is None:
                import tiktoken
                _tiktoken_encoder = tiktoken.get_encoding(settings.a3_token_count_model)
            return len(_tiktoken_encoder.encode(text))
        except Exception:
            _tiktoken_unavailable = True
    return len(text) // 4


# Mã giả #6
def build_structural_outline(elements: list[DocElement]) -> list[OutlineNode]:
    outline = []
    for i, e in enumerate(elements):
        if e.type == ElementType.HEADING:
            first_sentence = None
            for nxt in elements[i + 1:]:
                if nxt.type == ElementType.PARAGRAPH:
                    first_sentence = re.split(r"(?<=[.!?])\s", nxt.content_display)[0]
                    break
                if nxt.type == ElementType.HEADING:
                    break
            outline.append(OutlineNode(
                level=e.metadata.heading_level or 1, text=e.content_display,
                page=e.metadata.page, section_id=e.section_id or "unknown",
                first_sentence=first_sentence,
            ))
    return outline


# Mã giả #7
def normalize_entity(raw_mention: str) -> str:
    key = raw_mention.strip()
    return ALIAS_MAP.get(key.lower(), key)


def extract_entities_gliner(elements: list[DocElement]) -> list[EntityMention]:
    """A3.2 — zero-shot NER.

    Backend selection (`settings.a3_ner_backend`, default "auto"):
      - "gliner": GLiNER only (downloads its weights from the HF Hub on
        first use — subject to HF rate limiting).
      - "spacy": spaCy only. spaCy's pretrained pipelines (e.g.
        `en_core_web_sm`) install as plain pip wheels from GitHub releases,
        NOT from the Hugging Face Hub, so this keeps working even when HF
        is rate-limiting downloads. NER quality is lower than GLiNER
        (fixed entity types, not zero-shot) but far better than the regex
        fallback.
      - "regex": skip both models, use the light regex heuristic directly
        — zero downloads, zero network, works anywhere.
      - "auto" (default): try GLiNER, then spaCy, then regex.
    """
    entity_types = ["technology", "framework", "protocol", "standard", "tool", "language"]
    mentions_by_name: dict[str, EntityMention] = {}
    backend = settings.a3_ner_backend

    def _add(name: str, mention_text: str, section_id: Optional[str]) -> None:
        m = mentions_by_name.setdefault(
            name, EntityMention(entity_id=f"ent_{name.lower()}", canonical_name=name))
        m.mentions.append(mention_text)
        if section_id and section_id not in m.section_ids:
            m.section_ids.append(section_id)

    def _try_gliner() -> bool:
        try:
            from gliner import GLiNER
            model = GLiNER.from_pretrained("urchade/gliner_small-v2.1")
        except Exception:
            return False
        for el in elements:
            for ent in model.predict_entities(el.content_display, entity_types):
                _add(normalize_entity(ent["text"]), ent["text"], el.section_id)
        return True

    def _try_spacy() -> bool:
        try:
            import spacy
            try:
                nlp = spacy.load("en_core_web_sm")
            except OSError:
                return False  # model not installed; don't silently download mid-pipeline
        except Exception:
            return False
        # spaCy's default NER labels aren't IT-specific like GLiNER's zero-shot
        # types — ORG/PRODUCT/LANGUAGE are the closest stand-ins for
        # technology/framework/tool mentions.
        relevant_labels = {"ORG", "PRODUCT", "LANGUAGE", "WORK_OF_ART"}
        for el in elements:
            for ent in nlp(el.content_display).ents:
                if ent.label_ in relevant_labels:
                    _add(normalize_entity(ent.text), ent.text, el.section_id)
        return True

    def _regex_fallback() -> None:
        pattern = re.compile(r"\b([A-Z][a-zA-Z0-9+.#]{2,}|[A-Z]{2,5})\b")
        for el in elements:
            for match in pattern.findall(el.content_display):
                _add(normalize_entity(match), match, el.section_id)

    if backend == "gliner":
        if not _try_gliner():
            _regex_fallback()
    elif backend == "spacy":
        if not _try_spacy():
            _regex_fallback()
    elif backend == "regex":
        _regex_fallback()
    else:  # "auto"
        if not _try_gliner() and not _try_spacy():
            _regex_fallback()

    return list(mentions_by_name.values())


def resolve_entities_by_embedding(mentions: list[EntityMention]) -> list[EntityMention]:
    """Second entity-resolution pass, run after `extract_entities_gliner` +
    the static `ALIAS_MAP`. Merges any remaining entities whose
    canonical_name embeddings are highly similar (cosine) — catches variant
    spellings/casing the 7-entry static dict can't cover ("Kubernetes" /
    "K8s Cluster" / "kubernetes"). No-op (returns input unchanged) if
    there's nothing to merge, resolution is disabled, or the embedder isn't
    usable for any reason — this must never crash A3."""
    if not settings.a3_entity_resolution_enabled or len(mentions) < 2:
        return mentions
    try:
        import numpy as np
        from common.llm_client import LocalEmbedder
        names = [m.canonical_name for m in mentions]
        vecs = np.array(LocalEmbedder.encode(names), dtype=float)
        norms = np.linalg.norm(vecs, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        unit = vecs / norms
        sims = unit @ unit.T
    except Exception:
        return mentions

    n = len(mentions)
    threshold = settings.a3_entity_embed_similarity_threshold
    parent = list(range(n))

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for i in range(n):
        for j in range(i + 1, n):
            if sims[i, j] >= threshold:
                union(i, j)

    groups: dict[int, list[int]] = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(i)

    merged: list[EntityMention] = []
    for idxs in groups.values():
        if len(idxs) == 1:
            merged.append(mentions[idxs[0]])
            continue
        members = [mentions[i] for i in idxs]
        primary = max(members, key=lambda m: len(m.canonical_name))  # keep fullest display name
        all_mentions: list[str] = []
        all_sections: list[str] = []
        for m in members:
            for mm in m.mentions:
                if mm not in all_mentions:
                    all_mentions.append(mm)
            for s in m.section_ids:
                if s not in all_sections:
                    all_sections.append(s)
        merged.append(EntityMention(
            entity_id=primary.entity_id, canonical_name=primary.canonical_name,
            mentions=all_mentions, section_ids=all_sections,
        ))
    return merged


def detect_cross_references(func_get_llm: Callable[[], Any], outline: list[OutlineNode],
                             entity_map: list[EntityMention]) -> list[CrossReference]:
    """A3.4 — needs semantic understanding, so this is the one LLM call in A3."""
    if not outline:
        return []
    prompt = (
        "Given this document heading tree and entity map (JSON), list cross-references "
        "between sections (e.g. 'section X refers back to section Y').\n"
        "Return ONLY a JSON array of objects: "
        '{"from_section_id":..., "to_section_id":..., "relation_hint":...}\n\n'
        f"heading_tree: {json.dumps([o.model_dump() for o in outline[:50]])}\n"
        f"entity_map: {json.dumps([e.model_dump() for e in entity_map[:50]])}\n"
    )
    raw = _call_llm_with_backoff(
        func_get_llm, prompt, system="You are a precise document structure analyst.", tier="light")
    try:
        data = extract_and_parse_json(raw)
        items = data if isinstance(data, list) else data.get("cross_references", [])
        return [CrossReference(**item) for item in items]
    except Exception:
        return []


# Mã giả #8
def verify_fits_context(global_index: GlobalIndex, model_context_window: int = 128_000) -> bool:
    text = global_index.model_dump_json()
    approx_tokens = _count_tokens(text)
    global_index.size_tokens = approx_tokens
    global_index.fits_context = approx_tokens < model_context_window * 0.30
    return global_index.fits_context


def build_global_index(doc: UnifiedDoc, func_get_llm: Callable[[], Any]) -> GlobalIndex:
    """Entry point for stage A3.

    DESIGN-DOC DECISION: GLiNER/spaCy/regex zero-shot NER (extract_entities_gliner
    below) is no longer called here. GLiNER's fixed 6-type tech-only entity_types
    gave meaningless results on real, multi-domain documents (confirmed via
    experimentation — see mdu1.md §2 / thiet_ke_cai_tien_kb_pipeline_final.md §2).
    Entity extraction now happens inside A4 (the LLM already reads the section in
    full domain context for element extraction, so it extracts entities in the
    same call — see a4_constraint_extraction.EXTRACTION_SYSTEM_PROMPT), and the
    new A4.5 stage (stages/a4_5_entity_consolidation.py) consolidates those into
    the persisted, cross-document-safe entity_map that A5/B2 actually use.

    GlobalIndex.entity_map is therefore always empty here; cross-reference
    detection runs on the heading tree alone. `extract_entities_gliner` /
    `resolve_entities_by_embedding` are kept below (unused) only in case anyone
    wants a fallback NER pass for a document format A4 doesn't extract entities
    well from — nothing currently calls them.
    """
    outline = build_structural_outline(doc.elements)
    entity_map: list[EntityMention] = []
    cross_refs = detect_cross_references(func_get_llm, outline, entity_map)

    gi = GlobalIndex(source_id=doc.source_id, heading_tree=outline,
                      entity_map=entity_map, cross_references=cross_refs)
    verify_fits_context(gi)
    return gi
