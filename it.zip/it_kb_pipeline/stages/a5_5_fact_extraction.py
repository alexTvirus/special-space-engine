"""
A5.5 — Fact extraction: entity-entity relations with a FREE-FORM,
domain-specific relation_type (CAUSES, TRIGGERS, INCREASES_LOAD,
DEPENDS_ON, ...) instead of only the 4 generic DEFINES/EXTENDS/CONTRADICTS/
RELATED_TO types that b2_wiki_graph_chunking.build_kg's entity-entity
*projection* produces (that projection just relabels whatever atom-atom
relation A5 already found — it can never say "Redis CAUSES Session Loss").

Giai đoạn 0 of phan_tich_va_giai_phap_cai_tien_graph.md §2.1.4 / §3.

INPUT:  list[KnowledgeAtom] (everything B1 has stored for a source_id, with
        .entities already resolved by A4.5)
        + MergeResult (A5's cross_links — used as one candidate-pair source)
OUTPUT: (list[Fact], list[FactEvidence])
        -> merged into B2Output.facts/fact_evidence by create_kb_from_file.py
           BEFORE stage C persists (kg_facts/fact_evidence), so both this
           stage's domain-specific facts and B2's projected generic-relation
           facts (see b2_wiki_graph_chunking.build_kg) end up in the same
           two tables.

Runs AFTER A4.5 (needs KnowledgeAtom.entities[].entity_id already resolved)
and can run right after A5 (reuses its cross_links as one candidate-pair
source, alongside same-atom entity co-occurrence). Does NOT depend on B2.

Cost-cap philosophy mirrors A5 exactly (see stages/a5_global_merge.py):
candidate pairs are capped BEFORE going to the LLM
(settings.a5_5_max_entity_pairs_per_source), and every returned relation
must carry a verbatim evidence_raw substring or it's dropped — no
LLM-invented edges make it into kg_facts.
"""
from __future__ import annotations

import itertools
import json
import logging
import re
import time
from typing import NamedTuple, Optional

from rapidfuzz import fuzz

from common.config import settings
from common.llm_client import LLMClient, extract_and_parse_json
from common.schemas import KnowledgeAtom, MergeResult, Fact, FactEvidence
from typing import Callable, Any

logger = logging.getLogger(__name__)

MAX_PAIRS_PER_CALL = 40
_SLUG_RE = re.compile(r"[^A-Z0-9]+")


def _canonical_relation_type(text: str) -> str:
    """Canonicalizes a free-form relation type the same way A4.5 canonicalizes
    entity names (lexical normalization) — e.g. "increases load",
    "INCREASES_LOAD", "làm tăng tải" style variants collapse to one slug so
    kg_facts doesn't accumulate near-duplicate relation_type strings. This is
    a cheap lexical fold only (upper-snake-case); true semantic merging of
    synonymous relation types (e.g. "TĂNG_TẢI" vs "INCREASES_LOAD") is a
    documented follow-up — see the accompanying markdown report, §"Chưa làm".
    """
    text = (text or "").strip().upper()
    text = _SLUG_RE.sub("_", text).strip("_")
    return text or "RELATED_TO"


class EntityPair(NamedTuple):
    a_id: str
    b_id: str
    atom_ids: tuple[str, ...]   # atoms where both entities co-occur (evidence candidates)


def build_entity_pairs(atoms: list[KnowledgeAtom], merge_result: MergeResult) -> list[EntityPair]:
    """Two cheap (non-LLM) candidate-pair sources, same spirit as
    a5_global_merge.build_candidate_pairs:
      1. same-atom co-occurrence — both entities already mentioned in one atom
      2. cross-linked atoms — A5 already confirmed cl.from_id/cl.to_id are
         related (DEFINES/EXTENDS/CONTRADICTS/RELATED_TO); the entities on
         those two atoms are plausible candidates for a MORE SPECIFIC
         domain relation than the generic one A5 found.
    """
    atom_by_id = {a.id: a for a in atoms}
    pairs: dict[tuple[str, str], set[str]] = {}

    for a in atoms:
        eids = sorted({e.get("entity_id") for e in (a.entities or []) if e.get("entity_id")})
        if len(eids) > 5:
            continue  # same safety valve as A5/B2 — avoid combinatorial blow-up on a noisy element
        for ea, eb in itertools.combinations(eids, 2):
            pairs.setdefault((ea, eb), set()).add(a.id)

    for cl in merge_result.cross_links:
        a1, a2 = atom_by_id.get(cl.from_id), atom_by_id.get(cl.to_id)
        if a1 is None or a2 is None:
            continue
        eids_a = {e.get("entity_id") for e in (a1.entities or []) if e.get("entity_id")}
        eids_b = {e.get("entity_id") for e in (a2.entities or []) if e.get("entity_id")}
        if len(eids_a) > 5 or len(eids_b) > 5:
            continue
        for ea in eids_a:
            for eb in eids_b:
                if ea == eb:
                    continue
                key = tuple(sorted([ea, eb]))
                pairs.setdefault(key, set()).update([cl.from_id, cl.to_id])

    return [EntityPair(a_id=k[0], b_id=k[1], atom_ids=tuple(sorted(v))) for k, v in pairs.items()]


def cap_entity_pairs(pairs: list[EntityPair]) -> list[EntityPair]:
    """Design-doc §5.2-style cost cap, applied to ENTITY pairs instead of
    ATOM pairs — reuses the exact same rationale as
    a5_global_merge.cap_candidate_pairs (a hub-like document could otherwise
    blow up LLM cost unboundedly). Priority: pairs with more independent
    co-occurrence evidence first (more likely a genuine, well-attested
    relation, not incidental)."""
    if len(pairs) <= settings.a5_5_max_entity_pairs_per_source:
        return pairs
    ranked = sorted(pairs, key=lambda p: -len(p.atom_ids))
    kept = ranked[:settings.a5_5_max_entity_pairs_per_source]
    logger.warning(
        "entity_pairs (A5.5) vượt trần (%d > %d), cắt còn %d, ưu tiên theo số atom đồng xuất hiện",
        len(pairs), settings.a5_5_max_entity_pairs_per_source, len(kept),
    )
    return kept


FACT_SYSTEM_PROMPT = """Bạn là hệ thống trích xuất quan hệ tri thức.
Bạn sẽ nhận một danh sách các CẶP thực thể (entity), kèm theo các đoạn văn bản (atom) nơi 2 thực thể
đó cùng xuất hiện. Nhiệm vụ: với MỖI cặp, xác định xem có tồn tại một quan hệ nhân quả/vận hành cụ
thể giữa 2 thực thể hay không (ví dụ: CAUSES, TRIGGERS, INCREASES_LOAD, DEPENDS_ON, REQUIRES,
DEFINES, PART_OF, MITIGATES...) — KHÔNG giới hạn trong danh sách ví dụ này, hãy dùng loại quan hệ
NGẮN GỌN, dạng ĐỘNG TỪ/CỤM ĐỘNG TỪ VIẾT_HOA_CÓ_GẠCH_DƯỚI mô tả đúng nhất bản chất quan hệ.

Với mỗi cặp (entity_a, entity_b), trả về MỘT trong hai loại kết quả:
- Nếu có quan hệ thật: {"pair_id": <số>, "source_entity": "a"|"b", "relation_type": "<LOẠI_QUAN_HỆ>",
    "evidence_raw": <cụm từ NGUYÊN VĂN, phải xuất hiện y hệt trong MỘT trong các atom được liệt kê
    cho cặp này, làm bằng chứng>}
  ("source_entity": "a" nghĩa là quan hệ có hướng entity_a -> entity_b; "b" nghĩa là entity_b -> entity_a)
- Nếu không có quan hệ thật (chỉ tình cờ cùng xuất hiện, không có giá trị tri thức thật): bỏ qua, không trả gì.

QUY TẮC BẮT BUỘC:
1. evidence_raw PHẢI là chuỗi con nguyên văn (không diễn giải, không dịch, không tóm tắt) của một
   trong các atom liệt kê cho cặp đó.
2. Nếu không chắc chắn, KHÔNG trả — thà bỏ sót còn hơn báo sai.
3. Chỉ trả JSON, không thêm lời dẫn, không thêm markdown code fence.

Định dạng output: {"facts": [ {...}, {...} ]}
"""


def _verify_and_locate_evidence(evidence_raw: str, candidate_atoms: list[KnowledgeAtom]) -> Optional[str]:
    """Same 2-tier verification philosophy as A5's _verify_evidence, but also
    returns WHICH atom the evidence actually came from (needed for
    fact_evidence.atom_id) instead of just a yes/no."""
    if not evidence_raw:
        return None
    for atom in candidate_atoms:
        if evidence_raw in atom.raw:
            return atom.id
    for atom in candidate_atoms:
        if fuzz.partial_ratio(evidence_raw, atom.raw) >= settings.fuzzy_match_threshold:
            return atom.id
    return None


def _build_payload(batch: list[EntityPair], entity_label: dict[str, str],
                    atom_by_id: dict[str, KnowledgeAtom]) -> list[dict]:
    payload = []
    for i, p in enumerate(batch):
        atoms = [atom_by_id[aid] for aid in p.atom_ids if aid in atom_by_id]
        if not atoms:
            continue
        payload.append({
            "pair_id": i,
            "entity_a": {"id": p.a_id, "name": entity_label.get(p.a_id, p.a_id)},
            "entity_b": {"id": p.b_id, "name": entity_label.get(p.b_id, p.b_id)},
            "atoms": [{"id": a.id, "raw": a.raw} for a in atoms[:5]],  # cap payload size per pair
        })
    return payload


def _extract_one_batch(batch: list[EntityPair], entity_label: dict[str, str],
                        atom_by_id: dict[str, KnowledgeAtom], llm: LLMClient,
                        source_id: str, fact_agg: dict[str, dict]) -> None:
    """Mutates `fact_agg` in place: fact_id -> {"source_entity_id",
    "target_entity_id", "relation_type", "evidence": [(atom_id, evidence_raw), ...]}.
    Aggregating across ALL batches (instead of returning finished Fact
    objects per-batch with a hardcoded confidence) is what lets
    extract_facts() compute a real corroboration-based confidence at the end
    — see the module docstring's "Cần sửa" note and b2_wiki_graph_chunking's
    entity_entity_agg, whose min(weight/3, 1.0) formula this reuses instead
    of the previous fixed confidence=0.6."""
    if settings.a5_5_llm_rate_limit_seconds > 0:
        time.sleep(settings.a5_5_llm_rate_limit_seconds)
    payload = _build_payload(batch, entity_label, atom_by_id)
    if not payload:
        return
    raw = llm.generate(json.dumps(payload, ensure_ascii=False),
                        system=FACT_SYSTEM_PROMPT, json_mode=True, tier="strong")
    try:
        data = extract_and_parse_json(raw)
        if not isinstance(data, dict):
            data = {}
    except Exception:
        data = {}

    by_pair_id = {i: p for i, p in enumerate(batch)}
    for item in data.get("facts", []) or []:
        if not isinstance(item, dict):
            continue
        pair = by_pair_id.get(item.get("pair_id"))
        if pair is None:
            continue
        candidate_atoms = [atom_by_id[aid] for aid in pair.atom_ids if aid in atom_by_id]
        evidence_raw = str(item.get("evidence_raw") or "").strip()
        atom_id = _verify_and_locate_evidence(evidence_raw, candidate_atoms)
        if atom_id is None:
            continue  # no verifiable evidence -> no fact, same rule as A5's cross_links
        relation_type = _canonical_relation_type(str(item.get("relation_type") or ""))
        direction = str(item.get("source_entity", "a")).strip().lower()
        src, tgt = (pair.a_id, pair.b_id) if direction != "b" else (pair.b_id, pair.a_id)
        fact_id = f"fact55_{src}_{tgt}_{relation_type}"

        agg = fact_agg.setdefault(fact_id, {
            "source_entity_id": src, "target_entity_id": tgt,
            "relation_type": relation_type, "evidence": [],
        })
        # Corroboration signal: how many DISTINCT atoms actually contain
        # evidence_raw verbatim (same "count independent confirming atoms"
        # spirit as B2's entity_entity_agg["weight"], just counted directly
        # from co-occurring atoms instead of from confirming cross_links —
        # A5.5 doesn't have a cross_link-per-confirmation concept, so this is
        # the closest equivalent evidence unit available here).
        added_any = False
        for atom in candidate_atoms:
            if evidence_raw and evidence_raw in atom.raw:
                pair_ev = (atom.id, evidence_raw)
                if pair_ev not in agg["evidence"]:
                    agg["evidence"].append(pair_ev)
                    added_any = True
        if not added_any:
            # Fuzzy-matched fallback (see _verify_and_locate_evidence) — the
            # located atom_id doesn't necessarily contain evidence_raw as an
            # exact substring, but it's still the best evidence we have.
            pair_ev = (atom_id, evidence_raw)
            if pair_ev not in agg["evidence"]:
                agg["evidence"].append(pair_ev)


def extract_facts(atoms: list[KnowledgeAtom], merge_result: MergeResult,
                   entity_label: dict[str, str], func_get_llm: Callable[[], Any],
                   source_id: Optional[str] = None) -> tuple[list[Fact], list[FactEvidence]]:
    """Entry point for stage A5.5.

    `entity_label`: entity_id -> canonical_name, e.g.
    {e.entity_id: e.canonical_name for e in entity_map} — used to give the
    LLM readable names instead of opaque ids.
    """
    
    source_id = source_id or (atoms[0].source_id if atoms else "")
    if not atoms:
        return [], []
    atom_by_id = {a.id: a for a in atoms}
    pairs = cap_entity_pairs(build_entity_pairs(atoms, merge_result))
    if not pairs:
        return [], []

    fact_agg: dict[str, dict] = {}
    for start in range(0, len(pairs), MAX_PAIRS_PER_CALL):
        llm = func_get_llm()
        batch = pairs[start:start + MAX_PAIRS_PER_CALL]
        _extract_one_batch(batch, entity_label, atom_by_id, llm, source_id, fact_agg)

    all_facts: list[Fact] = []
    all_evidence: list[FactEvidence] = []
    for fact_id, agg in fact_agg.items():
        # Same formula as b2_wiki_graph_chunking.build_kg's entity_entity_agg
        # (min(weight/3.0, 1.0)) instead of the old fixed confidence=0.6 —
        # unifies how "confidence" is scaled between the two sources that
        # both write into kg_facts (see module docstring, mục 3 of the
        # accompanying markdown report).
        confidence = min(len(agg["evidence"]) / 3.0, 1.0) if agg["evidence"] else 0.0
        all_facts.append(Fact(id=fact_id, source_id=source_id,
                               source_entity_id=agg["source_entity_id"],
                               target_entity_id=agg["target_entity_id"],
                               relation_type=agg["relation_type"], confidence=confidence))
        for atom_id, evidence_raw in agg["evidence"]:
            all_evidence.append(FactEvidence(fact_id=fact_id, atom_id=atom_id,
                                              evidence_raw=evidence_raw, confidence=1.0))

    logger.info("A5.5: %d entity pairs -> %d facts, %d fact_evidence rows",
                len(pairs), len(all_facts), len(all_evidence))
    return all_facts, all_evidence
