"""
C — Storage Layer

INPUT:  B2Output (chunk_records, kg_nodes, kg_edges, wiki_pages) for one source_id
OUTPUT: none (side effect: rows persisted in Postgres + wiki committed to Git)

Also owns batch-level monitoring (mã giả #14), replacing Sentry + Flower.
This is the thinnest stage on purpose: it only calls functions already
defined in common/db.py and stages/b2_*.py, so that if you later want a
dedicated "storage service", you literally move common/db.py + this file.
"""
from __future__ import annotations

import requests

from common import db
from common.config import settings
from common.schemas import B2Output, BatchRun
from stages.b2_wiki_graph_chunking import commit_wiki_to_git


def persist_b2_output(output: B2Output) -> None:
    for rec in output.chunk_records:
        db.upsert_chunk_record(rec)
    for node in output.kg_nodes:
        db.upsert_kg_node(node)
    for edge in output.kg_edges:
        db.insert_kg_edge(edge)
    # Giai đoạn 0 — Fact layer. facts tham chiếu kg_nodes (FK) nên phải sau
    # vòng kg_nodes ở trên; fact_evidence tham chiếu kg_facts nên sau vòng facts.
    for fact in output.facts:
        db.insert_kg_fact(fact)
    for ev in output.fact_evidence:
        db.insert_fact_evidence(ev)
    commit_wiki_to_git(output.wiki_pages, output.source_id)


# Mã giả #14
def send_webhook(url: str, message: str) -> None:
    if not url:
        return
    try:
        requests.post(url, json={"text": message}, timeout=10)
    except Exception:
        pass  # monitoring must never break the pipeline


def finish_batch(batch_id: str) -> BatchRun:
    """Entry point for end-of-batch monitoring."""
    stats = db.finish_batch(batch_id)
    if stats.failed_sections > 0 or stats.manual_review_sections > 0:
        send_webhook(
            settings.monitoring_webhook_url,
            f"Batch {batch_id}: {stats.failed_sections} lỗi, "
            f"{stats.manual_review_sections} cần review thủ công",
        )
    return stats
