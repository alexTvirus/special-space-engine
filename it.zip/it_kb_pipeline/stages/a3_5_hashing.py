"""
A3.5 — Section-Level Hashing

INPUT:  UnifiedDoc (output of A2), source_id
OUTPUT: common.schemas.SectionHashReport
        -> `.sections_to_process` is what gets enqueued into A4 (see mã giả #9)

FIX LOG (vs previous version):
  - Content used to be hashed raw. Two runs of an unchanged section could
    hash differently purely from Unicode normalization-form drift (NFC vs
    NFD diacritics) or trailing/incidental whitespace picked up by a
    different parser run, which would wrongly mark the section "changed"
    and re-queue it into A4 for no real content reason. Content is now run
    through `common.text_norm.normalize_for_hashing` before hashing.
"""
from __future__ import annotations

import hashlib
from collections import defaultdict

from common import db
from common.schemas import UnifiedDoc, SectionHashReport
from common.text_norm import normalize_for_hashing


def group_by_section(elements) -> dict[str, list]:
    grouped = defaultdict(list)
    for e in elements:
        grouped[e.section_id or "unknown"].append(e)
    return grouped


def concat_raw_content(elements) -> str:
    return "\n".join(e.content_raw for e in elements)


def compute_section_hash_report(unified_doc: UnifiedDoc, source_id: str) -> SectionHashReport:
    """Entry point for stage A3.5 (mã giả #9)."""
    new_sections, changed_sections, unchanged_sections = [], [], []

    for section_id, elements in group_by_section(unified_doc.elements).items():
        content = normalize_for_hashing(concat_raw_content(elements))
        new_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
        old_hash = db.get_section_hash(source_id, section_id)

        # print(f"[HASH] Section: {section_id}, old_hash: {old_hash[:8] if old_hash else 'None'}, new_hash: {new_hash[:8]}, status: {'NEW' if old_hash is None else 'CHANGED' if old_hash != new_hash else 'UNCHANGED'}")

        if old_hash is None:
            new_sections.append(section_id)
            db.upsert_section_hash(source_id, section_id, new_hash)
        elif old_hash != new_hash:
            changed_sections.append(section_id)
            db.upsert_section_hash(source_id, section_id, new_hash)
        else:
            unchanged_sections.append(section_id)

    return SectionHashReport(
        source_id=source_id, new_sections=new_sections,
        changed_sections=changed_sections, unchanged_sections=unchanged_sections,
    )
