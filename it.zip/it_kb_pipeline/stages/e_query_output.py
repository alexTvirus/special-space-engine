"""
E — Query Output + Citation Chain

INPUT:  common.schemas.RetrievalResult (output of D)
OUTPUT: common.schemas.AnswerWithCitations — final response returned to the user.

Anti-hallucination design (see stages/d_retrieval.py for the D-side half):

  1. The model is forced into a structured JSON response that separates
     "answer" from "uncovered_topics" — this makes gap-disclosure a field
     the code can check/enforce, instead of a sentence buried in free text
     that the model may or may not actually honor.
  2. `uncovered_terms` computed in stage D is fed back into the prompt
     explicitly, telling the model which parts of the question it must NOT
     try to answer from background knowledge.
  3. After generation, every [#atom_id] citation is validated against the
     *actual* retrieved candidate set — IDs that don't exist in `retrieval`
     are dropped (they can only be fabricated, since the prompt never showed
     the model any ID that wasn't retrieved).
  4. Each remaining cited sentence is then checked for lexical grounding
     against the atom it cites, and — if enabled — cross-checked with a
     second, independent LLM call whose only job is "is this claim actually
     supported by this atom text?". Sentences that fail both are stripped
     from the final answer rather than shown to the user.
"""
from __future__ import annotations

import json
import logging
import re
import time
from typing import Optional
from common import db
from common.config import settings
from common.llm_client import LLMClient ,extract_and_parse_json
from common.schemas import RetrievalResult, AnswerWithCitations, Citation , Suggestion, RetrievalQuery

logger = logging.getLogger(__name__)

ANSWER_SYSTEM_PROMPT = """Bạn là trợ lý trả lời câu hỏi CHỈ dựa trên các "context atoms" được cung cấp.

QUY TẮC BẮT BUỘC — vi phạm bất kỳ điều nào dưới đây đều là lỗi nghiêm trọng:
1. TUYỆT ĐỐI KHÔNG dùng kiến thức nền/kiến thức chung của bạn để bổ sung định nghĩa, khái niệm hay số liệu không có trong context atoms — kể cả khi bạn tin điều đó đúng trong thực tế.
2. Mỗi câu khẳng định phải đi kèm citation dạng [#atom_id], và atom_id đó phải THỰC SỰ chứa nội dung hỗ trợ trực tiếp cho câu đó. Không được gắn citation cho một câu mà atom không thực sự nói tới — đây gọi là "citation giả" và bị cấm tuyệt đối.
3. Nếu người dùng hỏi về một khái niệm/thực thể mà KHÔNG atom nào đề cập, KHÔNG được suy diễn hay viết một câu nghe hợp lý để lấp đầy khoảng trống. Thay vào đó, liệt kê khái niệm đó vào "uncovered_topics".
4. Nếu danh sách "Thuật ngữ không tìm thấy trong bất kỳ atom nào" được cung cấp bên dưới, bạn PHẢI đưa toàn bộ các thuật ngữ đó (hoặc thuật ngữ tương ứng trong câu hỏi) vào "uncovered_topics", và KHÔNG được viết bất kỳ câu khẳng định nào về chúng trong "answer".
5. Chỉ trả lời phần nào của câu hỏi có căn cứ; phần còn lại nêu rõ là tài liệu không đề cập, không cố "kết nối" các mảnh thông tin rời rạc thành một câu chuyện liền mạch nếu context không thực sự nói vậy.
6. **QUAN TRỌNG - Cách sử dụng thông tin quan hệ (edges):**
   - Nếu phần "Mối quan hệ giữa các atom" được cung cấp, hãy dùng nó để hiểu cách các atom liên kết với nhau.
   - Ví dụ: nếu atom A có quan hệ `RELATED_TO` với atom B, bạn có thể kết hợp thông tin từ cả hai để tạo câu trả lời hoàn chỉnh. Nếu quan hệ là `DEFINES`, atom A định nghĩa khái niệm trong B; nếu là `EXTENDS`, A bổ sung cho B.
   - Khi kết hợp, hãy trích dẫn cả hai atom để minh bạch nguồn thông tin.
7. **BẮT BUỘC đọc HẾT toàn bộ context atoms trước khi trả lời, kể cả những đoạn ở cuối danh sách** — thứ tự liệt kê KHÔNG phản ánh mức độ quan trọng đối với câu hỏi này. Nếu bạn đã mô tả một hiện tượng/sự kiện trong câu trả lời (vd: "X gây ra lỗi Y") và có MỘT đoạn tri thức khác (dù không phải đoạn khớp trực tiếp với từ ngữ câu hỏi) giải thích rõ CƠ CHẾ hoặc NGUYÊN NHÂN của chính hiện tượng/sự kiện đó, bạn PHẢI trích dẫn và đưa đoạn đó vào câu trả lời — không được chỉ nêu hiện tượng mà bỏ qua đoạn giải thích cơ chế của nó khi đoạn đó có sẵn trong danh sách được cung cấp. Quy tắc này KHÔNG cho phép bạn suy diễn hay thêm nội dung ngoài atom — bạn chỉ được áp dụng nó khi atom đó thực sự, rõ ràng nói về đúng cơ chế/nguyên nhân đang được nhắc tới (vẫn phải tuân thủ quy tắc 2 ở trên: citation phải có căn cứ thật).

Trả lời CHỈ bằng một object JSON hợp lệ theo đúng schema sau, không thêm bất kỳ text, giải thích, hay markdown code fence nào khác:
{
  "answer": "câu trả lời tiếng Việt, mỗi khẳng định có căn cứ phải có [#atom_id] ngay sau nó; phần không có căn cứ thì viết rõ 'Tài liệu không đề cập đến ...'",
  "cited_atom_ids": ["id1", "id2"],
  "uncovered_topics": ["khái niệm trong câu hỏi mà context atoms không hề đề cập"]
}"""

ANSWER_SYSTEM_PROMPT_ADDITION = """
Một số đoạn tham khảo được gắn nhãn "graph_expansion" — nghĩa là hệ thống đưa vào vì nó có quan hệ
(ghi rõ loại quan hệ) với một đoạn khác đã khớp trực tiếp với câu hỏi, KHÔNG phải vì bản thân nó
giống câu hỏi. Hãy tự đánh giá: nếu đoạn đó thực sự cần thiết để trả lời đầy đủ, hãy dùng và trích dẫn
rõ nguồn; nếu không liên quan tới câu hỏi cụ thể này, hãy bỏ qua dù nó có mặt trong danh sách.

Một số đoạn khác được gắn nhãn "section_expansion" — nghĩa là đoạn này nằm CÙNG một mục/section với
một đoạn khác đã khớp trực tiếp với câu hỏi, nhưng bản thân nó KHÔNG được xác nhận là khớp trực tiếp
với câu hỏi hay với đoạn kia. Nó được đưa vào vì đoạn văn xung quanh đôi khi chứa chi tiết bổ trợ cần
thiết. Hãy tự đánh giá độc lập từng đoạn "section_expansion": chỉ dùng nếu nội dung của chính nó thực
sự hỗ trợ câu trả lời; đừng suy diễn rằng nó liên quan chỉ vì nằm gần đoạn đã khớp.
"""

VERIFY_SYSTEM_PROMPT = """Bạn là bộ kiểm tra tính xác thực (fact-checker). Nhiệm vụ DUY NHẤT của bạn:
với mỗi cặp (câu khẳng định, đoạn atom nguồn), xác định atom đó có THỰC SỰ hỗ trợ trực tiếp câu khẳng định hay không.
Không dùng kiến thức nền của bạn để đánh giá đúng/sai về mặt thực tế — chỉ đánh giá xem đoạn atom có nói ra điều đó hay không.
Trả lời CHỈ bằng JSON: {"verdicts": [{"index": 0, "supported": true/false}, ...]}, không thêm text nào khác."""


def _atom_lookup(retrieval: RetrievalResult) -> dict[str, str]:
    return {c.atom_id: f"{c.raw} {c.normalized or ''}".strip() for c in retrieval.candidates}


def expand_with_contradicting_opposites(candidates: list) -> list:
    """Design-doc §10: for every candidate flagged contradicts_flag, pull in
    the atom on the other end of its CONTRADICTS kg_edge (if not already in
    the pool) so the model sees BOTH sides and can surface the contradiction
    instead of silently picking whichever side retrieval happened to rank
    higher."""
    from common.schemas import RetrievedCandidate
    existing_ids = {c.atom_id for c in candidates}
    extra: list = []
    for c in candidates:
        if not c.contradicts_flag:
            continue
        opposite = db.get_contradicting_atom(c.atom_id)
        if not opposite or opposite["id"] in existing_ids:
            continue
        existing_ids.add(opposite["id"])
        extra.append(RetrievedCandidate(
            atom_id=opposite["id"], raw=opposite["raw"], normalized=opposite["normalized"],
            source="graph", rank=0, relevance_score=c.relevance_score,
            confidence=float(opposite["confidence"] or 0), contradicts_flag=True,
            location=f"{opposite['source_id']} — Chapter {opposite['chapter']}, Page {opposite['page_start']}",
            origin="graph_expansion", relation="CONTRADICTS", linked_from=c.atom_id,
        ))
    return candidates + extra


def _format_candidate_line(c) -> str:
    """Context-block line for one candidate, with provenance markers the
    ANSWER_SYSTEM_PROMPT_ADDITION prompt text refers to: a graph_expansion
    tag (with the relation that pulled it in) and a [MÂU THUẪN] tag for
    contradicts_flag candidates."""
    tags = []
    if c.origin == "graph_expansion":
        if c.relation:
            tags.append(f"graph_expansion via {c.relation}"
                         + (f" from #{c.linked_from}" if c.linked_from else ""))
        else:
            tags.append("graph_expansion (liên kết gián tiếp qua đồ thị tri thức, "
                         "không qua một cạnh quan hệ trực tiếp duy nhất)")
    elif c.origin == "section_expansion":
        anchor_note = f" (gần #{c.anchor_atom_id})" if c.anchor_atom_id else ""
        tags.append(f"section_expansion{anchor_note}")
    tag_str = f" ({'; '.join(tags)})" if tags else ""
    return f"[#{c.atom_id}]{tag_str} {c.normalized or c.raw}"

def _format_entity_paths_block(retrieval: RetrievalResult, atom_text_map: dict[str, str]) -> str:
    """Đề xuất #1 — hiển thị chuỗi entity-fact (Entity_A --CAUSES--> Entity_B
    --TRIGGERS--> Entity_C) mà entity_path_search tìm được, kèm evidence
    atom cho mỗi cạnh (nếu có trong candidates hiện tại — evidence atom
    luôn có mặt trong retrieval.candidates vì entity_path_search chính là
    nguồn tạo ra các candidate đó, xem stages/d_retrieval.py::retrieve()).
    Đặt TRƯỚC relations_block (atom-atom, generic) — xem
    ANSWER_SYSTEM_PROMPT_ADDITION cho cách model được hướng dẫn dùng 2 block
    này khác nhau."""
    if not retrieval.entity_paths:
        return ""
    lines = []
    for hop in retrieval.entity_paths:
        evidence_bits = []
        for aid in hop.evidence_atom_ids:
            text = atom_text_map.get(aid)
            if text:
                evidence_bits.append(f"[#{aid}] \"{text}\"")
            else:
                evidence_bits.append(f"[#{aid}]")
        evidence_str = f" (evidence: {'; '.join(evidence_bits)})" if evidence_bits else " (chưa có evidence — đối chiếu cẩn thận trước khi dùng)"
        lines.append(f"- {hop.source_label} --{hop.relation_type}--> {hop.target_label}{evidence_str}")
    return (
        "\n\nChuỗi quan hệ suy luận được tìm thấy (đối chiếu evidence trước khi dùng):\n"
        + "\n".join(lines)
    )


def build_answer_json(query_text: str, retrieval: RetrievalResult, llm: LLMClient) -> dict:
    context_block = "\n".join(_format_candidate_line(c) for c in retrieval.candidates)
    atom_text_map = {c.atom_id: c.normalized or c.raw for c in retrieval.candidates}

    entity_paths_block = _format_entity_paths_block(retrieval, atom_text_map)

    relations_block = ""
    # if retrieval.candidate_edges:
    #     relation_lines = []
    #     meaningful_edges = [e for e in retrieval.candidate_edges if e.get("relation") != "SIMILAR_TO"]
    #     meaningful_edges.sort(
    #             key=lambda e: (e.get("evidence_raw") is not None, abs(e.get("score") or 0.0)),
    #             reverse=True,
    #         )
    #     meaningful_edges = meaningful_edges[: settings.e_answer_max_relation_lines]            
    #     for e in meaningful_edges:
    #         if e["source_id"] not in atom_text_map or e["target_id"] not in atom_text_map:
    #             continue
    #         # Hiển thị evidence nếu có
            
    #         evidence = f" (evidence: {e['evidence_raw']})" if e.get('evidence_raw') else ""
    #         relation_lines.append(
    #             f"- [#{e['source_id']}] --{e['relation']}--> [#{e['target_id']}]{evidence}"
    #         )
    #     if relation_lines:
    #         relations_block = (
    #             "\n\nGợi ý quan hệ giữa các atom ở trên (trích xuất tự động, "
    #             "có thể không hoàn toàn chính xác — đối chiếu với nội dung atom "
    #             "trước khi dùng để suy luận):\n" + "\n".join(relation_lines)
    #         )

    prompt = f"Câu hỏi: {query_text}\n\nCác atom:\n{context_block}"

    if entity_paths_block:
        prompt += entity_paths_block

    if relations_block:
        prompt += relations_block

    time.sleep(5)
    if retrieval.uncovered_terms:
        prompt += (
            "\n\nThuật ngữ không tìm thấy trong bất kỳ atom nào ở trên (bắt buộc đưa vào "
            f"uncovered_topics, không được suy diễn về chúng): {', '.join(retrieval.uncovered_terms)}"
        )
    print(f"prom  {prompt}")
    # raw =""
    raw = llm.generate(prompt, system=ANSWER_SYSTEM_PROMPT + ANSWER_SYSTEM_PROMPT_ADDITION, json_mode=True, tier="strong")
    try:
        data = extract_and_parse_json(raw)
        data.setdefault("answer", "")
        data.setdefault("cited_atom_ids", [])
        data.setdefault("uncovered_topics", [])
        return data
    except Exception as e:
        logger.warning("Failed to parse structured answer JSON (%s); raw=%r", e, raw[:300])
        # Fail closed: don't hand the user unparseable/unverifiable text.
        return {
            "answer": "Hệ thống không tạo được câu trả lời có định dạng hợp lệ để xác minh. "
                      "Vui lòng thử lại.",
            "cited_atom_ids": [], "uncovered_topics": retrieval.uncovered_terms,
        }



def extract_cited_ids(answer_text: str) -> list[str]:
    return re.findall(r"\[#([\w\-]+)\]", answer_text)


_TOKEN_RE = re.compile(r"[\wÀ-ỹ]+")


def _tokens(text: str) -> set[str]:
    return {t.lower() for t in _TOKEN_RE.findall(text) if len(t) > 2}


_CITATION_TAG_RE = re.compile(r"^\[#[\w\-]+\]\s*")
_CITATION_ONLY_RE = re.compile(r"^(?:\[#[\w\-]+\]\s*)+$")


def _split_sentences(text: str) -> list[str]:
    """Simple sentence splitter — good enough for a grounding heuristic, not
    meant to be a full Vietnamese sentence segmenter. One important cleanup
    pass: models are inconsistent about whether [#atom_id] goes right before
    or right after the sentence-ending period, which can otherwise split a
    single grounded claim into "prose" + "orphan citation" pieces and cause
    the grounding check below to wrongly strip a perfectly-supported
    sentence just because its citation ended up in the next chunk."""
    raw = [p for p in re.split(r"(?<=[.!?])\s+", text.strip()) if p]
    merged: list[str] = []
    for part in raw:
        if merged and _CITATION_ONLY_RE.match(part):
            merged[-1] = f"{merged[-1]} {part}"
            continue
        tag_match = _CITATION_TAG_RE.match(part)
        if merged and tag_match:
            merged[-1] = f"{merged[-1]} {tag_match.group(0).strip()}"
            rest = part[tag_match.end():].strip()
            if rest:
                merged.append(rest)
            continue
        merged.append(part)
    return merged


def lexical_overlap(sentence: str, atom_text: str) -> float:
    a, b = _tokens(sentence), _tokens(atom_text)
    if not a or not b:
        return 0.0
    return len(a & b) / len(a)


def llm_verify_claims(pairs: list[tuple[str, str]], llm: LLMClient) -> list[bool]:
    """Independent second pass: ask the model (cheap tier) whether each
    (claim, atom_text) pair is actually entailed. Returns one bool per pair,
    defaulting to True (i.e. "don't strip") only if verification itself is
    unavailable/unparseable — a lexical-overlap floor still applies upstream
    as a safety net in that case."""
    if not pairs:
        return []
    items = "\n".join(f"{i}. Khẳng định: {c}\n   Atom nguồn: {a}" for i, (c, a) in enumerate(pairs))
    prompt = f"Kiểm tra từng cặp sau:\n{items}"
    time.sleep(6)
    raw = llm.generate(prompt, system=VERIFY_SYSTEM_PROMPT, json_mode=True, tier="light")
    try:
        # cleaned = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.MULTILINE).strip()
        # data = json.loads(cleaned)
        data = extract_and_parse_json(raw)
        verdicts = {v["index"]: bool(v["supported"]) for v in data.get("verdicts", [])}
        return [verdicts.get(i, True) for i in range(len(pairs))]
    except Exception as e:
        logger.warning("Grounding LLM-verify pass failed/unparseable (%s); relying on lexical overlap only", e)
        return [True] * len(pairs)


def verify_and_strip_unsupported(answer_text: str, valid_atom_ids: set[str],
                                  atom_lookup: dict[str, str], llm: LLMClient) -> tuple[str, list[str]]:
    """Post-hoc grounding pass. Returns (cleaned_answer, stripped_sentences)."""
    sentences = _split_sentences(answer_text)
    kept: list[str] = []
    stripped: list[str] = []
    verify_pairs: list[tuple[str, str]] = []
    verify_slots: list[int] = []  # index into `sentences` for each pending pair

    decisions: list[bool | None] = [None] * len(sentences)

    for i, sent in enumerate(sentences):
        cited = extract_cited_ids(sent)
        if not cited:
            # No citation at all on a claim-bearing sentence is itself a
            # violation of the system prompt's rule #2; treat as unsupported
            # unless it's clearly just a transition/summary sentence (short).
            decisions[i] = len(_tokens(sent)) < 6
            continue
        # Drop citations pointing at atom_ids that were never actually
        # retrieved — those can only be fabricated by the model.
        real_cited = [aid for aid in cited if aid in valid_atom_ids]
        if not real_cited:
            decisions[i] = False
            continue
        atom_text = " ".join(atom_lookup.get(aid, "") for aid in real_cited)
        overlap = lexical_overlap(sent, atom_text)
        if overlap < settings.e_grounding_min_overlap:
            decisions[i] = False
            continue
        if settings.e_grounding_llm_check_enabled:
            verify_pairs.append((sent, atom_text))
            verify_slots.append(i)
        else:
            decisions[i] = True

    if verify_pairs:
        verdicts = llm_verify_claims(verify_pairs, llm)
        for slot, ok in zip(verify_slots, verdicts):
            decisions[slot] = ok

    for sent, ok in zip(sentences, decisions):
        if ok:
            kept.append(sent)
        else:
            stripped.append(sent)

    cleaned = " ".join(kept).strip()
    return cleaned, stripped


def build_citation_chain(cited_atom_ids: list[str]) -> list[Citation]:
    chain = []
    for atom_id in cited_atom_ids:
        # Ưu tiên tìm trong knowledge_atoms
        atom = db.get_knowledge_atom(atom_id)
        if atom:
            chain.append(Citation(
                atom_id=atom_id,
                raw=atom["raw"],
                location=f"{atom['source_id']} — Chapter {atom['chapter']}, Page {atom['page_start']}",
            ))
        else:
            # Nếu không thấy, thử tìm trong chunk_records (parent)
            with db.get_conn() as conn:
                row = conn.execute(
                    "SELECT content, metadata FROM chunk_records WHERE id=%s AND type='parent'",
                    (atom_id,)
                ).fetchone()
                if row:
                    chain.append(Citation(
                        atom_id=atom_id,
                        raw=row["content"],
                        location=f"Parent chunk: {atom_id}",
                    ))
    return chain


def _retry_with_retrieval_gap(query_text: str, retrieval: RetrievalResult,
                               original_query: RetrievalQuery, llm: LLMClient) -> Optional[RetrievalResult]:
    """Đề xuất #14 — vòng lặp retrieve-reason-retrieve Ở TẦNG NGOÀI
    retrieve(), KHÁC gap-fill nội bộ đã có trong
    stages/d_retrieval.py::entity_path_search (gap-fill đó bù ĐÚNG 1 CẠNH
    cụ thể trong 1 path entity đã biết, bằng sub_query
    "{entity_a} {relation} {entity_b}"). Hàm này bù khi TOÀN BỘ pool sau
    khi hợp nhất mọi kênh (dense/bm25/graph/entity-path) vẫn thiếu —
    dùng `retrieval.retrieval_gap_terms` (key-term CÓ trong corpus nhưng bị
    retrieval bỏ lỡ, đã tính sẵn trong compute_coverage() nhưng trước đây
    bị bỏ phí — không caller nào dùng lại) làm sub-query bổ sung.

    BẮT BUỘC giới hạn cứng 1 vòng: hàm này chỉ gọi retrieve() bổ sung ĐÚNG 1
    LẦN, không tự đệ quy — caller (answer_query) chịu trách nhiệm không gọi
    lại hàm này lần thứ 2 cho cùng 1 câu hỏi (tham số _gap_retry_done).

    Trả về RetrievalResult đã hợp nhất candidate cũ+mới rồi self_verify lại,
    hoặc None nếu lượt retrieve() bổ sung thất bại hoặc không mang lại
    candidate nào mới — trường hợp đó caller giữ nguyên insufficient_context
    cũ, không có gì để thử thêm.
    """
    from stages import d_retrieval  # lazy import — D luôn có trước E trong pipeline, nhưng tránh ràng buộc module-level ngoài lúc thật sự cần

    sub_query_text = " ".join(retrieval.retrieval_gap_terms)
    logger.info("answer_query: insufficient_context nhưng còn %d retrieval_gap_terms chưa dùng "
                "(%s) — thử retrieve() thêm ĐÚNG 1 lượt với sub-query bổ sung: %r",
                len(retrieval.retrieval_gap_terms), retrieval.retrieval_gap_terms, sub_query_text)

    sub_query = RetrievalQuery(
        query_text=sub_query_text,
        top_k_final=original_query.top_k_final,
        top_k_per_source=original_query.top_k_per_source,
        source_id=original_query.source_id,
    )
    try:
        extra = d_retrieval.retrieve(sub_query, llm)
    except Exception as e:
        logger.warning("answer_query: retry retrieve() thất bại (%s) — giữ nguyên insufficient_context", e)
        return None

    existing_ids = {c.atom_id for c in retrieval.candidates}
    new_candidates = [c for c in extra.candidates if c.atom_id not in existing_ids]
    if not new_candidates:
        logger.info("answer_query: retry retrieve() không tìm thêm được candidate mới nào, bỏ qua")
        return None

    merged_candidates = sorted(list(retrieval.candidates) + new_candidates,
                                key=lambda c: c.relevance_score, reverse=True)

    key_terms = d_retrieval.extract_key_terms(query_text)
    coverage_ratio, uncovered_terms, retrieval_gap_terms = d_retrieval.compute_coverage(
        key_terms, merged_candidates, llm, source_id=original_query.source_id,
        corpus_check_enabled=settings.d_coverage_check_scope == "full_corpus",
    )
    # edges = db.get_edges_between_atoms([c.atom_id for c in merged_candidates])
    result = d_retrieval.self_verify(
        merged_candidates, coverage_ratio, uncovered_terms, retrieval.suggestions,
        chain_coverage=retrieval.chain_coverage,
    )
    result.query_text = query_text
    result.entity_paths = retrieval.entity_paths + extra.entity_paths
    result.retrieval_gap_terms = retrieval_gap_terms
    return result


def answer_query(query_text: str, retrieval: RetrievalResult, llm: LLMClient,
                  original_query: Optional[RetrievalQuery] = None,
                  _gap_retry_done: bool = False) -> AnswerWithCitations:
    """Entry point for stage E.

    `original_query` (MỚI — đề xuất #14, optional): RetrievalQuery gốc đã
    dùng để gọi retrieve() lần đầu. CHỈ cần truyền vào nếu muốn bật retry
    gap-fill 1 lượt (xem _retry_with_retrieval_gap) khi
    insufficient_context=True; không truyền (None, mặc định) giữ nguyên
    hành vi cũ y hệt trước đây. `_gap_retry_done` chỉ dùng NỘI BỘ để giới
    hạn cứng 1 vòng retry — không truyền tay từ ngoài.
    """
    # 1. Trường hợp insufficient_context
    if retrieval.insufficient_context:
        if (settings.d_gap_retry_enabled and not _gap_retry_done
                and original_query is not None and retrieval.retrieval_gap_terms):
            retried = _retry_with_retrieval_gap(query_text, retrieval, original_query, llm)
            if retried is not None:
                return answer_query(query_text, retried, llm,
                                     original_query=original_query, _gap_retry_done=True)
        return AnswerWithCitations(
            answer="Tài liệu hiện có không chứa thông tin đủ tin cậy để trả lời câu hỏi này"
                   + (f" (không tìm thấy: {', '.join(retrieval.uncovered_terms)})."
                      if retrieval.uncovered_terms else "."),
            citations=[], insufficient_context=True,
            uncovered_topics=retrieval.uncovered_terms,
        )

    data = build_answer_json(query_text, retrieval, llm)
    answer_text = data["answer"]
    uncovered_topics = list(dict.fromkeys(data.get("uncovered_topics", []) + retrieval.uncovered_terms))

    valid_atom_ids = {c.atom_id for c in retrieval.candidates}
    atom_lookup = _atom_lookup(retrieval)

    cleaned_answer, stripped = verify_and_strip_unsupported(answer_text, valid_atom_ids, atom_lookup, llm)

    if not cleaned_answer.strip():
        # Everything got stripped as unsupported — don't return an empty
        # string, be explicit that grounding failed rather than silently
        # returning nothing.
        cleaned_answer = ("Không thể tạo câu trả lời có căn cứ rõ ràng từ tài liệu cho câu hỏi này.")
        if uncovered_topics:
            cleaned_answer += f" Các khái niệm sau không có trong tài liệu: {', '.join(uncovered_topics)}."

    final_cited_ids = [aid for aid in extract_cited_ids(cleaned_answer) if aid in valid_atom_ids]
    citations = build_citation_chain(final_cited_ids)

    return AnswerWithCitations(
        answer=cleaned_answer,
        citations=citations,
        insufficient_context=False,
        uncovered_topics=uncovered_topics,
        stripped_unsupported_sentences=stripped,
    )

def build_suggestions(cited_atom_ids: list[str]) -> list[Suggestion]:
    """Với mỗi atom ID được trích dẫn, tìm parent hoặc child tương ứng để gợi ý."""
    suggestions = []
    seen = set()

    with db.get_conn() as conn:
        for atom_id in cited_atom_ids:
            # Kiểm tra xem atom_id có trong chunk_records không
            row = conn.execute(
                "SELECT id, type, content, parent_id, children FROM chunk_records WHERE id = %s",
                (atom_id,)
            ).fetchone()
            if not row:
                continue

            if row["type"] == "child":
                # Nếu là child, lấy parent của nó
                parent_id = row["parent_id"]
                if parent_id and parent_id not in seen:
                    # Lấy thông tin parent
                    parent_row = conn.execute(
                        "SELECT content FROM chunk_records WHERE id = %s AND type = 'parent'",
                        (parent_id,)
                    ).fetchone()
                    if parent_row:
                        preview = parent_row["content"][:200] + "..." if len(parent_row["content"]) > 200 else parent_row["content"]
                        suggestions.append(Suggestion(
                            chunk_id=parent_id,
                            type="parent",
                            content_preview=preview,
                            children_count=None,
                            parent_id=None
                        ))
                        seen.add(parent_id)

            elif row["type"] == "parent":
                # Nếu là parent, lấy các child của nó
                child_ids = row["children"] or []
                for child_id in child_ids:
                    if child_id not in seen:
                        child_row = conn.execute(
                            "SELECT content FROM chunk_records WHERE id = %s AND type = 'child'",
                            (child_id,)
                        ).fetchone()
                        if child_row:
                            preview = child_row["content"][:200] + "..." if len(child_row["content"]) > 200 else child_row["content"]
                            suggestions.append(Suggestion(
                                chunk_id=child_id,
                                type="child",
                                content_preview=preview,
                                parent_id=row["id"],
                                children_count=None
                            ))
                            seen.add(child_id)

    return suggestions

def build_suggestions_from_candidates(candidates: list[RetrievedCandidate], top_k: int = 3) -> list[Suggestion]:
    """Lọc các candidate có score cao (≥ 0.7) và tạo suggestions."""
    sorted_candidates = sorted(
        [c for c in candidates if c.relevance_score >= settings.e_query_out_PARENT_FALLBACK_THRESHOLD],
        key=lambda c: c.relevance_score,
        reverse=True
    )[:top_k]
    # atom_ids = [c.atom_id for c in sorted_candidates]
    suggestions = []
    for atom in sorted_candidates:
        suggestions.append(Suggestion(
                            chunk_id=atom.atom_id,
                            type=atom.type,
                            content_preview=atom.raw,
                            children_count=None,
                            parent_id=None
                        ))
    return suggestions

def _join_entity_path_chains(hops: list) -> list[list]:
    """Câu hỏi người dùng — entity_paths hiện chỉ in từng hop rời "A>B",
    "B>C" thành 2 dòng riêng, dù target_entity_id của hop này == source_
    entity_id của hop kia (tức về logic là 1 chuỗi liền A->B->C->D). LLM
    phải tự nhận ra 2 dòng chung 1 entity để nối lại — rủi ro nối sai/nối
    nhầm 2 chuỗi khác nhau khi có nhiều nhánh trộn lẫn. Hàm này nối các hop
    liên tiếp thành 1 chuỗi TRƯỚC khi hiển thị, dùng entity_id (không dùng
    label string — 2 entity khác nhau có thể trùng label hiển thị).

    Trả về list các "chain" — mỗi chain là 1 list hop liên tiếp (len>=1).
    Chỉ nối khi nối 1-1 (không rẽ nhánh); nếu 1 entity có nhiều hop đi ra,
    chỉ nối tiếp theo 1 nhánh (ưu tiên hop có evidence), các hop còn lại của
    nhánh khác vẫn được trả ra như chain riêng (len=1) — không ép nối sai."""
    if not hops:
        return []

    # outgoing[source_entity_id] = list of hop index đi ra từ entity đó
    outgoing: dict[str, list[int]] = {}
    # incoming_targets = tập target_entity_id đã từng là target của 1 hop
    # nào đó -> dùng để xác định "root" (entity KHÔNG là target của hop nào
    # khác trong tập hop hiện tại -> là điểm bắt đầu chuỗi hợp lý).
    incoming_targets: set[str] = set()
    for i, h in enumerate(hops):
        if h.source_entity_id:
            outgoing.setdefault(h.source_entity_id, []).append(i)
        if h.target_entity_id:
            incoming_targets.add(h.target_entity_id)

    consumed = [False] * len(hops)
    chains: list[list] = []

    def _pick_continuation(entity_id: str, visited: set[str]) -> Optional[int]:
        """Trong các hop đi ra từ entity_id, CHƯA dùng, CHƯA thăm (tránh vòng
        lặp) -> ưu tiên hop có evidence, nếu không có evidence thì lấy hop
        đầu tiên."""
        candidates_idx = [
            i for i in outgoing.get(entity_id, [])
            if not consumed[i] and hops[i].target_entity_id not in visited
        ]
        if not candidates_idx:
            return None
        with_evidence = [i for i in candidates_idx if hops[i].evidence_atom_ids]
        return with_evidence[0] if with_evidence else candidates_idx[0]

    # Bắt đầu từ các "root" trước (source không phải target của hop nào
    # khác) để chuỗi được nối từ ĐẦU chuỗi thật, không bắt đầu giữa chuỗi.
    root_starts = [i for i, h in enumerate(hops)
                   if h.source_entity_id and h.source_entity_id not in incoming_targets]
    other_starts = [i for i in range(len(hops)) if i not in root_starts]

    for i in root_starts + other_starts:
        if consumed[i]:
            continue
        chain = [hops[i]]
        consumed[i] = True
        visited = {hops[i].source_entity_id, hops[i].target_entity_id}
        current_target = hops[i].target_entity_id
        while current_target:
            nxt = _pick_continuation(current_target, visited)
            if nxt is None:
                break
            consumed[nxt] = True
            chain.append(hops[nxt])
            visited.add(hops[nxt].target_entity_id)
            current_target = hops[nxt].target_entity_id
        chains.append(chain)

    return chains


def _format_entity_paths_block(retrieval: RetrievalResult, atom_text_map: dict[str, str]) -> str:
    """Đề xuất #1 — hiển thị chuỗi entity-fact (Entity_A --CAUSES--> Entity_B
    --TRIGGERS--> Entity_C) mà entity_path_search tìm được, kèm evidence
    atom cho mỗi cạnh (nếu có trong candidates hiện tại — evidence atom
    luôn có mặt trong retrieval.candidates vì entity_path_search chính là
    nguồn tạo ra các candidate đó, xem stages/d_retrieval.py::retrieve()).
    Đặt TRƯỚC relations_block (atom-atom, generic) — xem
    ANSWER_SYSTEM_PROMPT_ADDITION cho cách model được hướng dẫn dùng 2 block
    này khác nhau.

    Nối các hop liên tiếp (target của hop này == source của hop kia) thành
    1 chuỗi duy nhất trước khi in — xem _join_entity_path_chains."""
    if not retrieval.entity_paths:
        return ""
    chains = _join_entity_path_chains(retrieval.entity_paths)
    lines = []
    for chain in chains:
        evidence_bits = []
        for hop in chain:
            for aid in hop.evidence_atom_ids:
                text = atom_text_map.get(aid)
                bit = f"[#{aid}] \"{text[:150]}\"" if text else f"[#{aid}]"
                if bit not in evidence_bits:
                    evidence_bits.append(bit)
        evidence_str = f" (evidence: {'; '.join(evidence_bits)})" if evidence_bits else " (chưa có evidence — đối chiếu cẩn thận trước khi dùng)"
        # Nối chuỗi: A --REL1--> B --REL2--> C --REL3--> D
        chain_str = chain[0].source_label
        for hop in chain:
            chain_str += f" --{hop.relation_type}--> {hop.target_label}"
        lines.append(f"- {chain_str}{evidence_str}")
    return (
        "\n\nChuỗi quan hệ suy luận được tìm thấy (đối chiếu evidence trước khi dùng):\n"
        + "\n".join(lines)
    )
