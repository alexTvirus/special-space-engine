"""
A4.5 — Entity Consolidation

INPUT:  list[KnowledgeAtom] for one source_id (everything B1 has stored once
        all of that source_id's section_jobs are DONE — same precondition A5
        already relies on, see db.all_section_jobs_done).
OUTPUT: list[EntityMention] (consolidated, persisted `entity_map` table) —
        also mutates each atom's `.entities` list in place (adding a resolved
        "entity_id" key) and persists that via db.update_atom_entities, so
        B2's MENTIONS edge builder and A5's candidate_pairs builder can both
        just read ent["entity_id"] straight off the atom.

Why this stage exists (see thiet_ke_cai_tien_kb_pipeline_final.md §2 and
mdu1.md §2): GLiNER's fixed tech-only entity_types gave meaningless output on
real, multi-domain documents. A4 now extracts entities itself (LLM, correct
domain context, same call as element extraction — see
a4_constraint_extraction.EXTRACTION_SYSTEM_PROMPT), but those are still just
raw per-sentence mentions with no cross-document/cross-section identity: the
same real-world entity can show up as "MySQL", "mysql", "MySQL Server" across
different sentences. This stage is the ONE place that resolves all of those
into a single canonical entity_id per source_id.

Two independent things happen here, in order:
  1. Hybrid dedupe (lexical + embedding, gated by entity `type`) — merges
     spelling/casing variants of the same entity via union-find.
  2. IDF-style frequency filter — entities appearing in more sections than
     `a4_5_entity_common_cutoff` are "common" (topic-level noise for the
     purpose of DRIVING new candidate_pairs in A5) but are NOT dropped
     entirely: they still get a MENTIONS edge in B2 (that edge is free/
     structural, no LLM cost), just excluded from A5's entity-based candidate
     generation so the candidate_pairs batch doesn't balloon back up to
     "every atom that mentions a super common word".

"entity trọng yếu trong 1 câu" (A4 only extracts what's salient enough to be
worth naming) and "entity phổ biến/hiếm trên toàn tài liệu" are two
independent axes — good per-sentence extraction does NOT make the frequency
filter unnecessary.
"""
from __future__ import annotations

import re
from collections import defaultdict
from typing import Optional

from rapidfuzz import fuzz

from common import db
from common.config import settings
from common.llm_client import LLMClient
from common.schemas import KnowledgeAtom, EntityMention


class EntityCandidate:
    """One raw (name, type) mention, tagged with where it came from. Not a
    Pydantic model — purely an internal working structure for this stage's
    union-find pass, never serialized/persisted as-is."""

    __slots__ = ("name", "type", "section_id", "atom_id", "embedding")

    def __init__(self, name: str, type_: str, section_id: str, atom_id: str):
        self.name = name
        self.type = type_
        self.section_id = section_id
        self.atom_id = atom_id
        self.embedding: Optional[list[float]] = None


_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slug(text: str) -> str:
    return _SLUG_RE.sub("_", text.strip().lower()).strip("_") or "entity"


def _grounded_in_raw(name: str, raw: str, normalized: Optional[str] = None) -> bool:
    if not name:
        return False
    if raw and (name.lower() in raw.lower()
                or fuzz.partial_ratio(name.lower(), raw.lower()) >= settings.a4_5_entity_lexical_threshold):
        return True
    if normalized and (name.lower() in normalized.lower()
                        or fuzz.partial_ratio(name.lower(), normalized.lower()) >= settings.a4_5_entity_lexical_threshold):
        return True
    return False


def collect_candidates(atoms: list[KnowledgeAtom]) -> list[EntityCandidate]:
    """Flattens every atom.entities dict into one EntityCandidate per
    (atom, mention) pair. Multiple mentions of the same name within one atom
    only produce one candidate (dedup at the atom level is meaningless noise
    for cross-section consolidation). Entity names that don't actually
    appear (verbatim or near-verbatim) in the atom's own `raw` text are
    dropped here — see _grounded_in_raw."""
    candidates: list[EntityCandidate] = []
    dropped = 0
    for atom in atoms:
        seen_in_atom: set[tuple[str, str]] = set()
        for ent in atom.entities or []:
            name = (ent.get("name") or "").strip()
            etype = (ent.get("type") or "OTHER").strip() or "OTHER"
            if not name:
                continue
            if not _grounded_in_raw(name, atom.raw, atom.normalized):
                dropped += 1
                continue
            key = (name.lower(), etype.lower())
            if key in seen_in_atom:
                continue
            seen_in_atom.add(key)
            candidates.append(EntityCandidate(name, etype, atom.section_id, atom.id))
    if dropped:
        import logging
        logging.getLogger(__name__).warning(
            "A4.5: dropped %d entity mention(s) not grounded in their atom's raw text "
            "(likely LLM hallucination in A4's entities field)", dropped)
    return candidates


def entity_similarity(a: EntityCandidate, b: EntityCandidate) -> float:
    """Hybrid lexical+embedding score. Hard type gate first — never merge
    across types even if the names look similar (e.g. "MySQL" the technology
    vs a hypothetical "MySQL" organization name), matching the design-doc
    rule that catches "MySQL" <-> "PostgreSQL" false-positives at the
    embedding level alone.

    Lexical score is computed on lowercased names: rapidfuzz's fuzz.*
    functions are case-sensitive by default (fuzz.token_sort_ratio("MySQL",
    "mysql") == ~20, not ~100), so comparing raw-case strings would fail to
    merge the single most common real-world variant — differing only in
    capitalization — that this stage exists to catch.
    """
    if a.type.strip().lower() != b.type.strip().lower():
        return 0.0
    lex = fuzz.token_sort_ratio(a.name.lower(), b.name.lower()) / 100.0
    emb = 0.0
    if a.embedding is not None and b.embedding is not None:
        emb = _cosine(a.embedding, b.embedding)
    return settings.a4_5_entity_lex_weight * lex + settings.a4_5_entity_emb_weight * emb


def _cosine(u: list[float], v: list[float]) -> float:
    import math
    dot = sum(x * y for x, y in zip(u, v))
    nu = math.sqrt(sum(x * x for x in u))
    nv = math.sqrt(sum(y * y for y in v))
    if nu == 0 or nv == 0:
        return 0.0
    return dot / (nu * nv)


class _UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[ra] = rb


def dedupe_candidates(candidates: list[EntityCandidate], llm: LLMClient) -> list[list[EntityCandidate]]:
    """Union-find merge of every candidate pair scoring above threshold.
    O(n^2) comparisons — fine for the entity-name scale a single document
    produces (hundreds, not tens of thousands); if that ever becomes a
    bottleneck, bucket by `type` first (cheap) before the O(n^2) pass."""
    if not candidates:
        return []

    names = [c.name for c in candidates]
    try:
        embeddings = llm.embed(names)
        for c, emb in zip(candidates, embeddings):
            c.embedding = emb
    except Exception:
        pass  # fall back to lexical-only matching below (embedding stays None)

    n = len(candidates)
    uf = _UnionFind(n)
    for i in range(n):
        for j in range(i + 1, n):
            a, b = candidates[i], candidates[j]
            if a.type.strip().lower() != b.type.strip().lower():
                continue
            lex_pct = fuzz.token_sort_ratio(a.name.lower(), b.name.lower())
            combined = entity_similarity(a, b)
            if lex_pct >= settings.a4_5_entity_lexical_threshold or combined >= settings.a4_5_entity_embed_threshold:
                uf.union(i, j)

    groups: dict[int, list[EntityCandidate]] = defaultdict(list)
    for i in range(n):
        groups[uf.find(i)].append(candidates[i])
    return list(groups.values())


def build_entity_map(source_id: str, groups: list[list[EntityCandidate]]) -> tuple[list[EntityMention], dict[tuple[str, str], str]]:
    """Turns each union-find group into one persisted EntityMention, and
    returns a (name.lower(), type.lower()) -> entity_id lookup so callers can
    resolve every raw atom.entities mention back to its group's entity_id."""
    entities: list[EntityMention] = []
    name_to_id: dict[tuple[str, str], str] = {}
    used_ids: set[str] = set()

    for group in groups:
        # Prefer the longest name as the canonical display form (fullest,
        # least likely to be an abbreviation), tie-broken by first-seen.
        primary = max(group, key=lambda c: len(c.name))
        entity_type = primary.type
        base_id = f"ent_{_slug(primary.name)}_{_slug(source_id)}"
        entity_id = base_id
        # Collision guard: two DIFFERENT groups (didn't merge — e.g. same
        # slugged name but different type, or dedupe legitimately kept them
        # apart) must never share one entity_id, or the second's
        # db.save_entity_map upsert would silently overwrite the first's row.
        suffix = 2
        while entity_id in used_ids:
            entity_id = f"{base_id}_{suffix}"
            suffix += 1
        used_ids.add(entity_id)

        section_ids: list[str] = []
        mention_count = 0
        for c in group:
            if c.section_id not in section_ids:
                section_ids.append(c.section_id)
            mention_count += 1
            name_to_id[(c.name.lower(), c.type.lower())] = entity_id

        entities.append(EntityMention(
            entity_id=entity_id, canonical_name=primary.name, type=entity_type,
            mentions=list({c.name for c in group}), section_ids=section_ids,
            section_count=len(section_ids), mention_count=mention_count,
            # `primary` is the EntityCandidate chosen as canonical display
            # form above — its .embedding was computed in dedupe_candidates()
            # (llm.embed(names)) and previously thrown away once union-find
            # was done. Reuse it as-is instead of a fresh embed call.
            name_embedding=primary.embedding,
        ))
    return entities, name_to_id


def resolve_atom_entities(atoms: list[KnowledgeAtom], name_to_id: dict[tuple[str, str], str]) -> None:
    """Mutates atom.entities in place (adds "entity_id") and persists the
    change — this is what makes ent["entity_id"] safe for B2/A5 to read
    without KeyError."""
    for atom in atoms:
        changed = False
        new_entities = []
        for ent in atom.entities or []:
            name = (ent.get("name") or "").strip()
            etype = (ent.get("type") or "OTHER").strip() or "OTHER"
            key = (name.lower(), etype.lower())
            entity_id = name_to_id.get(key)
            if entity_id is None:
                # Shouldn't happen (every candidate came from some atom), but
                # never crash on it — degrade to a stable per-atom fallback id
                # rather than silently dropping the mention.
                entity_id = f"ent_{_slug(name)}_{_slug(atom.source_id)}"
            new_ent = dict(ent)
            new_ent["entity_id"] = entity_id
            new_entities.append(new_ent)
            changed = True
        if changed:
            atom.entities = new_entities
            db.update_atom_entities(atom.id, new_entities)


def consolidate_entities(source_id: str, atoms: list[KnowledgeAtom], llm: LLMClient) -> list[EntityMention]:
    """Entry point for stage A4.5. Never raises — worst case (embed call
    fails, or zero candidates) it returns an empty/lexical-only entity_map
    rather than blocking the rest of the pipeline."""
    candidates = collect_candidates(atoms)
    if not candidates:
        return []

    groups = dedupe_candidates(candidates, llm)
    entities, name_to_id = build_entity_map(source_id, groups)

    resolve_atom_entities(atoms, name_to_id)
    db.save_entity_map(source_id, entities)
    return entities
