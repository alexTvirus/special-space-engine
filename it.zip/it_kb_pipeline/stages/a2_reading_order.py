"""
A2 — Reading Order Verify + Cross-page Table merge

INPUT:  UnifiedDoc (output of A1)
OUTPUT: UnifiedDoc (same object, annotated: issues appended, elements
        flagged is_footnote/is_sidebar, adjacent split tables merged)

Kept as pure, dependency-light code per the design doc (no LLM here), except
for the optional pdfplumber bbox backfill below, which only runs for PDFs
and only touches elements that don't already have a bbox.

FIX LOG (vs previous version):
  - The design doc calls for "pdfplumber - trich bbox doc lap" but no such
    code existed; without it, any element whose primary parser didn't attach
    a bbox (e.g. pymupdf blocks mode, or any stub fallback) silently
    disabled verify_reading_order/detect_footnote/detect_sidebar for that
    element (they all early-return False/no-op on `bbox is None`).
    `backfill_bboxes_from_pdfplumber()` now fills those gaps.
  - `try_merge_tables` compared `bbox.bottom`/`bbox.top` (absolute PDF point
    coordinates, e.g. ~0-792) directly against the ratio thresholds 0.75/0.20
    that were clearly meant for *normalized* [0,1] page-position ratios -
    a bbox.bottom of, say, 700 would fail `> 0.75` even though the table
    physically sits at the very bottom of the page. Both are now divided by
    an actual page height first.
  - `try_merge_tables` compared table headers with strict `==`, so any
    whitespace/OCR noise difference silently voted NO_MERGE. Now uses
    rapidfuzz with `settings.a2_table_header_fuzzy_threshold`.
"""
from __future__ import annotations

from typing import Optional

from common.config import settings
from common.schemas import UnifiedDoc, DocElement, ElementType, BBox, ParseIssue

_DEFAULT_PAGE_HEIGHT = 792.0  # US Letter points; used only when the real
                              # page height can't be looked up.


# -----------------------------------------------------------------------------
# pdfplumber independent bbox extraction (design-doc component that was
# previously unimplemented) — backfills bbox for elements the primary parser
# left without one, so downstream reading-order/footnote/table-merge logic
# actually has something to compare.
# -----------------------------------------------------------------------------
def _pdfplumber_lines_by_page(file_path: str) -> dict[int, list[tuple[str, BBox]]]:
    try:
        import pdfplumber
    except Exception:
        return {}
    pages_lines: dict[int, list[tuple[str, BBox]]] = {}
    try:
        with pdfplumber.open(file_path) as pdf:
            for i, page in enumerate(pdf.pages):
                words = page.extract_words()
                if not words:
                    continue
                # Group words into visual lines by rounding their vertical
                # position — pdfplumber gives per-word boxes, not per-line.
                buckets: dict[int, list[dict]] = {}
                for w in words:
                    key = round(w["top"] / 2) * 2
                    buckets.setdefault(key, []).append(w)
                lines = []
                for key in sorted(buckets):
                    ws = sorted(buckets[key], key=lambda w: w["x0"])
                    text = " ".join(w["text"] for w in ws)
                    lines.append((text, BBox(
                        page=i + 1,
                        top=min(w["top"] for w in ws),
                        left=min(w["x0"] for w in ws),
                        bottom=max(w["bottom"] for w in ws),
                        right=max(w["x1"] for w in ws),
                    )))
                pages_lines[i + 1] = lines
    except Exception:
        return {}
    return pages_lines


def backfill_bboxes_from_pdfplumber(doc: UnifiedDoc) -> None:
    """Mutates `doc.elements` in place: for any element on a PDF page that
    is missing `metadata.bbox`, fuzzy-match its text against pdfplumber's
    independent word extraction for that page and attach the best bbox
    match, provided the match score clears
    `settings.a2_bbox_match_score_threshold`. No-op for non-PDF sources or
    when pdfplumber isn't installed."""
    if not settings.a2_bbox_backfill_enabled or doc.file_type != "pdf":
        return
    missing = [e for e in doc.elements if e.metadata.bbox is None and e.metadata.page and e.content_display.strip()]
    if not missing:
        return
    pages_lines = _pdfplumber_lines_by_page(doc.file_path)
    if not pages_lines:
        return
    try:
        from rapidfuzz import process, fuzz
    except Exception:
        return
    for el in missing:
        page_lines = pages_lines.get(el.metadata.page)
        if not page_lines:
            continue
        candidates = [t for t, _ in page_lines]
        match = process.extractOne(el.content_display, candidates, scorer=fuzz.token_sort_ratio)
        if match and match[1] >= settings.a2_bbox_match_score_threshold:
            _, _, idx = match
            el.metadata.bbox = page_lines[idx][1]


_page_height_cache: dict[str, dict[int, float]] = {}


def _page_height(file_path: str, page_number: Optional[int]) -> float:
    """Real page height in points, looked up once per file_path and cached,
    so try_merge_tables can turn absolute bbox coordinates into the [0,1]
    ratios its thresholds actually expect. Falls back to US Letter height on
    any failure (missing fitz, non-PDF source, out-of-range page, ...)."""
    if page_number is None:
        return _DEFAULT_PAGE_HEIGHT
    if file_path not in _page_height_cache:
        heights: dict[int, float] = {}
        try:
            import fitz
            doc = fitz.open(file_path)
            for i, page in enumerate(doc):
                heights[i + 1] = page.rect.height
        except Exception:
            pass
        _page_height_cache[file_path] = heights
    return _page_height_cache[file_path].get(page_number, _DEFAULT_PAGE_HEIGHT)


# Mã giả #3
def verify_reading_order(elements: list[DocElement]) -> tuple[list[ParseIssue], bool]:
    tool_order = [e.id for e in elements]
    spatial_order = sorted(
        elements,
        key=lambda e: (
            (e.metadata.bbox.page if e.metadata.bbox else e.metadata.page or 0),
            (e.metadata.bbox.top if e.metadata.bbox else 0),
            (e.metadata.bbox.left if e.metadata.bbox else 0),
        ),
    )
    spatial_ids = [e.id for e in spatial_order]
    mismatches = sum(1 for a, b in zip(tool_order, spatial_ids) if a != b)
    diff_ratio = mismatches / len(elements) if elements else 0.0
    if diff_ratio > settings.reading_order_diff_threshold:
        return [ParseIssue(level="WARNING", message="Reading order mismatch",
                            detail={"diff_ratio": diff_ratio})], True
    return [], False


# Mã giả #4
BODY_FONT_SIZE = 11.0


def detect_footnote(element: DocElement, page_height: float = 792.0) -> bool:
    if not element.metadata.bbox or not element.metadata.font_size:
        return False
    y_ratio = element.metadata.bbox.top / page_height if page_height else 0
    return y_ratio > 0.90 and element.metadata.font_size < BODY_FONT_SIZE * 0.85


def detect_sidebar(element: DocElement, main_column_bounds: tuple[float, float]) -> bool:
    if not element.metadata.bbox:
        return False
    left, right = main_column_bounds
    return element.metadata.bbox.left < left or element.metadata.bbox.right > right


# Mã giả #5
def try_merge_tables(table_i: DocElement, table_j: DocElement, file_path: Optional[str] = None) -> str:
    conditions_met = 0
    cols_i = table_i.content_raw.split("\n")[0].count("|") if table_i.content_raw else 0
    cols_j = table_j.content_raw.split("\n")[0].count("|") if table_j.content_raw else 0

    if cols_i == cols_j:
        conditions_met += 1

    # bbox.bottom/.top are absolute PDF-point coordinates (e.g. ~0-792), but
    # the 0.75/0.20 thresholds below are meant as *ratios* of page height —
    # divide by the real page height (or Letter default) before comparing,
    # otherwise a table sitting at the true bottom of the page (e.g.
    # bottom=700) would wrongly fail the `> 0.75` check.
    page_i = table_i.metadata.bbox.page if table_i.metadata.bbox else table_i.metadata.page
    page_j = table_j.metadata.bbox.page if table_j.metadata.bbox else table_j.metadata.page
    height_i = _page_height(file_path, page_i) if file_path else _DEFAULT_PAGE_HEIGHT
    height_j = _page_height(file_path, page_j) if file_path else _DEFAULT_PAGE_HEIGHT
    bottom_i_ratio = (table_i.metadata.bbox.bottom / height_i) if table_i.metadata.bbox else 1.0
    top_j_ratio = (table_j.metadata.bbox.top / height_j) if table_j.metadata.bbox else 0.0
    if bottom_i_ratio > 0.75:
        conditions_met += 1
    if top_j_ratio < 0.20:
        conditions_met += 1

    header_i = table_i.content_raw.split("\n")[0] if table_i.content_raw else ""
    header_j = table_j.content_raw.split("\n")[0] if table_j.content_raw else ""
    if not header_j:
        conditions_met += 1
    else:
        try:
            from rapidfuzz import fuzz
            if fuzz.ratio(header_i, header_j) >= settings.a2_table_header_fuzzy_threshold:
                conditions_met += 1
        except Exception:
            if header_i == header_j:
                conditions_met += 1

    if conditions_met == 4:
        return "AUTO_MERGE"
    if conditions_met == 3:
        return "FLAG_REVIEW"
    return "NO_MERGE"


def verify_and_fix(doc: UnifiedDoc) -> UnifiedDoc:
    """Entry point for stage A2."""
    backfill_bboxes_from_pdfplumber(doc)

    issues, needs_review = verify_reading_order(doc.elements)
    doc.issues.extend(issues)
    doc.needs_review = doc.needs_review or needs_review

    for el in doc.elements:
        if el.type == ElementType.PARAGRAPH:
            if detect_footnote(el):
                el.metadata.is_footnote = True
                el.type = ElementType.FOOTNOTE

    # merge adjacent split tables
    merged: list[DocElement] = []
    tables_pending = None
    for el in doc.elements:
        if el.type == ElementType.TABLE:
            if tables_pending is None:
                tables_pending = el
                continue
            decision = try_merge_tables(tables_pending, el, file_path=doc.file_path)
            if decision == "AUTO_MERGE":
                tables_pending.content_raw += "\n" + el.content_raw
                tables_pending.content_display += "\n" + el.content_display
                continue
            elif decision == "FLAG_REVIEW":
                doc.issues.append(ParseIssue(level="WARNING",
                                              message=f"Possible split table {tables_pending.id}/{el.id}"))
            merged.append(tables_pending)
            tables_pending = el
        else:
            if tables_pending is not None:
                merged.append(tables_pending)
                tables_pending = None
            merged.append(el)
    if tables_pending is not None:
        merged.append(tables_pending)

    doc.elements = merged
    return doc
