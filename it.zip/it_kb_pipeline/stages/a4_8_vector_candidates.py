"""
A4.8 — Vector Candidate Pre-filter

INPUT:  list[KnowledgeAtom] (atoms whose SIMILAR_TO edges/candidate pairs
        need (re)computing — the full document on first ingest, or just the
        new/changed atoms on an incremental update, see mục 6 of the design
        doc / create_kb_from_file.py orchestration).
OUTPUT: list[tuple[from_id, to_id, score]] — the vector-based half of A5's
        candidate_pairs (see a5_global_merge.build_candidate_pairs).
        SIDE EFFECT: writes a SIMILAR_TO kg_edge for every pair above
        threshold DIRECTLY (no LLM involved) — usable immediately by D's
        graph_search for retrieval expansion, independent of whether A5 ever
        confirms a "real" relation type for that pair.

Why this stage exists (see mdu1.md §1/§3 and thiet_ke_cai_tien_kb_pipeline_final.md
§4): A5's previous 150-atom sequential batching is a "blind split by
position" — two related atoms in different batches (purely due to where they
happen to sit in the document) are never seen together by the LLM. ANN
search over embeddings (cheap, no LLM, ~O(log N) via the hnsw index already
on knowledge_atoms.embedding) finds related atoms across the WHOLE document
regardless of position, and produces two things:
  1. `SIMILAR_TO(score)` edges — sufcient on their own for *retrieval*
     purposes (mdu1.md's "80% giá trị với 20% chi phí"): no LLM needed
     because retrieval just needs "atom liên quan để lấy thêm ngữ cảnh", not
     the exact relation type.
  2. `candidate_pairs` — narrows what A5's LLM call actually has to look at,
     specifically to catch CONTRADICTS (see mdu1.md §3: vector similarity
     cannot tell "agrees" from "contradicts", only an LLM reading both sides
     can).
"""
from __future__ import annotations

from common import db
from common.config import settings
from common.schemas import KnowledgeAtom, KGNode


def build_vector_candidates(atoms: list[KnowledgeAtom]) -> list[tuple[str, str, float]]:
    """Entry point for stage A4.8. For each atom, ANN-search its embedding
    against every OTHER atom in the same source_id (cross-section only —
    same-section relations are already covered by B2's parent/child
    chunking), and for every neighbor above
    settings.a4_8_vector_candidate_threshold: upsert a SIMILAR_TO kg_edge
    immediately and add the pair to the returned candidate list.

    Never raises: a single atom with no embedding (e.g. B1 skipped embedding
    for some reason) is just skipped, not fatal to the whole batch.
    """
    candidate_pairs: list[tuple[str, str, float]] = []
    seen_pairs: set[tuple[str, str]] = set()

    for atom in atoms:
        if not atom.embedding:
            continue
        try:
            neighbors = db.ann_search_atoms(
                atom.embedding, settings.a4_8_top_k_neighbors,
                exclude_section=atom.section_id, source_id=atom.source_id,
            )
        except Exception:
            continue

        for n in neighbors:
            score = float(n.get("score") or 0.0)
            if score < settings.a4_8_vector_candidate_threshold:
                continue
            pair_key = tuple(sorted([atom.id, n["id"]]))
            if pair_key in seen_pairs:
                continue
            seen_pairs.add(pair_key)

            # kg_edges has an FK to kg_nodes on both endpoints, and A4.8 can
            # run before B2 (which normally creates atom KGNodes) — upsert
            # minimal atom nodes here so the edge insert doesn't fail. B2
            # re-upserts the same nodes later with a richer label; both calls
            # are idempotent (ON CONFLICT DO UPDATE).
            db.upsert_kg_node(KGNode(id=atom.id, label=(atom.normalized or atom.raw)[:80],
                                      type="atom", source_id=atom.source_id))
            db.upsert_kg_node(KGNode(id=n["id"], label=(n.get("raw") or "")[:80],
                                      type="atom", source_id=atom.source_id))
            db.upsert_similarity_edge(atom.id, n["id"], score)
            candidate_pairs.append((atom.id, n["id"], score))

    return candidate_pairs
