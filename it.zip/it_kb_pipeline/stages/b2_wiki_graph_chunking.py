"""
B2 — LLM Wiki + Knowledge Graph + Late Chunking

INPUT:  list[KnowledgeAtom] (B1 output for a source_id)
        + MergeResult (A5 output — cross_links become kg_edges)
OUTPUT: common.schemas.B2Output (chunk_records, kg_nodes, kg_edges, wiki_pages)
        -> persisted by stage C (db.upsert_chunk_record / upsert_kg_node / insert_kg_edge,
           plus `git commit` of the wiki markdown files)
"""
from __future__ import annotations

import os
import subprocess
from collections import defaultdict
from typing import Optional
import re
from common import db
from common.config import settings
from common.llm_client import LLMClient
from common.schemas import (
    KnowledgeAtom, MergeResult, ChunkRecord, KGNode, KGEdge, WikiPage, B2Output, GlobalIndex,
    ElementLabel, Fact, FactEvidence,
)


def group_by_section(atoms: list[KnowledgeAtom]) -> dict[str, list[KnowledgeAtom]]:
    grouped = defaultdict(list)
    for a in atoms:
        grouped[a.section_id].append(a)
    return grouped


def concat_display_content(atoms: list[KnowledgeAtom]) -> str:
    return "\n".join(a.normalized or a.raw for a in atoms)

_ENRICHMENT_SYSTEM_PROMPT = (
    "Bạn là trợ lý index hoá tài liệu kỹ thuật. Với đoạn nội dung được đưa "
    "vào, hãy liệt kê ngắn gọn (1-2 câu, hoặc một danh sách từ khoá cách "
    "nhau bằng dấu phẩy) các từ đồng nghĩa/cách diễn đạt khác/thuật ngữ liên "
    "quan mà người dùng có thể dùng để hỏi về đúng nội dung này. Không lặp "
    "lại nội dung gốc, không thêm lời dẫn — chỉ đưa ra danh sách từ khoá."
)

def generate_chunk_enrichment(parent_text: str, llm: LLMClient) -> str:
    """Phase 2 fix (analysis doc #6) — generates a short synonym/keyword
    summary for a parent chunk's text via a cheap tier="light" LLM call.
    Meant to be appended ONLY to the text that gets embedded (never to
    `ChunkRecord.content`, which is what's shown to the user/cited), so the
    chunk's vector "covers" more phrasings of the same content right at
    index time instead of only at query time (see HyDE in stages/
    d_retrieval.py for the query-time counterpart). Returns "" (caller
    should just skip enrichment) if the LLM call fails.
    """
    if not parent_text:
        return ""
    try:
        return llm.generate(parent_text, system=_ENRICHMENT_SYSTEM_PROMPT, tier="light").strip()
    except Exception as e:
        print(f"[CHUNK] enrichment generation failed, skipping: {e}")
        return ""

# Mã giả #13 — parent/child chunk records, only parent gets embedded (late chunking)
def build_chunk_records(atoms: list[KnowledgeAtom], func_get_llm: Callable[[], Any],
                         global_index: Optional[GlobalIndex] = None,
                         sections: Optional[set[str]] = None) -> list[ChunkRecord]:
    """`global_index`: when given, its heading_path_for() breadcrumb is
    prepended to the parent chunk's text before embedding — see
    GlobalIndex.heading_path_for docstring for why (contextual embedding,
    design-doc §7.2). Optional/backward-compatible: pass None to embed the
    raw concatenated content only, same as before.

    `sections`: when given, only builds chunk records for these section_ids
    — the incremental-update path (design-doc §6 step 5) only wants to
    rebuild the parent/child chunks of new/changed sections, not
    re-embed the whole document on every ingest.
    """
    chunk_records: list[ChunkRecord] = []
    for section_id, section_atoms in group_by_section(atoms).items():
        if sections is not None and section_id not in sections:
            continue
        llm = func_get_llm()
        # ---- Kiểm tra xem có atom nào KHÔNG phải heading không ----
        has_non_heading = any(a.label != ElementLabel.HEADING for a in section_atoms)
         # Nếu chỉ có heading mà không có nội dung khác => bỏ qua parent chunk
        if not has_non_heading:
            # Vẫn có thể lưu child records nếu muốn, nhưng vì không có nội dung, ta bỏ qua hẳn
            print(f"[CHUNK] Skipping parent chunk for section '{section_id}' (only heading, no content)")
            continue


        breadcrumb = global_index.heading_path_for(section_id) if global_index else ""
        body = concat_display_content(section_atoms)
        parent_text = f"{breadcrumb}\n{body}" if breadcrumb else body

        print(f"[CHUNK] Building parent for section '{section_id}' with {len(section_atoms)} atoms.")
        print(f"[CHUNK] Parent text preview: {parent_text[:300]}... (total {len(parent_text)} chars)")


        embed_text = parent_text
        if parent_text and settings.b2_chunk_enrichment_enabled:
            enrichment = generate_chunk_enrichment(parent_text, llm)
            if enrichment:
                embed_text = f"{parent_text}\n\n{enrichment}"

        parent_embedding = llm.embed([embed_text])[0] if embed_text else None

        if parent_embedding:
            print(f"[CHUNK] Parent embedding dimension: {len(parent_embedding)}")

        parent_id = f"parent_{section_id}"
        chunk_records.append(ChunkRecord(
            id=parent_id, type="parent", content=parent_text,
            embedding=parent_embedding, children=[a.id for a in section_atoms],
        ))
        for a in section_atoms:
            print(f"  - Child record: id={a.id}, parent_id={parent_id}, raw={a.raw[:150]!r}")
            chunk_records.append(ChunkRecord(
                id=a.id, type="child", content=a.raw, parent_id=parent_id,
                metadata={"label": a.label.value, "normalized": a.normalized},
            ))
    return chunk_records

_TYPE_SLUG_RE = re.compile(r"[^a-z0-9]+")
def _type_slug(text: str) -> str:
    """Same normalization spirit as a4_5_entity_consolidation._slug, kept as
    a small local copy rather than a cross-module import to avoid coupling
    B2 to A4.5's internals for what is a trivial string operation."""
    return _TYPE_SLUG_RE.sub("_", text.strip().lower()).strip("_") or "other"

def build_kg(atoms: list[KnowledgeAtom], merge_result: MergeResult) -> tuple[list[KGNode], list[KGEdge]]:
    """Builds the FULL kg_nodes/kg_edges set for one document:
      - atom nodes + entity nodes (entity nodes come from
        merge_result.resolved_entities, which A5 now just passes through
        unchanged from A4.5's consolidated entity_map)
      - MENTIONS edges: entity -> atom, one per resolved entity mention on
        each atom (design-doc §3 — this is what makes entity_map actually
        useful for graph traversal/retrieval, not just A5 candidate-pair
        generation)
      - SIMILAR_TO edges: pulled in from what A4.8 already persisted
        directly to kg_edges (db.load_similarity_edges) — NOT rebuilt here,
        just folded into the same return value so B2Output/C's caller sees
        one complete picture. If A4.8 never ran (e.g. an atom has no
        embedding), this is simply empty for those atoms.
      - the 4 LLM-confirmed relation types from A5's cross_links (unchanged
        from before), plus: CONTRADICTS pairs now actually set
        contradicts_flag=TRUE on both endpoint atoms (previously nothing in
        the codebase ever wrote to that column).
    """
    edges: list[KGEdge] = []
    facts: list[Fact] = []
    fact_evidence: list[FactEvidence] = []
    section_heading = {}
    for a in atoms:
        if a.label == "HEADING":
            section_heading[a.section_id] = a.id

    # Tạo edges PARENT_OF (từ heading đến các atom khác trong cùng section)
    for a in atoms:
        if a.section_id in section_heading and a.id != section_heading[a.section_id]:
            edges.append(KGEdge(
                source_id=section_heading[a.section_id],
                target_id=a.id,
                relation="PARENT_OF",
                score=1.0,
                tier="structural",
            ))      
    # Tạo edges SAME_SECTION (yếu, score=0.2) giữa các atom cùng section
    if settings.b2_enable_same_section_edges:
        from collections import defaultdict
        section_atoms = defaultdict(list)
        for a in atoms:
            section_atoms[a.section_id].append(a.id)

        for sec_id, ids in section_atoms.items():
            for i in range(len(ids)):
                for j in range(i+1, len(ids)):
                    edges.append(KGEdge(
                        source_id=ids[i],
                        target_id=ids[j],
                        relation="SAME_SECTION",
                        score=0.2
                    ))  

    source_id = atoms[0].source_id if atoms else None
    nodes: dict[str, KGNode] = {}
    for a in atoms:
        nodes[a.id] = KGNode(id=a.id, label=(a.normalized or a.raw)[:80], type="atom", source_id=a.source_id, tier="structural")
    for e in merge_result.resolved_entities:
        nodes[e.entity_id] = KGNode(id=e.entity_id, label=e.canonical_name, type="entity", source_id=source_id, tier="reasoning")

    type_node_ids: dict[str, str] = {}
    for e in merge_result.resolved_entities:
        etype = (e.type or "OTHER").strip() or "OTHER"
        type_key = etype.lower()
        if type_key not in type_node_ids:
            type_node_id = f"type_{_type_slug(etype)}_{source_id}"
            type_node_ids[type_key] = type_node_id
            nodes[type_node_id] = KGNode(id=type_node_id, label=f"[Loại] {etype}", type="type", source_id=source_id)
        edges.append(KGEdge(source_id=e.entity_id, target_id=type_node_ids[type_key],
                             relation="INSTANCE_OF", score=1.0, tier="reasoning"))
    

    # --- MENTIONS: entity -> atom, structural, no LLM, always score=1.0 ---
    seen_mentions: set[tuple[str, str]] = set()
    for a in atoms:
        for ent in (a.entities or []):
            entity_id = ent.get("entity_id")
            if not entity_id or entity_id not in nodes:
                continue  # A4.5 hasn't consolidated this mention (or ran with a stale entity_map) — skip rather than guess
            key = (entity_id, a.id)
            if key in seen_mentions:
                continue
            seen_mentions.add(key)
            edges.append(KGEdge(source_id=entity_id, target_id=a.id, relation="MENTIONS", score=1.0, tier="structural"))

    # --- SIMILAR_TO: already written to kg_edges by A4.8, just reflected here ---
    atom_ids = [a.id for a in atoms]
    edges.extend(db.load_similarity_edges(atom_ids))

    # --- the 4 LLM-confirmed relation types (A5 candidate-pairs output) ---
    contradicting_atom_ids: set[str] = set()
    atom_by_id = {a.id: a for a in atoms}
    # (entity_a, entity_b, relation) -> aggregated projection info. Multiple
    # atom-level cross_links can project onto the same entity pair+relation
    # (e.g. 3 different atom pairs all confirming DEFINES between the same
    # 2 entities) — aggregated instead of inserted as duplicate edges.
    entity_entity_agg: dict[tuple[str, str, str], dict] = {}
    for cl in merge_result.cross_links:
        if not cl.evidence_raw:
            continue  # design-doc rule: no edge without evidence
        edges.append(KGEdge(source_id=cl.from_id, target_id=cl.to_id, relation=cl.relation,
                             evidence_raw=cl.evidence_raw, tier="structural"))
        if cl.relation == "CONTRADICTS":
            contradicting_atom_ids.add(cl.from_id)
            contradicting_atom_ids.add(cl.to_id)
        entities_a = {e["entity_id"] for e in (atom_by_id[cl.from_id].entities or [])
                      if e.get("entity_id")} if cl.from_id in atom_by_id else set()
        entities_b = {e["entity_id"] for e in (atom_by_id[cl.to_id].entities or [])
                      if e.get("entity_id")} if cl.to_id in atom_by_id else set()
        # Cheap safety valve: EXTRACTION_SYSTEM_PROMPT already tells A4 to
        # only list entities "genuinely important" per element (typically
        # 0-3), so this should rarely trigger — but guards against a
        # combinatorial blow-up (entities_a x entities_b pairs) if some
        # element ever comes back with an unusually long entity list.
        if len(entities_a) > 5 or len(entities_b) > 5:
            continue
        for ea in entities_a:
            for eb in entities_b:
                if ea == eb:
                    continue
                key = (ea, eb, cl.relation)
                if key not in entity_entity_agg:
                    entity_entity_agg[key] = {"weight": 0.0, "evidences": []}
                agg = entity_entity_agg[key]
                agg["weight"] += 1.0
                for atom_id in (cl.from_id, cl.to_id):
                    pair = (atom_id, cl.evidence_raw)
                    if pair not in agg["evidences"]:
                        agg["evidences"].append(pair)

    for (ea, eb, relation), agg in entity_entity_agg.items():
        confidence = min(agg["weight"] / 3.0, 1.0)
        # KGEdge chiếu cũ — giữ nguyên hành vi (1 evidence), không đổi để
        # không ảnh hưởng graph_traverse_multi/B2.5 đang đọc kg_edges.
        edges.append(KGEdge(
            source_id=ea, target_id=eb, relation=relation,
            score=confidence,
            evidence_raw=agg["evidences"][0][1] if agg["evidences"] else None,
            tier="reasoning",
        ))
        # MỚI (Giai đoạn 0) — bản sửa thật: 1 Fact + TOÀN BỘ evidence atom
        # xác nhận nó, không chỉ evidence đầu tiên.
        fact_id = f"fact_{ea}_{eb}_{_type_slug(relation)}"
        facts.append(Fact(id=fact_id, source_id=source_id, source_entity_id=ea,
                           target_entity_id=eb, relation_type=relation, confidence=confidence))
        for atom_id, evidence_raw in agg["evidences"]:
            fact_evidence.append(FactEvidence(fact_id=fact_id, atom_id=atom_id,
                                               evidence_raw=evidence_raw, confidence=1.0))


    if contradicting_atom_ids:
        db.set_contradicts_flag(list(contradicting_atom_ids))

    return list(nodes.values()), edges, facts, fact_evidence


def build_wiki_pages(
    atoms: list[KnowledgeAtom] ,global_index: Optional[GlobalIndex] = None,
    edges: list[KGEdge] = None,          # <--- thêm
    entity_map: list[EntityMention] = None  # <--- thêm (tùy chọn)
    ) -> list[WikiPage]:
    pages = []
    # Tạo mapping từ atom_id -> atom object để lấy label
    atom_by_id = {a.id: a for a in atoms}
    for section_id, section_atoms in group_by_section(atoms).items():
        has_non_heading = any(a.label != ElementLabel.HEADING for a in section_atoms)
        if not has_non_heading:
            print(f"[WIKI] Skipping page for section '{section_id}' (only heading, no content)")
            continue
        # Lấy breadcrumb từ global_index nếu có
        breadcrumb = ""
        if global_index:
            breadcrumb = global_index.heading_path_for(section_id)
            if breadcrumb:
                breadcrumb = f"# {breadcrumb}\n\n"  # hoặc dùng level phù hợp    
        lines = []
        if breadcrumb:
            lines.append(f"- **[{"HEADING"}]** {breadcrumb}  ")
            lines.append(f"  <!-- source_atom: {section_id} -->")
        else:
            lines.append(f"# {section_id}")
            lines.append("")

        for a in section_atoms:
            lines.append(f"- **[{a.label.value}]** {a.normalized or a.raw}  ")
            lines.append(f"  <!-- source_atom: {a.id} -->")


        # --- THÊM PHẦN HIỂN THỊ EDGE ---
        if edges:
            lines.append("")
            lines.append("### Graph Links (edges)")
            # Lọc các edge có source hoặc target thuộc section này
            section_atom_ids = {a.id for a in section_atoms}
            relevant_edges = [
                e for e in edges
                if e.source_id in section_atom_ids or e.target_id in section_atom_ids
            ]
            if relevant_edges:
                for e in relevant_edges:
                    # Lấy label của source và target atom
                    src_atom = atom_by_id.get(e.source_id)
                    tgt_atom = atom_by_id.get(e.target_id)
                    src_label = src_atom.label.value if src_atom else "?"
                    tgt_label = tgt_atom.label.value if tgt_atom else "?"
                    # Hiển thị edge
                    evidence = f" (evidence: {e.evidence_raw})" if e.evidence_raw else ""
                    score_info = f" (score: {e.score:.2f})" if e.score is not None else ""
                    lines.append(
                        f"- `{e.source_id}` **{e.relation}** `{e.target_id}` "
                        f"[{src_label} → {tgt_label}]{evidence}{score_info}"
                    )
            else:
                lines.append("_No graph links for this section_")

        pages.append(WikiPage(section_id=section_id, title=section_id, markdown="\n".join(lines)))
    return pages


def commit_wiki_to_git(pages: list[WikiPage], source_id: str) -> None:
    """Stage C's file-store responsibility, triggered right after B2 builds
    the pages. Silently no-ops if git isn't available (e.g. in a sandbox)."""
    wiki_dir = settings.wiki_git_dir
    os.makedirs(wiki_dir, exist_ok=True)
    if not os.path.isdir(os.path.join(wiki_dir, ".git")):
        subprocess.run(["git", "init"], cwd=wiki_dir, capture_output=True)
        subprocess.run(["git", "config", "user.email", "kb-pipeline@local"], cwd=wiki_dir, capture_output=True)
        subprocess.run(["git", "config", "user.name", "IT KB Pipeline"], cwd=wiki_dir, capture_output=True)
    for page in pages:
        path = os.path.join(wiki_dir, f"{page.section_id}.md")
        with open(path, "w", encoding="utf-8") as f:
            f.write(page.markdown)
    subprocess.run(["git", "add", "."], cwd=wiki_dir, capture_output=True)
    subprocess.run(["git", "commit", "-m", f"update wiki for {source_id}"],
                    cwd=wiki_dir, capture_output=True)


def build_wiki_kg_chunks(atoms: list[KnowledgeAtom], merge_result: MergeResult,
                          func_get_llm: Callable[[], Any], global_index: Optional[GlobalIndex] = None,
                          sections: Optional[set[str]] = None) -> B2Output:
    """Entry point for stage B2.

    `global_index`: passed through to build_chunk_records for the breadcrumb
    contextual-embedding fix (design-doc §7.2).
    `sections`: incremental-update scoping (design-doc §6 step 5) — when
    given, only rebuild chunk_records for these section_ids; `atoms` itself
    should already be scoped to just the new/changed atoms in that case
    (build_kg's MENTIONS/SIMILAR_TO folding still works correctly on a
    partial atom list since it only reads what's actually on those atoms).
    """
    chunk_records = build_chunk_records(atoms, func_get_llm, global_index=global_index, sections=sections)

    # --- Xây dựng KG với đầy đủ atom của các section ---
    if sections and merge_result.source_id:
        # Lấy tất cả atom của các section đang xử lý (bao gồm heading cũ)
        all_atoms_for_kg = db.get_atoms_by_sections(merge_result.source_id, list(sections))
    else:
        all_atoms_for_kg = atoms

    parents = [c for c in chunk_records if c.type == 'parent']
    children = [c for c in chunk_records if c.type == 'child']
    print(f"[CHUNK] Total chunks built: {len(chunk_records)} (parents: {len(parents)}, children: {len(children)})")

    kg_nodes, kg_edges, facts, fact_evidence = build_kg(all_atoms_for_kg, merge_result)
    wiki_pages = build_wiki_pages(atoms,global_index=global_index,edges=kg_edges)
    return B2Output(source_id=merge_result.source_id, chunk_records=chunk_records,
                     kg_nodes=kg_nodes, kg_edges=kg_edges, wiki_pages=wiki_pages,
                     facts=facts, fact_evidence=fact_evidence)
