"""
A1 — Ensemble Parser + Unified Document Object (UDO)

INPUT:  file_path: str, source_id: str
OUTPUT: common.schemas.UnifiedDoc

This module owns exactly the mapping file-extension -> parser, and a scoring
function to pick the best result when more than one parser ran. Heavy parsers
(Docling, MinerU, Textract) are wired as optional plugins: if the package
isn't installed, `route_parser` still returns *some* tool from the list and
`select_best_result` degrades gracefully to whatever is installed.

FIX LOG (vs previous version):
  - `_pdf_is_multi_column` was a hard-coded `return False` stub. Now does
    real x-coordinate clustering over word bboxes.
  - `_parse_pymupdf` used to emit every block as a flat PARAGRAPH — no
    heading was ever produced for PDFs, which silently zeroed out the
    heading_tree in A3 (and short-circuited cross-reference detection,
    which early-returns on an empty outline). It now (a) maps the file's
    native TOC onto matching lines by page + fuzzy text match, and (b)
    falls back to font-size/bold clustering when there's no usable TOC.
  - `_parse_pymupdf` now also extracts real tables via
    `page.find_tables()` instead of never producing ElementType.TABLE at
    all, and skips paragraph text that physically overlaps an extracted
    table's bbox so content isn't duplicated.
  - The `"docling"` tool key used to point unconditionally at the naive
    paragraph-only stub. It now tries the real `docling` package first
    (if installed) and only falls back to the stub on ImportError/failure,
    so installing docling actually changes pipeline behavior with zero
    other code changes.
  - `compute_parse_confidence` only gave a flat 0/0.3 bonus for "has any
    heading at all". It now scores heading *density* and rewards tables,
    so a document with a real outline beats a longer flat text dump.
  - `select_best_result` now has a hard tie-break rule
    (`settings.a1_prefer_heading_bearing_parser`): if at least one
    candidate result produced any heading and at least one produced none,
    only the heading-bearing candidates compete — a flat stub dump must
    never outrank a parser that actually found structure.
"""
from __future__ import annotations

import os
import re
import statistics
from typing import Callable, Optional

from common.config import settings
from common.schemas import UnifiedDoc, DocElement, ElementType, ElementMetadata, BBox, ParseIssue


# -----------------------------------------------------------------------------
# Mã giả #1 — routing
# -----------------------------------------------------------------------------
def route_parser(file_path: str) -> list[str]:
    ext = os.path.splitext(file_path)[1].lower().lstrip(".")
    if ext == "pdf":
        if _pdf_is_scanned(file_path):
            return ["mineru_ocr", "textract"]
        if _pdf_has_toc(file_path) and not _pdf_is_multi_column(file_path):
            return ["pymupdf", "docling"]
        return ["mineru", "docling"]
    if ext == "epub":
        return ["docling", "ebooklib_bs4"]
    if ext in ("docx", "pptx"):
        return ["docling", "python_docx"]
    if ext == "md":
        return ["markdown_it_py", "mistune"]
    if ext in ("html", "htm"):
        return ["docling", "beautifulsoup4"]
    return ["docling"]


def _pdf_has_toc(path: str) -> bool:
    try:
        import fitz  # PyMuPDF
        return len(fitz.open(path).get_toc()) > 0
    except Exception:
        return False


def _pdf_is_multi_column(path: str) -> bool:
    """Real implementation: cluster word x0 coordinates per page. If most
    sampled pages show two well-separated horizontal clusters (a real gutter
    gap, not just ragged paragraph edges), treat the document as multi-column.

    Method per page: take word x0 values, sort them, find the single largest
    gap. If that gap is wide relative to page width AND both sides of the
    gap contain a non-trivial number of words, count it as a "split" page.
    A document is multi-column if a majority of sampled pages split.
    """
    try:
        import fitz
        doc = fitz.open(path)
        n_pages = len(doc)
        if n_pages == 0:
            return False
        sample_pages = range(0, n_pages, max(1, n_pages // 8))  # up to ~8 samples
        split_votes, checked = 0, 0
        for i in sample_pages:
            page = doc[i]
            words = page.get_text("words")  # (x0, y0, x1, y1, text, ...)
            if len(words) < 20:
                continue
            page_width = page.rect.width or 1.0
            xs = sorted(w[0] for w in words)
            best_gap, best_idx = 0.0, -1
            for idx in range(1, len(xs)):
                gap = xs[idx] - xs[idx - 1]
                if gap > best_gap:
                    best_gap, best_idx = gap, idx
            checked += 1
            if best_idx <= 0:
                continue
            left_count, right_count = best_idx, len(xs) - best_idx
            min_side = max(5, int(0.15 * len(xs)))
            if (
                best_gap / page_width >= settings.a1_multi_column_min_gap_ratio
                and left_count >= min_side
                and right_count >= min_side
            ):
                split_votes += 1
        return checked > 0 and split_votes / checked > 0.5
    except Exception:
        return False


def _pdf_is_scanned(path: str) -> bool:
    try:
        import fitz
        doc = fitz.open(path)
        text_len = sum(len(p.get_text()) for p in doc)
        return text_len < 50 * len(doc)  # near-empty text layer -> likely scanned
    except Exception:
        return False


# -----------------------------------------------------------------------------
# PDF heading detection helpers (font-size clustering + TOC mapping)
# -----------------------------------------------------------------------------
def _norm_for_match(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def _pdf_font_stats(doc) -> tuple[float, list[float]]:
    """Return (body_font_size, sorted_distinct_larger_sizes) sampled across
    the whole document, used to tell heading-sized text from body text
    without any embedded style metadata."""
    sizes: list[float] = []
    for page in doc:
        d = page.get_text("dict")
        for block in d.get("blocks", []):
            for line in block.get("lines", []):
                for span in line.get("spans", []):
                    txt = span.get("text", "").strip()
                    if txt:
                        sizes.append(round(span.get("size", 0.0), 1))
    if not sizes:
        return 11.0, []
    body_size = statistics.median(sizes)
    larger = sorted({s for s in sizes if s > body_size * 1.08}, reverse=True)
    return body_size, larger


def _heading_level_for_size(size: float, body_size: float, larger_sizes: list[float]) -> Optional[int]:
    if size <= body_size * 1.08:
        return None
    try:
        rank = larger_sizes.index(round(size, 1))
    except ValueError:
        rank = min(range(len(larger_sizes)), key=lambda i: abs(larger_sizes[i] - size)) if larger_sizes else 0
    return min(rank + 1, 6)


def _build_toc_index(doc) -> dict[int, list[tuple[str, int]]]:
    """page_number(0-based) -> list of (normalized_title, level) from the
    file's embedded outline/TOC, used as the authoritative heading source
    whenever a line's text matches closely enough."""
    idx: dict[int, list[tuple[str, int]]] = {}
    try:
        for level, title, page1 in doc.get_toc():
            idx.setdefault(page1 - 1, []).append((_norm_for_match(title), level))
    except Exception:
        pass
    return idx


def _match_toc_level(line_text: str, page_toc: list[tuple[str, int]]) -> Optional[int]:
    if not page_toc:
        return None
    norm_line = _norm_for_match(line_text)
    if not norm_line:
        return None
    try:
        from rapidfuzz import fuzz
        best_level, best_score = None, 0
        for toc_title, level in page_toc:
            score = fuzz.ratio(norm_line, toc_title)
            if score > best_score:
                best_level, best_score = level, score
        if best_score >= 85:
            return best_level
    except Exception:
        for toc_title, level in page_toc:
            if norm_line == toc_title or norm_line in toc_title or toc_title in norm_line:
                return level
    return None


def _rects_overlap(a: tuple[float, float, float, float], b: tuple[float, float, float, float]) -> bool:
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    return not (ax1 <= bx0 or bx1 <= ax0 or ay1 <= by0 or by1 <= ay0)


# -----------------------------------------------------------------------------
# Per-tool parse functions -> each returns list[DocElement] (best effort)
# -----------------------------------------------------------------------------
def _parse_pymupdf(file_path: str) -> list[DocElement]:
    import fitz
    elements: list[DocElement] = []
    doc = fitz.open(file_path)
    body_size, larger_sizes = _pdf_font_stats(doc)
    toc_index = _build_toc_index(doc)

    for pno, page in enumerate(doc):
        # 1) Real tables first, so we can (a) emit TABLE elements and
        #    (b) exclude their bbox area from the paragraph/heading pass
        #    below, avoiding duplicated content.
        table_rects: list[tuple[float, float, float, float]] = []
        try:
            found = page.find_tables()
            for t in found.tables:
                rows = t.extract()
                if not rows:
                    continue
                text = "\n".join(" | ".join("" if c is None else str(c) for c in row) for row in rows)
                x0, y0, x1, y1 = t.bbox
                table_rects.append((x0, y0, x1, y1))
                elements.append(DocElement(
                    type=ElementType.TABLE,
                    content_display=text, content_raw=text,
                    metadata=ElementMetadata(
                        page=pno + 1,
                        bbox=BBox(page=pno + 1, top=y0, left=x0, bottom=y1, right=x1),
                    ),
                ))
        except Exception:
            pass

        page_toc = toc_index.get(pno, [])
        d = page.get_text("dict")
        for block in d.get("blocks", []):
            for line in block.get("lines", []):
                spans = line.get("spans", [])
                if not spans:
                    continue
                text = "".join(s.get("text", "") for s in spans).strip()
                if not text:
                    continue
                bx0, by0, bx1, by1 = line.get("bbox", (0, 0, 0, 0))
                if any(_rects_overlap((bx0, by0, bx1, by1), tr) for tr in table_rects):
                    continue  # already captured as part of a table

                max_size = max(s.get("size", 0.0) for s in spans)
                is_bold = any("bold" in (s.get("font", "").lower()) for s in spans)

                toc_level = _match_toc_level(text, page_toc)
                font_level = _heading_level_for_size(max_size, body_size, larger_sizes)
                heading_level = toc_level if toc_level is not None else font_level
                # A short bold line with no size boost is still worth treating
                # as a heading candidate (common for DOCX-exported PDFs where
                # headings keep body font size but gain bold + isolation).
                if heading_level is None and is_bold and len(text) <= 90 and len(spans) <= 3:
                    heading_level = 6

                bbox = BBox(page=pno + 1, top=by0, left=bx0, bottom=by1, right=bx1)
                if heading_level is not None:
                    elements.append(DocElement(
                        type=ElementType.HEADING, content_display=text, content_raw=text,
                        metadata=ElementMetadata(page=pno + 1, heading_level=heading_level,
                                                  font_size=max_size, bbox=bbox),
                    ))
                else:
                    elements.append(DocElement(
                        type=ElementType.PARAGRAPH, content_display=text, content_raw=text,
                        metadata=ElementMetadata(page=pno + 1, font_size=max_size, bbox=bbox),
                    ))
    return elements


def _parse_docling(file_path: str) -> list[DocElement]:
    """Real docling integration, used only if the `docling` package is
    installed (it is heavy — torch-based layout models — so it stays an
    optional extra per requirements.txt). Falls back to the plain-text stub
    on any failure so the pipeline keeps running either way.

    docling's layout/table-structure models are themselves pulled from the
    Hugging Face Hub on first use. If HF is rate-limiting downloads, set
    A1_DOCLING_ENABLED=false to skip the attempt entirely (fail fast to the
    pdfplumber/pymupdf-heuristic stub below instead of hanging through
    retries/timeouts on every single document)."""
    if not settings.a1_docling_enabled:
        return _parse_generic_text(file_path)
    try:
        from docling.document_converter import DocumentConverter
    except Exception:
        return _parse_generic_text(file_path)

    try:
        converter = DocumentConverter()
        result = converter.convert(file_path)
        doc = result.document
        elements: list[DocElement] = []
        # docling's DoclingDocument exposes an iterator of items with a
        # `.label` (section_header, paragraph, table, list_item, ...) and
        # `.text` / `.export_to_markdown()` for tables. We degrade gracefully
        # field-by-field since docling's public API differs across versions.
        for item, _level in doc.iterate_items():
            label = str(getattr(item, "label", "")).lower()
            text = (getattr(item, "text", None) or "").strip()
            if not text and hasattr(item, "export_to_markdown"):
                try:
                    text = item.export_to_markdown().strip()
                except Exception:
                    text = ""
            if not text:
                continue
            if "table" in label:
                etype = ElementType.TABLE
            elif "header" in label or "title" in label or "heading" in label:
                etype = ElementType.HEADING
            elif "caption" in label:
                etype = ElementType.IMAGE_CAPTION
            elif "list" in label or "item" in label:
                etype = ElementType.LIST_ITEM
            else:
                etype = ElementType.PARAGRAPH
            meta = ElementMetadata()
            if etype == ElementType.HEADING:
                level = getattr(item, "level", None)
                meta.heading_level = int(level) if level else 1
            elements.append(DocElement(type=etype, content_display=text, content_raw=text, metadata=meta))
        return elements or _parse_generic_text(file_path)
    except Exception:
        return _parse_generic_text(file_path)


def _parse_markdown(file_path: str) -> list[DocElement]:
    from markdown_it import MarkdownIt
    text = open(file_path, "r", encoding="utf-8").read()
    md = MarkdownIt()
    tokens = md.parse(text)
    elements, current_heading_level = [], None
    for tok in tokens:
        if tok.type == "heading_open":
            current_heading_level = int(tok.tag[1])
        elif tok.type == "inline" and current_heading_level is not None:
            elements.append(DocElement(
                type=ElementType.HEADING, content_display=tok.content, content_raw=tok.content,
                metadata=ElementMetadata(heading_level=current_heading_level),
            ))
            current_heading_level = None
        elif tok.type == "inline":
            elements.append(DocElement(
                type=ElementType.PARAGRAPH, content_display=tok.content, content_raw=tok.content,
            ))
    return elements


def _parse_html(file_path: str) -> list[DocElement]:
    from bs4 import BeautifulSoup
    html = open(file_path, "r", encoding="utf-8", errors="ignore").read()
    soup = BeautifulSoup(html, "html5lib")
    elements = []
    for tag in soup.find_all(["h1", "h2", "h3", "h4", "p", "li"]):
        text = tag.get_text(strip=True)
        if not text:
            continue
        if tag.name.startswith("h"):
            elements.append(DocElement(type=ElementType.HEADING, content_display=text,
                                        content_raw=text,
                                        metadata=ElementMetadata(heading_level=int(tag.name[1]))))
        elif tag.name == "li":
            elements.append(DocElement(type=ElementType.LIST_ITEM, content_display=text, content_raw=text))
        else:
            elements.append(DocElement(type=ElementType.PARAGRAPH, content_display=text, content_raw=text))
    return elements


def _parse_docx(file_path: str) -> list[DocElement]:
    import docx
    d = docx.Document(file_path)
    elements = []
    for p in d.paragraphs:
        text = p.text.strip()
        if not text:
            continue
        style = (p.style.name or "").lower()
        if style.startswith("heading"):
            level = int(re.sub(r"\D", "", style) or 1)
            elements.append(DocElement(type=ElementType.HEADING, content_display=text,
                                        content_raw=text, metadata=ElementMetadata(heading_level=level)))
        else:
            elements.append(DocElement(type=ElementType.PARAGRAPH, content_display=text, content_raw=text))
    for table in d.tables:
        rows = [[c.text for c in row.cells] for row in table.rows]
        text = "\n".join(" | ".join(r) for r in rows)
        elements.append(DocElement(type=ElementType.TABLE, content_display=text, content_raw=text))
    return elements


def _parse_generic_text(file_path: str) -> list[DocElement]:
    """Last-resort fallback (used when no real parser applies/succeeds).
    Still tries a cheap heading heuristic (ALL-CAPS short line, numbered
    section line, or a "Chapter N" / "Phần N" style line) instead of
    flattening everything to PARAGRAPH, so downstream A3 outline building
    isn't guaranteed empty even in the degraded path."""
    text = open(file_path, "r", encoding="utf-8", errors="ignore").read()
    elements = []
    for para in text.split("\n\n"):
        para = para.strip()
        if not para:
            continue
        first_line = para.splitlines()[0].strip()
        looks_like_heading = (
            len(para.splitlines()) == 1
            and len(first_line) <= 80
            and (
                (first_line.isupper() and len(first_line.split()) <= 10)
                or bool(re.match(r"^(chapter|section|ph\u1ea7n|ch\u01b0\u01a1ng|m\u1ee5c)\s+\d+", first_line, re.IGNORECASE))
                or bool(re.match(r"^\d+(\.\d+)*[\.\)]?\s+\S", first_line))
            )
        )
        if looks_like_heading:
            elements.append(DocElement(type=ElementType.HEADING, content_display=first_line,
                                        content_raw=first_line, metadata=ElementMetadata(heading_level=1)))
        else:
            elements.append(DocElement(type=ElementType.PARAGRAPH, content_display=para, content_raw=para))
    return elements


_PARSERS: dict[str, Callable[[str], list[DocElement]]] = {
    "pymupdf": _parse_pymupdf,
    "markdown_it_py": _parse_markdown,
    "beautifulsoup4": _parse_html,
    "docling": _parse_docling,          # real docling if installed, else stub fallback
    "python_docx": _parse_docx,
    "mineru": _parse_generic_text,      # requires `mineru` CLI; stub fallback
    "mineru_ocr": _parse_generic_text,
    "textract": _parse_generic_text,
    "ebooklib_bs4": _parse_generic_text,
    "mistune": _parse_markdown,
}


def compute_parse_confidence(elements: list[DocElement]) -> float:
    """Explainable score combining text volume, heading density and table
    presence. Previous version only gave a flat 0/0.3 bonus for "any heading
    at all", which let a single stray heading count the same as a full
    outline, and never rewarded a parser for finding real tables."""
    if not elements:
        return 0.0
    text_len = sum(len(e.content_raw) for e in elements)
    n_headings = sum(1 for e in elements if e.type == ElementType.HEADING)
    n_tables = sum(1 for e in elements if e.type == ElementType.TABLE)
    heading_density = min(1.0, n_headings / max(1, len(elements) / 12))
    volume_score = min(1.0, text_len / 5000)
    table_bonus = min(0.15, n_tables * 0.03)
    return min(1.0, volume_score * 0.55 + heading_density * 0.30 + table_bonus)


def _has_heading(elements: list[DocElement]) -> bool:
    return any(e.type == ElementType.HEADING for e in elements)


# -----------------------------------------------------------------------------
# Mã giả #2 — select best + build UnifiedDoc
# -----------------------------------------------------------------------------
def select_best_result(results: dict[str, list[DocElement]], source_id: str,
                        file_path: str, file_type: str) -> UnifiedDoc:
    scored = {tool: (compute_parse_confidence(els), els) for tool, els in results.items()}

    heading_bearing = {t: els for t, (_s, els) in scored.items() if _has_heading(els)}
    non_heading = {t: els for t, (_s, els) in scored.items() if not _has_heading(els)}

    if settings.a1_prefer_heading_bearing_parser and heading_bearing and non_heading:
        # At least one candidate has real structure and at least one doesn't
        # -> only compete among the heading-bearing candidates. A flat stub
        # dump must never outrank a parser that actually found an outline.
        candidate_pool = {t: scored[t] for t in heading_bearing}
    else:
        candidate_pool = scored

    best_tool, best_score, best_elements = None, -1.0, []
    for tool, (score, els) in candidate_pool.items():
        if score > best_score:
            best_tool, best_score, best_elements = tool, score, els

    issues = []
    if best_score < 0.2:
        issues.append(ParseIssue(level="WARNING", message="Low parse confidence — consider manual check"))
    if not _has_heading(best_elements):
        issues.append(ParseIssue(
            level="WARNING",
            message="No heading detected by any parser — heading_tree/cross-references in A3 will be empty; "
                    "consider manual review or installing a stronger parser (docling/mineru).",
        ))

    # assign a stable section_id per top-level heading run, used by every later stage
    section_id, section_counter = None, 0
    for el in best_elements:
        if el.type == ElementType.HEADING:
            section_counter += 1
            section_id = f"{source_id}_sec{section_counter}"
        el.section_id = section_id or f"{source_id}_sec0"

    return UnifiedDoc(
        source_id=source_id, file_path=file_path, file_type=file_type,
        parser_used=best_tool or "none", parse_confidence=max(best_score, 0.0),
        elements=best_elements, issues=issues, needs_review=best_score < 0.2,
    )


def parse_document(file_path: str, source_id: str) -> UnifiedDoc:
    """Entry point for stage A1. This is the function to expose as
    `POST /parse` if A1 becomes its own microservice."""
    file_type = os.path.splitext(file_path)[1].lstrip(".").lower()
    tools = route_parser(file_path)
    results = {}
    for tool in tools:
        parser_fn = _PARSERS.get(tool, _parse_generic_text)
        try:
            results[tool] = parser_fn(file_path)
        except Exception:
            results[tool] = []
    return select_best_result(results, source_id, file_path, file_type)
