"""
D — Retrieval Engine (Online)

INPUT:  common.schemas.RetrievalQuery (query_text, top_k)
OUTPUT: common.schemas.RetrievalResult
        -> `.candidates` (or `.insufficient_context=True`) is what stage E turns
           into a final answer + citation chain
"""
from __future__ import annotations

import logging
import re
import time
from typing import Literal, Optional
import networkx as nx
from stages.b2_5_community_detection import _edge_weight
import math
from common import db
from common.config import settings
from itertools import cycle
from common.llm_client import LLMClient  , extract_and_parse_json
from common.llm_client import  OpenrouterClient , HuggingFaceClient  ,AlibabaClient
from common.llm_client import CerebrasClient,GroqClient,GeminiClient ,CloudflareClient
from common.schemas import RetrievalQuery, RetrievalResult, RetrievedCandidate, EntityPathHop,ElementLabel

logger = logging.getLogger(__name__)

# Vietnamese function words that are conventionally capitalized (sentence-
# initial, or just common) but are NOT topic/entity terms. Used to avoid
# treating e.g. "Hãy", "Những", "Điều" as if they were things the corpus
# needs to contain. Deliberately conservative — false negatives here just
# mean we skip checking a harmless word, false positives would wrongly
# suppress a real gap warning.
_VN_STOPWORDS = {
    "hãy", "những", "điều", "và", "hoặc", "khi", "nếu", "tuy", "nhiên",
    "đây", "đó", "là", "của", "cho", "với", "về", "các", "một", "này",
    "trong", "trên", "sao", "gì", "nào", "ai", "vì", "nên", "để", "sẽ",
    "đã", "đang", "bị", "được", "có", "không", "vậy", "thì", "mà", "cũng",
    "chính", "như", "theo", "từ", "đến", "khác", "cùng", "còn", "vẫn",
    "liên", "hệ",
}

# Character classes covering Vietnamese uppercase letters, so phrase
# extraction also catches Vietnamese-only proper nouns/tech terms like
# "Điện toán Đám mây", not just ASCII ones like "DevOps"/"IoT".
_VN_UPPER = "AĂÂBCDĐEÊGHIKLMNOÔƠPQRSTUƯVXYÁÀẢÃẠẤẦẨẪẬẮẰẲẴẶÉÈẺẼẸẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌỐỒỔỖỘỚỜỞỠỢÚÙỦŨỤỨỪỬỮỰÝỲỶỸỴ"
_WORD_RE = re.compile(r"[\wÀ-ỹ+#./]+")


def _rerank_blend(query_text: str, candidates: list[RetrievedCandidate], top_k: int,
                   blend: float, blend_by_origin: Optional[dict[str, float]] = None) -> list[RetrievedCandidate]:
    """Like llm_client.rerank(), but BLENDS the fresh cross-encoder score
    into each candidate's EXISTING `relevance_score` instead of overwriting
    it outright.

    Bug this fixes (user-reported): plain rerank() does
    `c.relevance_score = float(cross_encoder_score)` for every candidate —
    a full overwrite. Two call sites in retrieve() were calling plain
    rerank() on candidate pools whose relevance_score already carried a
    DELIBERATE, different signal:
      1. expanded_candidates from _expand_atom_seeds(): same-section atoms
         inherit their matched parent section's score precisely because
         they may not be individually similar to the query text — that's
         WHY they needed section-level inclusion instead of being found
         directly by dense/bm25 in the first place.
      2. The final seed+expanded_top+community_hits merge: expanded_top's
         carefully-blended score (see above) and community_hits' cosine
         score both got wiped and replaced by pure cross-encoder text
         similarity in one more overwrite.
    Both times, re-scoring a candidate by the exact signal that failed to
    surface it in the first place — right after including it for the
    opposite reason — silently pushed it back out of the top-K cut before
    it ever reached the LLM prompt.

    `blend` is the weight on the FRESH cross-encoder score; `(1 - blend)`
    is the weight kept on whatever relevance_score the candidate already
    had going in. blend=1.0 reproduces the old (buggy) full-overwrite
    behavior exactly; blend=0.0 ignores query-text similarity entirely and
    keeps whatever prior signal set the score. Mutates and returns the same
    RetrievedCandidate objects, sorted by the blended score, truncated to
    top_k — same call shape as rerank() so call sites don't need to change
    beyond passing a `blend`.
    """
    if not candidates:
        return []
    prior_scores = {id(c): c.relevance_score for c in candidates}
    reranked = rerank1(query_text, candidates, len(candidates))  # mutates c.relevance_score in place
    for c in reranked:
        prior = prior_scores.get(id(c), c.relevance_score)
        w = blend_by_origin.get(c.origin, blend) if blend_by_origin else blend
        c.relevance_score = w * c.relevance_score + (1.0 - w) * prior
    reranked.sort(key=lambda c: c.relevance_score, reverse=True)
    return reranked[:top_k]

def _is_cap(word: str) -> bool:
    return bool(word) and word[0] in _VN_UPPER


def extract_key_terms(query_text: str) -> list[str]:
    """Pull out likely entity/topic terms from the query (capitalized words
    and capitalized phrases, incl. Vietnamese diacritics + tech acronyms like
    'CI/CD'). Cheap heuristic, not real NER — good enough to answer "does the
    corpus even mention what's being asked about", which is a different and
    stronger question than "is there something vaguely relevant".

    Handles Vietnamese proper-noun phrases where only some words are
    capitalized (e.g. "Điện toán Đám mây": Điện/Đám capitalized, toán/mây
    not) by bridging a short lowercase connector word IF it isn't itself a
    stopword/conjunction — this avoids wrongly fusing two distinct entities
    joined by "và"/"với"/"hoặc" (e.g. "Microservices và IoT" must stay two
    separate terms, not become one unmatched phrase "Microservices IoT").
    """
    terms: list[str] = []
    seen: set[str] = set()
    # Work sentence-by-sentence so a run never bridges across a "." "?" "!" —
    # otherwise a trailing lowercase word of one sentence could fuse with the
    # capitalized first word of the next.
    for sentence in re.split(r"[.?!]", query_text):
        words = _WORD_RE.findall(sentence)
        n = len(words)
        i = 0
        while i < n:
            if not _is_cap(words[i]):
                i += 1
                continue
            j = i
            while j + 1 < n:
                nxt = words[j + 1]
                if _is_cap(nxt):
                    j += 1
                elif (nxt.lower() not in _VN_STOPWORDS and len(nxt) <= 6
                      and (j + 2 >= n or _is_cap(words[j + 2]))):
                    j += 1  # short non-stopword connector bridging two capitalized words
                else:
                    break
            run = [w for w in words[i:j + 1] if w.lower() not in _VN_STOPWORDS]
            if run:
                cleaned = " ".join(run).strip(".,;:!?")
                if len(cleaned) >= 3:
                    key = cleaned.lower()
                    if key not in seen:
                        seen.add(key)
                        terms.append(cleaned)
            i = j + 1
    return terms


def coverage_check(key_terms: list[str], pool: list[RetrievedCandidate],
                    llm: Optional[LLMClient] = None) -> tuple[float, list[str]]:
    """For each key term extracted from the query, check whether it appears
    (case-insensitive substring match) anywhere in the *broad* retrieved
    candidate pool (pre-rerank-cutoff, i.e. dense+bm25+graph fused results).
    Returns (coverage_ratio, uncovered_terms).

    This is intentionally a literal/lexical check, independent of embedding
    similarity: embedding scores can be "relevant-ish" for atoms that never
    actually mention the term being asked about (e.g. a CI/CD atom scoring
    above threshold for a DevOps question, even though "DevOps" itself never
    appears anywhere in the corpus). Catching that gap here — before
    generation — is what lets stage E be told explicitly what NOT to
    fabricate about, instead of discovering it only in the finished prose.
    """
    if not key_terms:
        return 1.0, []
    haystack = " ".join(f"{c.raw} {c.normalized or ''}" for c in pool).lower()
    literal_uncovered = [t for t in key_terms if t.lower() not in haystack]

    if not literal_uncovered or llm is None or not settings.d_coverage_semantic_check_enabled or not pool:
        covered_n = len(key_terms) - len(literal_uncovered)
        return (covered_n / len(key_terms)), literal_uncovered

    # Semantic second pass for the terms that missed literally.
    try:
        term_embeddings = llm.embed(literal_uncovered)
        pool_texts = [f"{c.raw} {c.normalized or ''}".strip() for c in pool]
        pool_embeddings = llm.embed(pool_texts)
    except Exception as e:
        print(f"Semantic coverage check unavailable (embedding call failed): {e}")
        covered_n = len(key_terms) - len(literal_uncovered)
        return (covered_n / len(key_terms)), literal_uncovered

    threshold = settings.d_coverage_semantic_threshold
    still_uncovered = []
    for term, term_emb in zip(literal_uncovered, term_embeddings):
        best_sim = max((_cosine(term_emb, p_emb) for p_emb in pool_embeddings), default=0.0)
        if best_sim < threshold:
            still_uncovered.append(term)
        else:
            print(f"Key term {term} covered semantically (best_sim={best_sim} >= {threshold}), not flagged as uncovered despite no literal match.")

    covered_n = len(key_terms) - len(still_uncovered)
    ratio = covered_n / len(key_terms)
    return ratio, still_uncovered


def resolve_uncovered_terms(pool_uncovered: list[str], source_id: str | None = None,
                             corpus_check_enabled: bool = True) -> tuple[list[str], list[str]]:
    """Split `pool_uncovered` (terms missing from the retrieved pool) into
    (truly_uncovered, retrieval_gap):
      - truly_uncovered: terms that also don't exist anywhere in the corpus —
        these are legitimate "tài liệu không đề cập" cases.
      - retrieval_gap: terms that DO exist in the corpus but simply weren't
        surfaced by dense/bm25/graph for this query — retrieval's fault, not
        a real content gap. These must NOT be forbidden from the answer.

    If `corpus_check_enabled` is False (see settings.d_coverage_check_scope),
    skips the extra DB round-trip and treats every pool-uncovered term as
    truly uncovered — this restores the old, stricter, pool-only behavior
    for anyone who prefers to pay for higher recall confidence instead.
    """
    if not pool_uncovered or not corpus_check_enabled:
        return pool_uncovered, []
    truly_uncovered, retrieval_gap = [], []
    for term in pool_uncovered:
        if db.term_exists_in_corpus(term, source_id=source_id):
            retrieval_gap.append(term)
        else:
            truly_uncovered.append(term)
    if retrieval_gap:
        logger.info("Terms missing from retrieved pool but present in corpus "
                     "(retrieval recall gap, NOT flagged as uncovered): %s", retrieval_gap)
    return truly_uncovered, retrieval_gap


def dense_search(query_text: str, llm: LLMClient, limit: int) -> list[RetrievedCandidate]:
    embedding = llm.embed([query_text])[0]
    chunk_rows = db.dense_search_chunks(embedding, limit)

    print(f"[RETRIEVAL] Dense search found {len(chunk_rows)} parent chunks for query: '{query_text[:50]}...'")
    for row in chunk_rows:
        print(f"  - parent id: {row['id']} ,real id: {row['type']}, score: {row['score']:.4f} ,content: {row['content'][:10]}")
    return _expand_parent_chunk_matches(chunk_rows, source="dense")


def bm25_search(query_text: str, limit: int, source_id: Optional[str] = None) -> list[RetrievedCandidate]:
    chunk_rows = db.bm25_search_chunks(query_text, limit,source_id=source_id)
    print(f"[RETRIEVAL] bm25_search search found {len(chunk_rows)} parent chunks for query: '{query_text[:50]}...'")
    for row in chunk_rows:
        print(f"  - parent id: {row['id']}, score: {row['score']:.4f}")
    return _expand_parent_chunk_matches(chunk_rows, source="bm25")

def bm25_search_atom(query_text: str, limit: int) -> list[RetrievedCandidate]:
    rows = db.bm25_search(query_text, limit)
    print(f"[RETRIEVAL] bm25_search_atom search found {len(rows)} parent chunks for query: '{query_text[:50]}...'")
    for row in rows:
        print(f"  - parent id: {row['id']}, score: {row['score']:.4f}")
    return [
        RetrievedCandidate(atom_id=r["id"], raw=r["raw"], normalized=r["normalized"],type=r["type"],
                            source="bm25", rank=i, relevance_score=float(r["score"]),
                            confidence=float(r["confidence"] or 0), contradicts_flag=r["contradicts_flag"],
                            location=f"{r['source_id']} — Chapter {r['chapter']}, Page {r['page_start']}")
        for i, r in enumerate(rows)
    ]

def dense_search_atom(query_text: str, llm: LLMClient, limit: int, source_id: Optional[str] = None) -> list[RetrievedCandidate]:
    embedding = llm.embed([query_text])[0]
    exclude_heading = settings.d_exclude_heading_from_dense_evidence
    fetch_limit = limit * settings.d_exclude_heading_fetch_multiplier if exclude_heading else limit
    rows = db.dense_search(embedding, fetch_limit, source_id=source_id)

    print(f"[RETRIEVAL] Dense search atom found {len(rows)} parent chunks for query: '{query_text[:50]}...'")
    for row in rows:
        print(f"  - parent id: {row['section_id']}, id: {row['id']}, score: {row['score']:.4f} , label: {row['label']} ,content: {row['raw'][:101]}")

    if exclude_heading:
        before = len(rows)
        rows = [r for r in rows if r.get("label") != ElementLabel.HEADING.value][:limit]
        skipped = before - len(rows)
        if skipped:
            print(f"[RETRIEVAL] Bỏ qua {skipped} atom label=HEADING khỏi dense-search evidence "
                  f"(settings.d_exclude_heading_from_dense_evidence=true)")
    else:
        rows = rows[:limit]

    return [
        RetrievedCandidate(atom_id=r["id"], raw=r["raw"], normalized=r["normalized"],section_id=r.get("section_id"),
                            source="dense", rank=i, relevance_score=float(r["score"] or 0),
                            confidence=float(r["confidence"] or 0), contradicts_flag=r["contradicts_flag"],
                            location=f"{r['source_id']} — Chapter {r['chapter']}, Page {r['page_start']}")
        for i, r in enumerate(rows)
    ]

def _expand_parent_chunk_matches(chunk_rows: list[dict],
                                  source: Literal["dense", "bm25"]) -> list[RetrievedCandidate]:
    """Take PARENT chunk_records search hits (already context-restored — see
    B2.build_chunk_records) and expand each one back down to its exact child
    knowledge_atoms, so the candidate pool still cites precise, verbatim atom
    text instead of the whole section. A parent match's score is inherited by
    every child atom under it; rerank() downstream narrows the pool back down
    to the atoms that actually matter for this specific query.
    """
    results: list[RetrievedCandidate] = []
   
    for row_rank,row in  enumerate(chunk_rows):
        parent_id = row["id"]
        
        # ✅ Luôn thêm parent vào candidates nếu score >= ngưỡng
        if float(row["score"]) >= settings.d_retrieval_PARENT_FALLBACK_THRESHOLD:
                print(f"_expand_parent_chunk_matches {row["score"]} {row["content"][:80]!r}")
                results.append(RetrievedCandidate(
                    atom_id=parent_id,   # parent id (bắt đầu bằng "parent_...")
                    raw=row["content"],  # toàn bộ nội dung parent
                    normalized=row["content"],
                    source=source,
                    rank=row_rank,
                    type=row["type"],
                    relevance_score=float(row["score"]),
                    confidence=0.5,      # fallback confidence
                    contradicts_flag=False,
                    location=f"Section: {parent_id}",
                ))
                

        child_ids = db.chunk_children_atom_ids(parent_id)
        if child_ids:
            atoms = db.atoms_for_ids(child_ids)
            for atom_id in child_ids:
                atom = atoms.get(atom_id)
                if not atom:
                    continue
                results.append(RetrievedCandidate(
                    atom_id=atom["id"],
                    raw=atom["raw"],
                    normalized=atom["normalized"],
                    source=source,
                    rank=row_rank,
                    type=row["type"],
                    relevance_score=float(row["score"]),
                    confidence=float(atom["confidence"] or 0),
                    contradicts_flag=atom["contradicts_flag"],
                    location=f"{atom['source_id']} — Chapter {atom['chapter']}, Page {atom['page_start']}",
                ))
                
            
    return results

def _expand_atom_seeds(seed: list[RetrievedCandidate]) -> tuple[list[str], list[str], dict[str, float], dict[str, RetrievedCandidate]]:
    """
    Mở rộng từ seed (danh sách candidate đã rerank) để lấy toàn bộ child atom trong các section liên quan.
    - Ưu tiên giữ các seed.
    - Giới hạn số lượng child lấy từ mỗi section (d_max_children_per_section).
    - Trả về (expanded_atom_ids, heading_ids).
    """
    from common import db
    from common.config import settings

    # Gom seed theo parent_id
    parent_to_seed_ids = {}
    seed_atom_ids_original = set()
    seed_score_by_parent = {}
    anchor_by_parent: dict[str, RetrievedCandidate] = {}
    
    for cand in seed:
        atom_id = cand.atom_id
        seed_atom_ids_original.add(atom_id)
        # Xác định parent_id
        if atom_id.startswith("parent_"):
            parent_id = atom_id
        else:
            if cand.section_id:
                parent_id = f"parent_{cand.section_id}"
            else:
                # Fallback: query DB
                atom = db.get_knowledge_atom(atom_id)
                if not atom:
                    continue
                parent_id = f"parent_{atom['section_id']}"
        parent_to_seed_ids.setdefault(parent_id, set()).add(atom_id)
        if parent_id not in seed_score_by_parent or cand.relevance_score > seed_score_by_parent[parent_id]:
            seed_score_by_parent[parent_id] = cand.relevance_score
            anchor_by_parent[parent_id] = cand  

    expanded_atom_ids = set()

    print(f"parent_to_seed_ids {parent_to_seed_ids}")
    max_children = settings.d_max_children_per_section


    for parent_id, seed_ids in parent_to_seed_ids.items():
        print(f"parent_id {parent_id}")
        all_child_ids = db.chunk_children_atom_ids(parent_id)
        if not all_child_ids:
            continue
        print(f"all_child_ids {all_child_ids}")
        # Tách seed và non-seed
        seed_child_ids = [cid for cid in all_child_ids if cid in seed_ids]
        non_seed_child_ids = [cid for cid in all_child_ids if cid not in seed_ids]
        # Luôn giữ toàn bộ seed
        selected = set(seed_child_ids)
        # Nếu còn slot, lấy thêm non-seed (theo thứ tự)
        remaining_slots = max_children - len(selected)
        if remaining_slots > 0:
            selected.update(non_seed_child_ids[:remaining_slots])
        expanded_atom_ids.update(selected)

    # Đảm bảo seed ban đầu có mặt (phòng trường hợp seed không có parent)
    expanded_atom_ids.update(seed_atom_ids_original)

    # --- Bổ sung heading ---
    heading_ids = set()
    for aid in expanded_atom_ids:
        atom = db.get_knowledge_atom(aid)
        if atom:
            heading = db.get_heading_atom(atom['source_id'], atom['section_id'])
            if heading:
                heading_ids.add(heading['id'])

    return list(expanded_atom_ids), list(heading_ids), seed_score_by_parent, anchor_by_parent


def graph_search(seed_atom_ids: list[str], max_depth: int = 2, source_id: Optional[str] = None,
                  tier: Optional[str] = None) -> list[RetrievedCandidate]:
    """D.seed-then-expand (design-doc §9.1) — replaces the previous
    implementation, which regex-guessed a capitalized word from the query
    text and looked up `ent_{word.lower()}`. That never matched anything
    even before this design revision (A4/A3 never wrote GLiNER-derived
    `ent_*` nodes with that exact naming), and definitely can't now that
    A4.5 namespaces entity_id as `ent_{slug(name)}_{slug(source_id)}` (see
    stages/a4_5_entity_consolidation.py) — so it always returned [].

    Instead: start from the atom ids that ALREADY matched the query directly
    (dense/bm25 "seed" candidates, chosen by the caller), and walk the
    persisted graph (MENTIONS + SIMILAR_TO + the 4 LLM relations) outward via
    db.graph_traverse_multi. Every result here is explicitly
    origin="graph_expansion" — it did NOT match the query itself, it's here
    because it's connected to something that did. Nodes reached that don't
    correspond to an actual knowledge_atom (i.e. we landed on an entity node,
    not an atom node — MENTIONS' source_id) are skipped: an entity node has
    no raw/normalized text of its own to show as a citable candidate.

    `tier` (MỚI — đề xuất #4, tùy chọn, mặc định None): truyền xuống
    db.graph_traverse_multi để giới hạn traversal chỉ theo cạnh "reasoning"
    hoặc "structural". Hiện tại seed của hàm này luôn là atom id (không
    phải entity id — xem docstring trên), nên trong pipeline này tier chưa
    có ngữ cảnh hữu ích để bật; tham số tồn tại sẵn để dùng khi/nếu graph_search
    được gọi với entity seed trong tương lai, không đổi hành vi mặc định.
    """
    if not seed_atom_ids:
        return []
    results: list[RetrievedCandidate] = []
    seen: set[str] = set()
    for row in db.graph_traverse_multi(seed_atom_ids, max_depth=max_depth, source_id=source_id, tier=tier):
       
        node_id = row["id"]
        if node_id in seen or node_id in seed_atom_ids:
           
            continue
        atom = db.get_knowledge_atom(node_id)
        if not atom:
           
            continue  # landed on an entity node (or a node with no atom row) — nothing citable here
        seen.add(node_id)
        print(f"graph_search section_id:{atom['section_id']}  id: {atom["id"]}")
        results.append(RetrievedCandidate(
            atom_id=atom["id"], raw=atom["raw"], normalized=atom["normalized"],
            source="graph", rank=int(row["depth"]),
            confidence=float(atom["confidence"] or 0), contradicts_flag=atom["contradicts_flag"],
            location=f"{atom['source_id']} — Chapter {atom['chapter']}, Page {atom['page_start']}",
            origin="graph_expansion", relation=row.get("relation"), linked_from=row.get("seed_id"),
        ))
    return results


def soft_score(candidate: RetrievedCandidate, hop_distance: int) -> float:
    """D.9.2 — replaces a hard rerank-threshold cutoff for graph-expanded
    candidates: an atom pulled in via graph_expansion can be the exact right
    supporting detail for the answer even if it scores below the normal
    relevance cutoff on its own text (that's WHY it needed graph expansion to
    surface at all — it doesn't repeat the query's wording). `candidate.
    relevance_score` here is expected to already have been set by a rerank()
    pass (cross-encoder query<->raw score) before this is called; edge type
    and hop distance are then blended in as additional, independent signal.
    """
    edge_confidence = {
        "DEFINES": 1.0, "EXTENDS": 0.9, "CONTRADICTS": 1.0, "RELATED_TO": 0.6,
        "MENTIONS": 0.5, "SIMILAR_TO": candidate.relevance_score,"PARENT_OF": 0.8,   # Quan hệ cha-con, khá quan trọng
    "SAME_SECTION": 0.1  # Rất yếu, không nên ảnh hưởng đến điểm
    }.get(candidate.relation, 0.5)
    hop_distance = max(hop_distance, 1)
    return (candidate.relevance_score
            + settings.d_retrieval_expansion_weight_edge * edge_confidence
            + settings.d_retrieval_expansion_weight_hop * (1.0 / hop_distance))


def soft_score_v2(
    candidate: RetrievedCandidate,
    anchor_atom_text: Optional[str],
    query_text: str,
    hop_distance: int,
    llm: Optional[LLMClient] = None,
    ppr_norm: Optional[float] = None,
    w1: float = 0.4,   # anchor similarity
    w2: float = 0.2,   # query similarity
    w3: float = 0.2,   # edge bonus
    w4: float = 0.1,   # hop penalty
    w5: float = 0.1,   # ppr_norm (nếu có)
) -> float:
    """
    Tính điểm tổng hợp cho expanded candidate.
    """
    # anchor_similarity đã được gán bởi _batch_score_against_anchor
    sim_to_anchor = getattr(candidate, 'anchor_similarity', 0.0)
    if sim_to_anchor == 0.0 and anchor_atom_text:
        # Fallback: nếu chưa có, tính cosine similarity (có thể bỏ qua để tiết kiệm)
        pass

    if sim_to_anchor is None:          # <--- FIX
        sim_to_anchor = 0.0

    sim_to_query = getattr(candidate, 'query_similarity', candidate.relevance_score)
    if sim_to_query is None:           # <--- FIX (phòng trường hợp tương tự)
        sim_to_query = candidate.relevance_score or 0.0

    edge_confidence = {
        "DEFINES": 1.0,
        "EXTENDS": 0.9,
        "CONTRADICTS": 1.0,
        "RELATED_TO": 0.6,
        "MENTIONS": 0.5,
        "SIMILAR_TO": 0.4,
        "PARENT_OF": 0.8,
        "SAME_SECTION": 0.2
    }.get(candidate.relation, 0.5)

    hop_penalty = 1.0 / max(1, hop_distance)
    ppr_term = ppr_norm if ppr_norm is not None else 0.0

    final_score = (w1 * sim_to_anchor +
                   w2 * sim_to_query +
                   w3 * edge_confidence +
                   w4 * hop_penalty +
                   w5 * ppr_term)
    return final_score

def community_search(query_text: str, llm: LLMClient, top_k: int = 2,
                      source_id: Optional[str] = None) -> list[RetrievedCandidate]:
    """B2.5's community summaries as a retrieval source — useful for broad/
    overview-style questions ("what does this document cover about X") that
    no single atom answers on its own. Returns candidates with
    type/atom_id = the community chunk_record id (`community_{source_id}_{i}`);
    stage E treats these like any other citable candidate."""
    try:
        embedding = llm.embed([query_text])[0]
    except Exception:
        return []
    rows = db.dense_search_communities(embedding, limit=top_k, source_id=source_id)
    return [
        RetrievedCandidate(
            atom_id=r["id"], raw=r["content"], normalized=r["content"], type="community",
            source="community", rank=i, relevance_score=float(r["score"]),
            confidence=0.6, contradicts_flag=False, location=f"Community summary: {r['id']}",
            origin="direct_match",
        )
        for i, r in enumerate(rows)
    ]


# Mã giả #15 — Reciprocal Rank Fusion
def reciprocal_rank_fusion(result_lists: list[list[RetrievedCandidate]], k: int = 60,
                            top_n: int = 40,
                            weights: Optional[list[float]] = None) -> list[RetrievedCandidate]:
    """Phase 3 fix (analysis doc #7): `weights` lets callers weight some
    result lists (e.g. dense) higher than others (e.g. bm25) instead of the
    old implicit 1.0/1.0 fusion — bm25 is still a keyword-literal channel
    even after the Phase 0 language fix, so callers that want to lean
    towards semantic matching can pass e.g. weights=[0.7, 0.3] for
    [dense_results, bm25_results]. Defaults to equal weighting (1.0 each)
    when `weights` is omitted, so existing callers are unaffected.
    """
    # Nếu chỉ có một danh sách, giữ nguyên điểm và cắt top_n
    if len(result_lists) == 1:
        return result_lists[0][:top_n]

    if weights is None:
        weights = [1.0] * len(result_lists)
    scores: dict[str, float] = {}
    by_id: dict[str, RetrievedCandidate] = {}
    for result_list, weight in zip(result_lists, weights):
        for rank, cand in enumerate(result_list):
            scores[cand.atom_id] = scores.get(cand.atom_id, 0.0) + weight / (k + rank + 1)
            by_id[cand.atom_id] = cand
    ranked_ids = sorted(scores, key=lambda i: scores[i], reverse=True)[:top_n]
    return [by_id[i] for i in ranked_ids]


def rerank1(query_text: str, candidates: list[RetrievedCandidate], top_k: int) -> list[RetrievedCandidate]:
    """D.5 — cross-encoder reranker. Uses a local `sentence-transformers`
    CrossEncoder if installed (free), else keeps RRF order as fallback."""
    if not candidates:
        return []
    try:
        from sentence_transformers import CrossEncoder
        model = CrossEncoder("BAAI/bge-reranker-v2-m3",max_length=1024)
        pairs = [(query_text, c.raw) for c in candidates]
        scores = model.predict(pairs)
        for c, s in zip(candidates, scores):
            c.relevance_score = float(1.0 / (1.0 + math.exp(-float(s))))
        candidates = sorted(candidates, key=lambda c: c.relevance_score, reverse=True)
    except Exception as e:
        # Fall back to RRF fusion order, but make this visible — silently
        # degrading retrieval quality is exactly the kind of thing that lets
        # weakly-related atoms slip past self_verify() unnoticed.
        logger.warning("Cross-encoder rerank unavailable, falling back to RRF order: %s", e)
    return candidates[:top_k]


# Mã giả #16 — self-verification
def self_verify(candidates: list[RetrievedCandidate], coverage_ratio: float,
                 uncovered_terms: list[str] , suggestions: list[RetrievedCandidate] ,
                 edges: list[dict] = None,
                 chain_coverage: Optional[float] = None) -> RetrievalResult:
    query_placeholder = ""  # filled by caller
    avg_confidence = (sum(c.confidence for c in candidates) / len(candidates)) if candidates else 0.0
    total_relevant = sum(1 for c in candidates if c.relevance_score > settings.d_relevance_threshold)

    # Hard gate: none of the query's key terms appear anywhere in the
    # retrieved pool at all → there's nothing in the corpus to ground an
    # answer on, regardless of how "relevant-ish" embeddings scored some
    # atoms. This is precisely the failure mode where a topically-adjacent
    # atom (e.g. CI/CD) gets used to answer a question about a term that was
    # never in the corpus at all (e.g. DevOps/Cloud/IoT).
    # Was a hard-coded `coverage_ratio == 0.0` check, which silently ignored
    # `settings.d_coverage_min_ratio` (dead config — see stages/d_retrieval.py
    # module docstring). Now actually configurable: raise
    # D_COVERAGE_MIN_RATIO towards 1.0 for stricter gating, lower it (e.g.
    # 0.0) to only ever gate on total absence.
    insufficient_coverage = bool(uncovered_terms) and coverage_ratio < settings.d_coverage_min_ratio

    # Đề xuất #9 — gate NHỊ PHÂN riêng cho chain_coverage, cùng nhóm với
    # insufficient_coverage nhưng KHÔNG gộp chung công thức: một câu hỏi
    # multi-hop có thể "đủ term" (coverage_ratio cao, vì mỗi từ khóa đến từ
    # dense search riêng lẻ) nhưng chain nối các entity lại đứt ở giữa —
    # insufficient_coverage không biết gì về việc này, nên cần điều kiện
    # riêng. Chỉ áp dụng khi entity_path_search thực sự dựng được path
    # tuyến tính giữa >=1 cặp seed entity (chain_coverage is not None) —
    # single-hop/không path thì bỏ qua, không coi là "đứt".
    chain_broken = chain_coverage is not None and chain_coverage < settings.d_chain_coverage_min_ratio

    print(f"[SELF_VERIFY] candidates={len(candidates)}, avg_confidence={avg_confidence:.3f}, total_relevant={total_relevant}, insufficient_coverage={insufficient_coverage}, chain_coverage={chain_coverage}, chain_broken={chain_broken}")
    print(f"[SELF_VERIFY] thresholds: d_relevance_threshold={settings.d_relevance_threshold}, d_min_confidence={settings.d_min_confidence}, d_coverage_min_ratio={settings.d_coverage_min_ratio}, d_chain_coverage_min_ratio={settings.d_chain_coverage_min_ratio}")


    if total_relevant == 0 or avg_confidence < settings.d_min_confidence or insufficient_coverage or chain_broken:
        return RetrievalResult(
            query_text=query_placeholder, candidates=[], insufficient_context=True,
            coverage_ratio=coverage_ratio, uncovered_terms=uncovered_terms,suggestions=suggestions,
            chain_coverage=chain_coverage,
        )
    return RetrievalResult(
        query_text=query_placeholder, candidates=candidates, insufficient_context=False,
        coverage_ratio=coverage_ratio, uncovered_terms=uncovered_terms,suggestions=suggestions,candidate_edges=edges or [],
        chain_coverage=chain_coverage,
    )


def retrieve(query: RetrievalQuery, llm: LLMClient) -> RetrievalResult:

   
   
    llm_strong7 = CerebrasClient()
    llm_strong7.set_key("csk-mkrwvckrernvexvwvh82ww52xte33ct3fp9c4mfcncpej3p8")
    llm_strong8 = CerebrasClient()
    llm_strong8.set_key("csk-xhm85jhw66vm2kmexjrfte38yx9dwwjhemh52mdd539pvc39")
    llm_strong9 = CerebrasClient()
    llm_strong9.set_key("csk-cyh6cfpyy3hrh3hnrvw6jt3mn6n54dnxtwwxjtr8n3yxr8vf")
    llm_strong10 = CerebrasClient()
    llm_strong10.set_key("csk-v4rrvww5856yn9devd4t2ep6dj4dwrtw3djj9hmph54fx3jv")
    llm_strong11 = CerebrasClient()
    llm_strong11.set_key("csk-p5cwcy98y4m4d94jk8fej8m6wrw3ymrm5mteetpmrr536n8x")
    llm_strongc12 = CerebrasClient()
    llm_strongc12.set_key("csk-9nvhrmj9nk3m2newkk6emvd5cev6mrexfdfdprfnhnc6mdth")

    llm_hf_1 = HuggingFaceClient()
    llm_hf_1.set_key("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")
    llm_hf_2 = HuggingFaceClient()
    llm_hf_2.set_key("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")
    llm_hf_3 = HuggingFaceClient()
    llm_hf_3.set_key("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")
    llm_hf_4 = HuggingFaceClient()
    llm_hf_4.set_key("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")
    llm_hf_5 = HuggingFaceClient()
    llm_hf_5.set_key("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")
    llm_hf_6 = HuggingFaceClient()
    llm_hf_6.set_key("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")
    llm_hf_7 = HuggingFaceClient()
    llm_hf_7.set_key("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")
    llm_hf_8 = HuggingFaceClient()
    llm_hf_8.set_key("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")
    llm_hf_9 = HuggingFaceClient()
    llm_hf_9.set_key("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")

    llm_ali_1 = AlibabaClient()
    llm_ali_1.set_key(
        key="sk-ws-H.DMHEMLL.6kr0.MEUCIQCP5saDdKDFVh4KbaaHL8lCiBgwI-8Xhn2GyhBqyRHNnwIgRQDsj73ccVAcP0WKx1w9m-OMI7PM0X60O5wCAEIuGlI",
    workspace_id= "ws-kpde21wer5ix2ad6")

    llm_ali_2 = AlibabaClient()
    llm_ali_2.set_key(
        key="sk-ws-H.DMHELLI.7Xhy.MEUCIQDAjJ3BMI1pkPogy1nDZB4g8D0P9gZmzEjy6kpfWd79fwIgfFtoZvXIF-QNm6FRjKsgOqJnXKEhGFdT-xp_WcJ_6_I",
    workspace_id= "ws-dqg0mm1esvvjw43l")

    llm_cf_1 = CloudflareClient()
    llm_cf_1.set_key(key="cfut_SNmu13EO4A3ivczBpkA2mNwA3S6wcyNINhYlkIBr4837a3b6",
    account_id="be9f4d8e6e32b5db14e7f41424c51cae")

    llm_cf_2 = CloudflareClient()
    llm_cf_2.set_key(key="cfut_AdnOFbxO3IaV6J4iMfB5llvcDODmXEmSaQBBOSi8b05e580e",
    account_id="f1bddd973672ce5f77f624e65e555ac4")

    llm_cf_3 = CloudflareClient()
    llm_cf_3.set_key(key="cfut_MXhkWzTqegIgh8Gyn8QzOxc2RJd4027nbxTal6Ed4cecaedb",
    account_id="743b8d8cf8f37b53eb2c8912f385424f")

    llm_Openrouter_1 = OpenrouterClient()
    llm_Openrouter_1.set_key("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")
    llm_Openrouter_2 = OpenrouterClient()
    llm_Openrouter_2.set_key("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")
    llm_Openrouter_3 = OpenrouterClient()
    llm_Openrouter_3.set_key("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")

    object_list = [llm_ali_1,llm_ali_2,llm_cf_1,llm_cf_2,llm_cf_3,llm_Openrouter_1,llm_Openrouter_2,llm_Openrouter_3]
    pool = cycle(object_list)

    def get_objectllm():
        return next(pool)

    object_list2 = [llm_strong7,llm_strong8,llm_strong9,llm_strong10]
    pool2 = cycle(object_list2)

    def get_objectllm_weak():
        return next(pool2)

    # dense = dense_search(query.query_text, llm, query.top_k_per_source)
    dense_atom = dense_search_atom(query.query_text, get_objectllm(), settings.d_max_total_candidates_for_answer, source_id=query.source_id)
    bm25 = False
    # bm25 = bm25_search(query.query_text, query.top_k_per_source, source_id=query.source_id)
    # bm25_atom = bm25_search_atom(query.query_text, query.top_k_per_source)

    dense_lists = [dense_atom]
    hyde_text =""
    if settings.d_hyde_enabled:
        hyde_text = generate_hyde_passage(query.query_text, get_objectllm())
        if hyde_text:
            hyde_atom = dense_search_atom(hyde_text, get_objectllm(), settings.d_max_total_candidates_for_answer)
            dense_lists.append(hyde_atom)
    
    print(f"hyde_text {hyde_text}")

    dense_combined = reciprocal_rank_fusion(dense_lists, top_n=settings.d_rrf_top_n) \
        if len(dense_lists) > 1 else dense_atom
  
    # Kết hợp dense và bm25 chỉ khi có cả hai
    if bm25:
        fused_seed = reciprocal_rank_fusion(
        [dense_combined, bm25],
        top_n=settings.d_rrf_top_n,
        weights=[settings.d_rrf_weight_dense, settings.d_rrf_weight_bm25],
    )
    else:
        fused_seed = dense_combined  # giữ nguyên điểm

    seed = fused_seed

    # seed = _rerank_blend(query.query_text, fused_seed,
    #                                 settings.d_max_total_candidates_for_answer,
    #                                 blend=settings.d_fisrt_rerank_blend_weight,
    #                                 blend_by_origin={
    #         "direct_match": settings.d_fisrt_rerank_blend_weight,
    #         "section_expansion": settings.d_final_rerank_blend_weight_expansion,
    #         "graph_expansion": settings.d_final_rerank_blend_weight_expansion,
    #     })

    for c in seed:
        c.query_similarity = c.relevance_score  # preserved before anything downstream overwrites relevance_score
    
    for c in seed:
        print(f"seed 1  [{c.source}] section_id {c.section_id}   score={c.relevance_score:.3f}  {c.raw[:80]!r}  {c.type} relation :{c.relation}")

    key_terms = extract_key_terms(query.query_text)

    extra_terms = []
    if settings.d_entity_fallback_bm25_enabled or settings.d_entity_path_enabled:
        extra_terms = extract_key_terms_llm(query.query_text, get_objectllm_weak())

    all_terms = list(dict.fromkeys(key_terms + extra_terms))

    print("---------------------------")
    print(f"all_terms {all_terms} ")

    # Đề xuất #11 — traversal_seed_ids TÁCH KHỎI seed. `seed` ở trên (ngưỡng
    # chặt, cắt ở d_max_total_candidates_for_answer sau rerank) tiếp tục giữ
    # NGUYÊN vai trò evidence cuối (final_candidates bên dưới chỉ đọc từ
    # `seed`, không đổi) — nhưng dùng CHÍNH `seed` đó làm input duy nhất cho
    # _expand_atom_seeds()/graph_search_ppr() ép seed cho traversal phải
    # "thực sự giống câu hỏi" như evidence, trong khi traversal chỉ cần "có
    # khả năng là điểm vào đúng hướng" — ngưỡng nên lỏng hơn.
    #
    # traversal_seed_candidates = seed + atom chỉ được xác nhận qua ENTITY
    # trùng khớp với câu hỏi (dù similarity dense thấp/không lọt seed) —
    # tái dùng cascade link_entities_from_terms/db.lookup_entity_ids đã có
    # (đề xuất #7), không thêm cách linking entity mới. Cap TUYỆT ĐỐI
    # (d_traversal_seed_max_extra_atoms), không chỉ ngưỡng điểm, để
    # personalization vector của PPR phía sau không phình to làm nhiễu
    # traversal — đánh đổi recall (bắt được entity cầu nối) / độ sạch.
    traversal_seed_candidates = list(seed)
    if settings.d_traversal_seed_enabled:
        traversal_anchor_entities = link_entities_from_terms(
            all_terms, query.query_text, query.source_id, get_objectllm(),
            min_ids=1, log_prefix="retrieve_traversal_seed",
        )
        entity_linked_atom_ids = db.get_atom_ids_mentioning_entities(
            traversal_anchor_entities, source_id=query.source_id,
            limit_per_entity=settings.d_traversal_seed_max_atoms_per_entity,
        ) if traversal_anchor_entities else []

        seed_ids_set = {c.atom_id for c in seed}
        extra_added = 0
        for aid in entity_linked_atom_ids:
            if aid in seed_ids_set:
                continue
            if extra_added >= settings.d_traversal_seed_max_extra_atoms:
                print(f"[TRAVERSAL-SEED] Đã đạt cap tuyệt đối "
                      f"({settings.d_traversal_seed_max_extra_atoms}), bỏ qua "
                      f"{len(entity_linked_atom_ids) - extra_added} atom entity-matched còn lại")
                break
            atom = db.get_knowledge_atom(aid)
            if not atom:
                continue
            traversal_seed_candidates.append(RetrievedCandidate(
                atom_id=aid, raw=atom['raw'], normalized=atom.get('normalized'),
                section_id=atom.get('section_id'), source="graph", rank=0,
                relevance_score=settings.d_traversal_seed_entity_match_score,
                confidence=float(atom['confidence'] or 0), contradicts_flag=atom['contradicts_flag'],
                location=f"{atom['source_id']} — Chapter {atom['chapter']}, Page {atom['page_start']}",
                origin="graph_expansion", relation="ENTITY_MATCH",
            ))
            seed_ids_set.add(aid)
            extra_added += 1
        if extra_added:
            print(f"[TRAVERSAL-SEED] +{extra_added} atom entity-matched (ngưỡng lỏng) "
                  f"vào traversal_seed_ids, không dùng làm evidence câu trả lời")

    expanded_atom_ids, heading_ids, seed_score_by_parent, anchor_by_parent = _expand_atom_seeds(
        traversal_seed_candidates)
    expanded_seed_ids = list(set(expanded_atom_ids) | set(heading_ids))

    raw_cache: dict[str, str] = {c.atom_id: c.raw for c in seed}

    expanded_candidates = []
    for aid in expanded_atom_ids:
        atom = db.get_knowledge_atom(aid)
        if not atom:
            continue
        parent_id = f"parent_{atom['section_id']}"
        score = seed_score_by_parent.get(parent_id, 0.5)
        anchor_cand = anchor_by_parent.get(parent_id)
        expanded_candidates.append(RetrievedCandidate(
            atom_id=aid,
            raw=atom['raw'],
            section_id=atom.get("section_id"),
            normalized=atom['normalized'],
            source="dense",
            rank=0,
            relevance_score=score,
            confidence=float(atom['confidence'] or 0),
            contradicts_flag=atom['contradicts_flag'],
            location=f"{atom['source_id']} — Chapter {atom['chapter']}, Page {atom['page_start']}",
            origin="section_expansion",
            relation="SAME_SECTION",
            linked_from=anchor_cand.atom_id if anchor_cand else None,
        ))
        raw_cache[aid] = atom['raw']

    # anchor_map = {cand.atom_id: cand.raw for cand in anchor_by_parent.values()}

    # 3. Rerank expanded_candidates so với query để lấy top K liên quan nhất
    if expanded_candidates:
        
        _batch_score_query_similarity(query.query_text, expanded_candidates)
        
        anchor_map = {}
        for parent_id, anchor_cand in anchor_by_parent.items():
            anchor_id = anchor_cand.atom_id
            if anchor_id not in raw_cache:
                anchor_atom = db.get_knowledge_atom(anchor_id)
                if anchor_atom:
                    raw_cache[anchor_id] = anchor_atom['raw']
            anchor_map[anchor_id] = raw_cache.get(anchor_id, "")

        _batch_score_against_anchor(expanded_candidates, anchor_map)

        for c in expanded_candidates:
            c.relevance_score = soft_score_v2(
                candidate=c,
                anchor_atom_text=anchor_map.get(c.linked_from),
                query_text=query.query_text,
                hop_distance=1,
                llm=get_objectllm(),
                ppr_norm=None,
            )
        expanded_sorted = sorted(expanded_candidates, key=lambda c: c.relevance_score, reverse=True)
        top_expanded = expanded_sorted[:settings.d_max_expanded_candidates_for_answer]
        suggestions = expanded_sorted[settings.d_max_expanded_candidates_for_answer:]
    else:
        top_expanded = []
        suggestions = []


    # 4. Hợp nhất seed (nếu là child) và top_expanded để tạo final candidates cho answer
    final_candidates = []
    # Giữ các seed ban đầu nếu chúng là child (không phải parent)
    for c in seed:
        if not c.atom_id.startswith("parent_"):
            final_candidates.append(c)
    # Thêm top_expanded (loại trùng)
    existing_ids = {c.atom_id for c in final_candidates}
    for c in top_expanded:
        if c.atom_id not in existing_ids:
            final_candidates.append(c)
            existing_ids.add(c.atom_id)

    # 5. Cập nhật seed = final_candidates (để dùng cho các bước tiếp theo)
    seed = final_candidates
    

    expanded = graph_search_ppr(
                expanded_seed_ids,
                query_text=query.query_text,
                source_id=query.source_id,
                llm=get_objectllm(),
                top_k=settings.d_retrieval_expansion_max_per_seed * max(len(seed), 1),
            )

    if expanded:
        # expanded = rerank1(query.query_text, expanded, len(expanded))
        _batch_score_query_similarity(query.query_text, expanded)

        # 2. Xây dựng anchor_map từ linked_from
        anchor_map = {}
        for c in expanded:
            anchor_id = c.linked_from
            if anchor_id and anchor_id not in anchor_map:
                if anchor_id not in raw_cache:
                    anchor_atom = db.get_knowledge_atom(anchor_id)
                    if anchor_atom:
                        raw_cache[anchor_id] = anchor_atom['raw']
                anchor_map[anchor_id] = raw_cache.get(anchor_id, "")

        # 3. Batch anchor similarity
        _batch_score_against_anchor(expanded, anchor_map)

        ppr_vals = [c.ppr_score for c in expanded if c.ppr_score is not None]
        if ppr_vals:
            lo, hi = min(ppr_vals), max(ppr_vals)
            spread = (hi - lo) or 1.0
            for c in expanded:
                if c.ppr_score is not None:
                    ppr_norm = (c.ppr_score - lo) / spread
                    beta = settings.d_ppr_blend_weight
                    c.relevance_score = beta * ppr_norm + (1 - beta) * c.relevance_score
                    c.ppr_norm = ppr_norm

        

        # 3. Tính soft score (kết hợp PPR, query_sim, anchor_sim, edge, hop)
        for c in expanded:
            hop_distance = max(getattr(c, 'rank', 1), 1)
            c.source = "graph"
            c.relevance_score = soft_score_v2(
                candidate=c,
                anchor_atom_text=anchor_map.get(c.linked_from),
                query_text=query.query_text,
                hop_distance=hop_distance,
                llm=get_objectllm(),
                ppr_norm=getattr(c, 'ppr_norm', 0.0),
                w1=0.3,   # giảm trọng số anchor để nhường chỗ cho PPR
                w2=0.15,
                w3=0.15,
                w4=0.1,
                w5=0.3,   # PPR chiếm 30%
            )

        expanded_top = sorted(expanded, key=lambda c: c.relevance_score, reverse=True)
        expanded_top = expanded_top[:settings.d_retrieval_expansion_max_per_seed * max(len(seed), 1)]

    else:
        expanded_top = []

    
    for c in expanded:
        ppr_str = f"{c.ppr_score:.3f}" if c.ppr_score is not None else "None"
        print(f"expanded  [{c.source}] relevance_score={c.relevance_score:.3f} ppr_score={ppr_str} atom_id: {c.atom_id} {c.raw[:80]!r}  section_id :{c.section_id}")

    community_hits = community_search(query.query_text, get_objectllm(), top_k=settings.d_retrieval_community_top_k,
                                       source_id=query.source_id)

    fallback_entity_ids = []
    top_seed_atoms = [c for c in seed if c.relevance_score >= settings.d_entity_fallback_min_score]
    for c in seed:
        print(f"seed 2  [{c.source}] section_id {c.section_id}   score={c.relevance_score:.3f}  {c.raw[:80]!r}  {c.type} relation :{c.relation}")

    for c in top_seed_atoms:
        print(f"top_seed_atoms  [{c.source}] section_id {c.section_id}   score={c.relevance_score:.3f}  {c.raw[:80]!r}  {c.type} relation :{c.relation}")

    top_seed_atoms = sorted(top_seed_atoms, key=lambda c: c.relevance_score, reverse=True)[:settings.d_entity_fallback_sample_limit]
    if top_seed_atoms:
        entity_score = {}
        entity_max_score: dict[str, float] = {}
        entity_extra_count: dict[str, int] = {}
        for c in top_seed_atoms:
            atom = db.get_knowledge_atom(c.atom_id)
            if not atom:
                continue
            entities = atom.get("entities") or []
            for ent in entities:
                eid = ent.get("entity_id")
                if not eid:
                    continue
                if eid in entity_max_score:
                    entity_extra_count[eid] = entity_extra_count.get(eid, 0) + 1
                    entity_max_score[eid] = max(entity_max_score[eid], c.relevance_score)
                else:
                    entity_max_score[eid] = c.relevance_score
                    entity_extra_count[eid] = 0

        entity_score = {
            eid: entity_max_score[eid] + settings.d_entity_fallback_freq_bonus * entity_extra_count[eid]
            for eid in entity_max_score
        }

        # Chọn ra top M entity có điểm cao nhất
        sorted_entities = sorted(entity_score.items(), key=lambda x: x[1], reverse=True)
        print(f"sorted_entities {sorted_entities}")
        fallback_entity_ids = [eid for eid, _ in sorted_entities[:settings.d_entity_fallback_max_entities]]

    if query.source_id and fallback_entity_ids:
        entity_map = db.load_entity_map(query.source_id)
        entity_by_id = {e.entity_id: e for e in entity_map}
        filtered = []
        for eid in fallback_entity_ids:
            entity = entity_by_id.get(eid)
            if entity and entity.section_count <= settings.a4_5_entity_common_cutoff:
                filtered.append(eid)
            elif not entity:
                # Nếu không có trong entity_map (lạ), vẫn giữ lại nhưng cảnh báo
                filtered.append(eid)
        fallback_entity_ids = filtered

    print(f"[RETRIEVE] Trích xuất {len(fallback_entity_ids)} entity từ seed atoms để làm fallback cho entity-path")

    # Đề xuất người dùng — BM25 hỗ trợ entity fallback cho entity_path_search.
    # Nhánh fallback ở trên CHỈ lấy entity từ atom đã lọt `seed` (dense-only,
    # xem bm25=False phía đầu retrieve() — bm25_search/bm25_search_atom hiện
    # bị comment-out khỏi seed chính). Một entity có thể xuất hiện NGUYÊN
    # VĂN trong 1 atom (đúng keyword) nhưng atom đó vẫn không lọt `seed` vì
    # dense similarity bị "loãng" (atom dài, embedding trung bình hoá không
    # còn sát query dù chứa đúng từ khoá) — BM25 (full-text, miễn nhiễm hiện
    # tượng này) là kênh ĐỘC LẬP để bắt lại các entity đó, bổ sung
    # (union, không thay thế) cho fallback_entity_ids trước khi gọi
    # entity_path_search(). Không đụng tới `seed`/evidence chính — chỉ ảnh
    # hưởng seed_entity_ids của entity-path.
    if settings.d_entity_fallback_bm25_enabled and query.source_id:
        bm25_key_terms = all_terms
        bm25_entity_score: dict[str, float] = {}
        seen_bm25_atom_ids: set[str] = set()
        for term in bm25_key_terms:
            try:
                bm25_rows = db.bm25_search(term, limit=settings.d_entity_fallback_bm25_limit_per_term,
                                            source_id=query.source_id)
            except Exception as e:
                print(f"[RETRIEVE] bm25 entity-fallback lỗi cho term {term!r}, bỏ qua term này: {e}")
                continue
            for r in bm25_rows:
                aid = r["id"]
                if aid in seen_bm25_atom_ids:
                    continue
                seen_bm25_atom_ids.add(aid)
                atom = db.get_knowledge_atom(aid)
                if not atom:
                    continue
                for ent in (atom.get("entities") or []):
                    eid = ent.get("entity_id")
                    if eid:
                        bm25_entity_score[eid] = bm25_entity_score.get(eid, 0.0) + float(r["score"] or 0)

        if bm25_entity_score:
            sorted_bm25_entities = sorted(bm25_entity_score.items(), key=lambda x: x[1], reverse=True)
            entity_map = db.load_entity_map(query.source_id)
            entity_by_id = {e.entity_id: e for e in entity_map}
            added = 0
            for eid, _ in sorted_bm25_entities:
                if added >= settings.d_entity_fallback_bm25_max_extra_entities:
                    break
                if eid in fallback_entity_ids:
                    continue  # đã có từ nhánh dense, không cần thêm lại
                entity = entity_by_id.get(eid)
                if entity and entity.section_count > settings.a4_5_entity_common_cutoff:
                    continue  # entity quá phổ biến (xem cùng bộ lọc ở nhánh dense trên)
                fallback_entity_ids.append(eid)
                added += 1
            if added:
                print(f"[RETRIEVE] +{added} entity từ BM25 keyword search (bổ sung cho fallback dense) "
                      f"-> tổng fallback_entity_ids={len(fallback_entity_ids)}")


    # Giai đoạn 2 — kênh entity-path, chạy SONG SONG rồi hợp nhất bằng RRF.
    entity_path_hits, entity_paths, entity_path_chain_coverage = entity_path_search(
        query.query_text, get_objectllm(), source_id=query.source_id,
        fallback_entity_ids=fallback_entity_ids )
    # if entity_path_hits:
    #     community_hits = reciprocal_rank_fusion(
    #         [community_hits, entity_path_hits], top_n=settings.d_retrieval_community_top_k + len(entity_path_hits),
    #     ) if community_hits else entity_path_hits

    for c in entity_path_hits:
        print(f"entity_path_hits  [{c.source}] relevance_score={c.relevance_score:.3f} atom_id: {c.atom_id} {c.raw[:180]!r}  section_id :{c.section_id}")


    seed = sorted(seed, key=lambda c: c.relevance_score, reverse=True)

        # Định nghĩa tỷ lệ đóng góp (có thể đọc từ settings)
    min_ratios = {
        "seed": settings.d_merge_min_ratio_seed,
        "expanded": settings.d_merge_min_ratio_expanded,
        "community": settings.d_merge_min_ratio_community,
        "entity_path": settings.d_merge_min_ratio_entity_path,
    }

    all_candidates = merge_candidates_with_priority(
                    seed=seed,
                    expanded_top=expanded_top,
                    community_hits=community_hits,
                    entity_path_hits=entity_path_hits,
                    target_total=settings.d_max_total_candidates_for_answer,
                    max_ratios=min_ratios
                )

    source_counts = {"seed": 0, "expanded-graph": 0,"expanded": 0, "community": 0, "entity_path": 0}
    for c in all_candidates:
        if c.origin == "direct_match":
            source_counts["seed"] += 1

        if c.origin == "section_expansion" and c.source == "dense":
            source_counts["expanded"] += 1

        if c.source == "graph":
            source_counts["expanded-graph"] += 1

        if c.source == "community":
            source_counts["community"] += 1

        if c.source == "entity_path_hit":
            source_counts["entity_path"] += 1
            print(f"entity_path_hits  [{c.source}] relevance_score={c.relevance_score:.3f} atom_id: {c.atom_id} {c.raw[:180]!r}  section_id :{c.section_id}")

    print(f"[RETRIEVE] Số candidate từ mỗi nguồn: {source_counts}")

    all_candidates = sorted(all_candidates, key=lambda c: c.relevance_score, reverse=True)

  
    with open("output.txt", "w", encoding="utf-8") as file:
        for c in all_candidates:
            # Ghi chuỗi và tạo một dòng trống phía sau
            file.write(c.raw + "\n\n")

    # Coverage is checked against the *broad* combined pool (before any
    # further trimming) so a term isn't wrongly flagged "uncovered" just
    # because it only showed up via graph expansion/community summary — we
    # want to know if the corpus has it at all, not just whether dense/bm25
    # alone surfaced it.
   
    _, pool_uncovered = coverage_check(key_terms, all_candidates,get_objectllm())
    if pool_uncovered:
        logger.info("Query terms not found anywhere in retrieved pool: %s", pool_uncovered)

    coverage_ratio, uncovered_terms, retrieval_gap_terms = compute_coverage(
        key_terms, all_candidates, get_objectllm(), source_id=query.source_id,
        corpus_check_enabled=settings.d_coverage_check_scope == "full_corpus",
    )
    print(f"key_terms {key_terms}")
    # --- Nếu coverage thấp và bật LLM fallback, gọi LLM để bổ sung terms ---
    if (settings.d_llm_keyterm_fallback_enabled and
    coverage_ratio < settings.d_llm_keyterm_fallback_coverage_threshold ):
    
        logger.info("Coverage ratio %.2f below threshold %.2f, calling LLM for additional key terms",
                coverage_ratio, settings.d_llm_keyterm_fallback_coverage_threshold)
    
        if all_terms :
            # Tính lại coverage với combined terms
            new_ratio, new_uncovered, new_gap = compute_coverage(
                all_terms, all_candidates, get_objectllm(), source_id=query.source_id,
                corpus_check_enabled=settings.d_coverage_check_scope == "full_corpus",
            )
            # Chỉ cập nhật nếu coverage được cải thiện
            if new_ratio > coverage_ratio:
                coverage_ratio = new_ratio
                uncovered_terms = new_uncovered
                retrieval_gap_terms = new_gap
                key_terms = all_terms
                logger.info("Coverage improved to %.2f after LLM fallback", coverage_ratio)
            else:
                logger.info("LLM fallback did not improve coverage (%.2f vs %.2f)", new_ratio, coverage_ratio)

    # all_candidates = _rerank_blend(query.query_text, all_candidates,
    #                                 settings.d_max_total_candidates_for_answer,
    #                                 blend=settings.d_final_rerank_blend_weight)
    all_candidates = all_candidates[:query.top_k_final]
    for c in all_candidates:
        print(f"all_candidates  [{c.source}] score={c.relevance_score:.3f}  {c.raw[:80]!r}  {c.type} relation :{c.relation}")


    candidate_ids = [c.atom_id for c in all_candidates]
    # edges = db.get_edges_between_atoms(candidate_ids)
    
    result = self_verify(all_candidates, coverage_ratio, uncovered_terms, suggestions,
                          chain_coverage=entity_path_chain_coverage)
    # Đề xuất #14 — retrieval_gap_terms (từ khóa CÓ trong corpus nhưng bị
    # retrieval bỏ lỡ, tính sẵn ở compute_coverage() phía trên) trước đây bị
    # bỏ phí ngay tại đây — không field nào trên RetrievalResult giữ lại
    # nó, nên không nơi nào (kể cả stage E) có thể tự động dùng lại để thử
    # retrieve() thêm 1 lượt khi insufficient_context=True. Giờ giữ lại,
    # xem stages/e_query_output.py::answer_query / _retry_with_retrieval_gap.
    result.retrieval_gap_terms = retrieval_gap_terms

    for c in result.candidates:
        print(f"result  [{c.source}] score={c.relevance_score:.3f}  {c.raw[:80]!r}  {c.type} relation :{c.relation}")
        
    # relation_lines=[]
    # for e in edges:
    #         # Chỉ hiển thị nếu cả hai endpoint đều có trong danh sách candidate (đã đảm bảo bởi truy vấn)
    #         evidence = f" (evidence: {e['evidence_raw'][:100]})" if e.get('evidence_raw') else ""
    #         score_info = f" score={e.get('score', 0):.2f}" if e.get('score') is not None else ""
    #         relation_lines.append(
    #             f"- [#{e['source_id']}] --{e['relation']}--> [#{e['target_id']}]{evidence}{score_info}"
    #         )
    #         print(f"candidate_edges - [#{e['source_id']}] --{e['relation']}--> [#{e['target_id']}]{evidence}{score_info}")
    
    result.query_text = query.query_text
    result.suggestions = suggestions
    # Đề xuất #1 — chuỗi entity-fact tìm được từ entity_path_search, giữ
    # nguyên cấu trúc thay vì chỉ có mặt gián tiếp qua các candidate rời rạc
    # (origin="graph_expansion"). Rỗng nếu entity_path_search không chạy
    # hoặc không tìm được path nào — build_answer_json bỏ qua block prompt
    # tương ứng trong trường hợp đó.
    result.entity_paths = entity_paths
    return result

def generate_hyde_passage(query_text: str, llm: LLMClient) -> str:
    """Phase 2 fix (analysis doc #5) — HyDE: generate a short hypothetical
    "answer passage" for the query with a cheap tier="light" LLM call. This
    passage reads much closer to the corpus's own documentation style than a
    short user question does, so embedding IT (in addition to the raw
    query) and fusing both dense-search result lists surfaces atoms that
    answer the question using different wording/synonyms than the query
    itself — the exact "hỏi ngắn, viết khác" gap this fixes. Cheaper than
    full multi-query rewriting since it's a single extra light-tier call.
    Returns "" (caller should just skip HyDE) if the LLM call fails.
    """
    try:
        hyde_text = llm.generate(query_text, system=_HYDE_SYSTEM_PROMPT, tier="light").strip()
        return hyde_text
    except Exception as e:
        print(f"HyDE passage generation failed, skipping HyDE dense search:  {e}")
        return ""
_HYDE_SYSTEM_PROMPT = (
    "Bạn là một trợ lý viết tài liệu kỹ thuật nội bộ. Hãy viết một đoạn văn "
    "NGẮN (3-5 câu), giả định là một đoạn trả lời trực tiếp cho câu hỏi được "
    "đưa ra, dùng văn phong tài liệu kỹ thuật/knowledge base. Không thêm lời "
    "dẫn, không nói 'tôi không biết' — chỉ viết đoạn văn giả định đó."
)

def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = sum(x * x for x in a) ** 0.5
    norm_b = sum(y * y for y in b) ** 0.5
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return dot / (norm_a * norm_b)

_ppr_graph_cache: dict[str, tuple[float, list[dict], list[dict]]] = {}


def _get_nodes_edges_cached(source_id: str) -> tuple[list[dict], list[dict]]:
    """TTL cache around db.get_nodes_edges_for_source(), keyed by source_id.

    Without this, graph_search_ppr() re-fetched the ENTIRE document's nodes
    and edges from Postgres on every single query, even repeated queries
    against the same document seconds apart. TTL (not a hard invalidation
    on ingest) is a deliberate simplification: it means a re-ingested/edited
    document can serve a stale graph for up to
    settings.d_ppr_graph_cache_ttl_seconds — acceptable for a QA workload
    where documents don't change every few seconds, but call
    invalidate_ppr_graph_cache(source_id) explicitly after re-ingesting a
    document if you need the new graph immediately. Set the TTL to 0 to
    disable caching entirely (always read fresh).
    """
    ttl = settings.d_ppr_graph_cache_ttl_seconds
    if ttl <= 0:
        return db.get_nodes_edges_for_source(source_id)
    now = time.time()
    cached = _ppr_graph_cache.get(source_id)
    if cached and (now - cached[0]) < ttl:
        return cached[1], cached[2]
    nodes, edges = db.get_nodes_edges_for_source(source_id)
    _ppr_graph_cache[source_id] = (now, nodes, edges)
    return nodes, edges


def invalidate_ppr_graph_cache(source_id: Optional[str] = None) -> None:
    """Call after re-ingesting/editing a document so graph_search_ppr picks
    up the new graph immediately instead of waiting out the TTL. Pass None
    to clear the whole cache."""
    if source_id is None:
        _ppr_graph_cache.clear()
    else:
        _ppr_graph_cache.pop(source_id, None)


def _bounded_graph_for_ppr(nodes: list[dict], edges: list[dict],
                            seed_ids: list[str]):
    """Builds the graph PPR actually runs on. If the FULL per-document graph
    is small enough (<= settings.d_ppr_max_graph_nodes), use it as-is — this
    is the common case for most KBs and gives PPR its full benefit (a
    relevant node several hops away through strong edges can outrank a node
    1 hop away through a weak edge, with no distance cutoff).

    Once a document's graph exceeds that cap, running full-graph PageRank on
    every query no longer scales (latency grows with total document size,
    not with question scope; memory grows with concurrent requests since
    each builds its own networkx.Graph). Instead, build the graph from the
    UNION of bounded ego-networks (nx.ego_graph, radius=
    settings.d_ppr_ego_radius) around every seed id — this keeps PPR's
    degree-normalized ranking within that neighborhood while making the
    compute cost bounded by the ego radius, not by the total size of the
    document — exactly like the original BFS's max_depth bounded its cost,
    just with PPR's ranking quality instead of plain unweighted hop-distance.
    """
    g_full = nx.Graph()
    for n in nodes:
        g_full.add_node(n["id"])
    for e in edges:
        w = _edge_weight(e["relation"], e.get("score"))
        if g_full.has_edge(e["source_id"], e["target_id"]):
            g_full[e["source_id"]][e["target_id"]]["weight"] += w
        else:
            g_full.add_edge(e["source_id"], e["target_id"], weight=w)

    if g_full.number_of_nodes() <= settings.d_ppr_max_graph_nodes:
        return g_full

    logger.info(
        "graph_search_ppr: document graph has %d nodes (> d_ppr_max_graph_nodes=%d) — "
        "restricting PPR to ego-subgraph radius=%d around %d seeds instead of the full graph",
        g_full.number_of_nodes(), settings.d_ppr_max_graph_nodes,
        settings.d_ppr_ego_radius, len(seed_ids),
    )
    sub_nodes: set[str] = set()
    for sid in seed_ids:
        if sid in g_full:
            sub_nodes.update(nx.ego_graph(g_full, sid, radius=settings.d_ppr_ego_radius).nodes())
    if not sub_nodes:
        return g_full.subgraph([])  # empty — caller handles gracefully
    return g_full.subgraph(sub_nodes).copy()


def graph_search_ppr(seed_atom_ids: list[str], query_text: str, source_id: Optional[str],



                      llm: LLMClient, top_k: int = 40,
                      alpha: float = 0.85) -> list[RetrievedCandidate]:
    """Thay BFS depth-capped bằng Personalized PageRank — kèm 3 cơ chế kiểm
    soát chi phí tính toán (xem docstrings của _get_nodes_edges_cached và
    _bounded_graph_for_ppr): cache TTL cho việc đọc graph, ego-subgraph cap
    khi tài liệu quá lớn, và max_iter/tol tường minh cho pagerank thay vì
    mặc định của networkx."""
    nodes, edges = _get_nodes_edges_cached(source_id)
    if not nodes:
        return []

    g = _bounded_graph_for_ppr(nodes, edges, seed_atom_ids)
    if g.number_of_nodes() == 0:
        return []

    # Personalization: vector-seed + symbolic-anchor-seed
    personalization: dict[str, float] = {}
    n_seeds = max(len(seed_atom_ids), 1)
    for aid in seed_atom_ids:
        if aid in g:
            personalization[aid] = personalization.get(aid, 0.0) + 1.0 / n_seeds

    # Symbolic anchoring — dùng extract_key_terms đã có. Linking dùng
    # link_entities_from_terms (đề xuất #7, sửa kèm) — cascade khớp-chính-xác
    # -> ILIKE -> LLM-term -> embedding CHUNG với entity_path_search, thay vì
    # bare db.lookup_entity_ids (chỉ khớp chính xác) như trước — 1 anchor
    # (min_ids=1) đã đủ hữu ích cho personalization vector của PPR.
    key_terms = extract_key_terms(query_text)
    print(f"combined_terms {key_terms}")
    anchor_entities = link_entities_from_terms(key_terms, query_text, source_id, llm, min_ids=1,
                                                log_prefix="graph_search_ppr")
    if anchor_entities:
        # Đề xuất #12 — tỷ lệ trọng số anchor entity (khớp lexical trực
        # tiếp trong câu hỏi) so với tổng trọng số 1.0 của dense seed atom.
        # Trước đây hard-code 0.5 (anchor luôn chỉ bằng NỬA dense seed) dù
        # với câu hỏi multi-hop, entity trung gian được gọi tên trực tiếp
        # thường là tín hiệu ĐÁNG TIN HƠN similarity của cả câu hỏi (atom mô
        # tả riêng quan hệ đó có thể không giống embedding câu hỏi tổng).
        # settings.d_ppr_anchor_weight_ratio mặc định vẫn là 0.5 (backward-
        # compatible) — tăng dần lên 1.0 (ngang hàng dense seed) SAU KHI A/B
        # test, không đổi ngay 1:1: entity degree cao (hub) có thể kéo PPR
        # tập trung quá mức vào vùng lân cận hub, giảm đa dạng kết quả.
        w_anchor = settings.d_ppr_anchor_weight_ratio / len(anchor_entities)
        for eid in anchor_entities:
            if eid in g:
                personalization[eid] = personalization.get(eid, 0.0) + w_anchor

    if not personalization:
        return []

    try:
        scores = nx.pagerank(g, alpha=alpha, personalization=personalization, weight="weight",
                              max_iter=settings.d_ppr_max_iter, tol=settings.d_ppr_tol)
    except nx.PowerIterationFailedConvergence as e:
        logger.warning("PPR did not converge within max_iter=%d for source_id=%s: %s — "
                        "falling back to empty graph expansion for this query",
                        settings.d_ppr_max_iter, source_id, e)
        return []
    except Exception as e:
        logger.warning("PPR failed, falling back to empty graph expansion: %s", e)
        return []

    ranked = sorted(
        ((nid, s) for nid, s in scores.items() if nid not in seed_atom_ids),
        key=lambda x: x[1], reverse=True,
    )[:top_k]

    seed_and_anchor_ids = set(seed_atom_ids) | set(anchor_entities)
    results = []
    for node_id, score in ranked:
        if node_id.startswith("ent_"):
            continue
        atom = db.get_knowledge_atom(node_id)
        if not atom:
            continue
        best_edge = _nearest_seed_edge(node_id, edges, seed_and_anchor_ids)
        relation, linked_from = best_edge if best_edge else (None, None)
        results.append(RetrievedCandidate(
            atom_id=atom["id"], raw=atom["raw"], normalized=atom["normalized"],
            source="graph", ppr_score=score,
            confidence=float(atom["confidence"] or 0),
            contradicts_flag=atom["contradicts_flag"],
            origin="graph_expansion", section_id=atom["section_id"],
            relation=relation, linked_from=linked_from,
        ))
    return results

def _nearest_seed_edge(node_id: str, edges: list[dict],
                        seed_and_anchor_ids: set[str]) -> Optional[tuple[str, str]]:
    """Best-effort lookup of (relation, linked_from) for a PPR result node.

    PPR reaches a node via a converged random-walk probability distribution
    over the WHOLE graph, not by traversing one single edge the way BFS
    does — so there usually isn't "the one relation" that explains why a
    node surfaced, unlike graph_search_bfs's row["relation"]/row["seed_id"].
    However, in the common case a PPR top-result node IS still a direct,
    1-hop neighbor of one of the seed/anchor nodes (PPR just also considers
    farther nodes without a hard depth cutoff) — in that case reporting the
    real relation type is both accurate and genuinely useful to the answer
    LLM (see ANSWER_SYSTEM_PROMPT rule 6: it interprets DEFINES/EXTENDS/
    RELATED_TO differently). This scans the raw edge list (not the
    aggregated-weight networkx graph, which merges parallel edges and loses
    the individual relation labels) for any edge directly connecting
    `node_id` to a seed or anchor id, and returns the highest-weight one if
    several exist. Returns None if the node is only reachable through 2+
    hops of diffusion — that's a real "no single relation" case, not a bug,
    and the caller/formatter should say so honestly rather than guess.
    """
    best: Optional[tuple[str, str, float]] = None  # (relation, linked_from, weight)
    for e in edges:
        src, tgt, rel = e["source_id"], e["target_id"], e["relation"]
        if rel == "SIMILAR_TO":
            continue  # not informative to show as "the reason" — see e_query_output's own SIMILAR_TO exclusion
        neighbor = None
        if src == node_id and tgt in seed_and_anchor_ids:
            neighbor = tgt
        elif tgt == node_id and src in seed_and_anchor_ids:
            neighbor = src
        if neighbor is None:
            continue
        w = _edge_weight(rel, e.get("score"))
        if best is None or w > best[2]:
            best = (rel, neighbor, w)
    return (best[0], best[1]) if best else None

_LLM_KEYTERM_SYSTEM_PROMPT = (
    "Bạn là trợ lý trích xuất từ khóa. Hãy đọc câu hỏi và liệt kê các cụm từ khóa (key phrases) "
    "quan trọng nhất, chỉ bao gồm các chủ đề, thực thể, khái niệm chính. "
    "KHÔNG bao gồm các từ chức năng (như 'là', 'của', 'và', 'hoặc'). "
    "Trả về danh sách các cụm từ (mỗi cụm là một chuỗi), không thêm giải thích hay định dạng khác. "
    "Định dạng JSON: {\"terms\": [\"term1\", \"term2\", ...]}"
)

def extract_key_terms_llm(query_text: str, llm: LLMClient) -> list[str]:
    """Gọi LLM để trích xuất key terms từ câu hỏi."""
    if not llm:
        return []
    try:
        raw = llm.generate(
            f"Câu hỏi: {query_text}",
            system=_LLM_KEYTERM_SYSTEM_PROMPT,
            json_mode=True,
            tier="light"
        )
        data = extract_and_parse_json(raw)
        
        # Xử lý cả hai trường hợp data là dict hoặc list
        if isinstance(data, dict):
            terms = data.get("terms", [])
        elif isinstance(data, list):
            terms = data
        else:
            terms = []
            
        if isinstance(terms, list):
            seen = set()
            filtered = []
            for t in terms:
                if not isinstance(t, str):
                    continue
                t = t.strip()
                if t and len(t) >= 3 and t not in seen:
                    seen.add(t)
                    filtered.append(t)
            return filtered[:settings.d_llm_keyterm_max_terms]
    except Exception as e:
        logger.warning("LLM key term extraction failed: %s", e)
    return []

def compute_coverage(key_terms: list[str], candidates: list[RetrievedCandidate],
                     llm: Optional[LLMClient] = None,
                     source_id: Optional[str] = None,
                     corpus_check_enabled: bool = True) -> tuple[float, list[str], list[str]]:
    """Tính coverage ratio và trả về (coverage_ratio, uncovered_terms, retrieval_gap_terms)."""
    if not key_terms:
        return 1.0, [], []
    _, pool_uncovered = coverage_check(key_terms, candidates, llm)
    uncovered_terms, retrieval_gap_terms = resolve_uncovered_terms(
        pool_uncovered,
        source_id=source_id,
        corpus_check_enabled=corpus_check_enabled,
    )
    covered_n = len(key_terms) - len(uncovered_terms)
    ratio = covered_n / len(key_terms)
    return ratio, uncovered_terms, retrieval_gap_terms

def _score_expanded_against_anchor(expanded_candidates: list[RetrievedCandidate],
                                    anchor_by_parent: dict[str, tuple[str, str]]) -> list[RetrievedCandidate]:
    """Replace flat score-inheritance for origin="section_expansion" candidates
    with a real per-pair similarity: cross-encoder(anchor_seed_text, candidate.raw).
    ...
    """
    if not expanded_candidates:
        return []
    try:
        from sentence_transformers import CrossEncoder
        model = CrossEncoder("BAAI/bge-reranker-v2-m3", max_length=1024)
    except Exception as e:
        logger.warning("Cross-encoder unavailable for anchor scoring (%s) — "
                        "keeping flat inherited section scores as-is.", e)
        return expanded_candidates

    pairs, scored = [], []
    for c in expanded_candidates:
        parent_id = f"parent_{c.section_id}" if c.section_id else None
        anchor = anchor_by_parent.get(parent_id) if parent_id else None
        if not anchor:
            continue
        anchor_atom_id, anchor_text = anchor
        pairs.append((anchor_text, c.raw))
        scored.append((c, anchor_atom_id))

    if not pairs:
        return expanded_candidates

    raw_scores = model.predict(pairs)
    w = settings.d_expansion_anchor_weight
    for (c, anchor_atom_id), s in zip(scored, raw_scores):
        anchor_sim = float(1.0 / (1.0 + math.exp(-float(s))))  # sigmoid, same convention as rerank1
        c.anchor_similarity = anchor_sim
        c.anchor_atom_id = anchor_atom_id
        prior_floor = c.relevance_score  # inherited seed_score_by_parent
        c.relevance_score = w * anchor_sim + (1.0 - w) * prior_floor
    return expanded_candidates

def _score_against_anchor(anchor_id: str, anchor_text: str,
                           candidates: list[RetrievedCandidate]) -> None:
    """Cross-encoder-score each candidate against a SPECIFIC anchor atom's
    raw text (not the user's query) and write the result onto
    candidate.anchor_similarity / candidate.anchor_atom_id in place.

    Why this exists (design-doc §9.3): an expansion candidate's job is to
    support the seed atom that pulled it in, not to resemble the question.
    Two atoms can share zero vocabulary/entities/vector-neighborhood with the
    query and still be exactly the evidence needed, as long as they're
    strongly related to an atom that DID match the query. rerank() already
    gives us candidate<->query similarity (query_similarity); this gives us
    candidate<->anchor similarity on the same cross-encoder, so soft_score()
    can blend both instead of relying on query-similarity alone.

    NOTE: rerank() mutates `c.relevance_score` in place — we snapshot and
    restore query_similarity around the call so this doesn't clobber it.
    """
    if not candidates or not anchor_text:
        return
    snapshot = {c.atom_id: c.relevance_score for c in candidates}
    rerank(anchor_text, candidates, len(candidates))  # mutates .relevance_score = sim(anchor, c)
    for c in candidates:
        c.anchor_similarity = c.relevance_score
        c.anchor_atom_id = anchor_id
        c.relevance_score = snapshot[c.atom_id]  # restore query_similarity


def _batch_score_against_anchor(
    candidates: list[RetrievedCandidate],
    anchor_map: dict[str, str],  # anchor_id -> anchor_text
) -> None:
    """
    Tính anchor similarity cho tất cả candidate bằng cross-encoder batch.
    Snapshot query_similarity trước khi gọi cross-encoder để bảo toàn.
    Gán kết quả vào c.anchor_similarity và c.anchor_atom_id.
    """
    if not candidates or not anchor_map:
        return

    # Snapshot query_similarity (hiện tại là relevance_score)
    for c in candidates:
        c.query_similarity = c.relevance_score  # hoặc snapshot riêng

    # Gom các cặp (anchor_text, candidate.raw) theo anchor_id
    pairs = []
    scored_items = []  # (candidate, anchor_id)
    for c in candidates:
        anchor_id = c.linked_from
        if not anchor_id or anchor_id not in anchor_map:
            continue
        anchor_text = anchor_map[anchor_id]
        pairs.append((anchor_text, c.raw))
        scored_items.append((c, anchor_id))

    if not pairs:
        return

    # Batch inference cross-encoder
    try:
        from sentence_transformers import CrossEncoder
        model = CrossEncoder("BAAI/bge-reranker-v2-m3", max_length=1024)
        raw_scores = model.predict(pairs)
    except Exception as e:
        logger.warning("Cross-encoder anchor scoring failed: %s", e)
        return

    # Gán anchor_similarity và khôi phục query_similarity
    for (c, anchor_id), s in zip(scored_items, raw_scores):
        # Sigmoid để chuẩn hóa về [0,1]
        c.anchor_similarity = float(1.0 / (1.0 + math.exp(-float(s))))
        c.anchor_atom_id = anchor_id
        # Khôi phục relevance_score về query_similarity (đã snapshot)
        c.relevance_score = getattr(c, 'query_similarity', 0.0)

def merge_candidates_with_priority(
    seed: list[RetrievedCandidate],
    expanded_top: list[RetrievedCandidate],
    community_hits: list[RetrievedCandidate],
    target_total: int,
    entity_path_hits: Optional[list[RetrievedCandidate]] = None,
    max_ratios: Optional[dict] = None,
) -> list[RetrievedCandidate]:
    """
    Gộp candidate từ các nguồn — ưu tiên điểm số, với 1 floor tối thiểu
    đảm bảo cho mỗi nguồn (KHÔNG phải ceiling tối đa như trước).

    Câu hỏi người dùng — trước đây `max_ratios` là CEILING cứng tính trên
    số lượng RAW của mỗi nguồn (trước khi biết trùng lặp): 1 candidate điểm
    cao của nguồn A có thể bị loại chỉ vì nguồn A đã "đủ quota", dù nguồn B
    (dưới quota) đang giữ chỗ bằng candidate điểm THẤP hơn — vì
    `sum(max_slots.values())` thường >= target_total trong thực tế, "vòng
    lấy thêm không giới hạn nguồn" ở cuối hầu như không bao giờ chạy tới,
    nên ceiling gần như luôn thực sự chặn candidate điểm cao ở nguồn "đầy".

    Đổi sang 2 giai đoạn:
      1. FLOOR — mỗi nguồn được đảm bảo TỐI THIỂU
         `d_merge_min_ratio_<name> * target_total` slot (nếu nguồn đó có đủ
         candidate) — bảo toàn tính đa dạng nguồn (đặc biệt entity_path/
         community, vốn có công thức tính điểm khác seed/expanded nên dễ bị
         "thua" nếu so điểm thuần tuý ngay từ đầu).
      2. GLOBAL FILL — phần CÒN LẠI của target_total lấp bằng điểm số TOÀN
         CỤC, không phân biệt nguồn, không còn ceiling nào chặn — candidate
         điểm cao ở bất kỳ nguồn nào (kể cả nguồn đã đủ floor) đều có cơ hội
         cạnh tranh công bằng cho các slot còn lại.

    `max_ratios` vẫn được NHẬN vào (giữ tương thích chữ ký cũ) nhưng KHÔNG
    còn dùng làm ceiling chặn — dùng làm floor nếu người gọi truyền vào,
    còn không thì lấy từ settings.d_merge_min_ratio_*.
    """
    if target_total <= 0:
        return []

    sources = {
        "seed": seed,
        "expanded": expanded_top,
        "community": community_hits,
        "entity_path": entity_path_hits or [],
    }
    for name, cands in sources.items():
        for c in cands:
            c._source_name = name

    print(f"merge_candidates_with_priority seed {len(seed)} expanded {len(expanded_top)} "
          f"entity_path {len(entity_path_hits or [])} community {len(community_hits)}")

    default_min = {
        "seed": settings.d_merge_min_ratio_seed,
        "expanded": settings.d_merge_min_ratio_expanded,
        "community": settings.d_merge_min_ratio_community,
        "entity_path": settings.d_merge_min_ratio_entity_path,
    }
    min_ratios = max_ratios if max_ratios is not None else default_min

    floor_slots = {}
    for name in sources:
        ratio = min_ratios.get(name, 0.0)
        if ratio <= 0 or not sources[name]:
            floor_slots[name] = 0
        else:
            # max(1, ...) — tránh int() làm tròn xuống 0 khi target_total
            # nhỏ (VD 10 * 0.05 = 0.5 -> int() = 0, làm floor mất hiệu lực
            # dù ratio > 0 và nguồn có candidate thật).
            floor_slots[name] = min(max(1, int(target_total * ratio)), len(sources[name]))

    selected: list[RetrievedCandidate] = []
    selected_ids: set[str] = set()

    # --- Giai đoạn 1: FLOOR — mỗi nguồn lấy top candidate của CHÍNH NÓ
    # (theo relevance_score) tới floor_slots[name], không cạnh tranh với
    # nguồn khác ở bước này.
    for name, cands in sources.items():
        cands_sorted = sorted(cands, key=lambda c: c.relevance_score, reverse=True)
        taken = 0
        for c in cands_sorted:
            if taken >= floor_slots[name] or len(selected) >= target_total:
                break
            if c.atom_id in selected_ids:
                continue
            selected.append(c)
            selected_ids.add(c.atom_id)
            taken += 1

    # --- Giai đoạn 2: GLOBAL FILL — không còn ceiling, chỉ dedup theo
    # atom_id, lấp phần còn lại của target_total bằng điểm số toàn cục.
    if len(selected) < target_total:
        all_candidates = []
        for cands in sources.values():
            all_candidates.extend(cands)
        all_candidates.sort(key=lambda c: c.relevance_score, reverse=True)
        for c in all_candidates:
            if len(selected) >= target_total:
                break
            if c.atom_id in selected_ids:
                continue
            selected.append(c)
            selected_ids.add(c.atom_id)

    # --- Giai đoạn 3: lọc near-duplicate NGỮ NGHĨA (atom_id khác nhau
    # nhưng nội dung gần trùng) — trùng atom_id đã được lọc ở trên (dedup
    # qua selected_ids), nhưng 2 atom KHÁC id diễn đạt lại cùng 1 ý thì
    # không bị chặn bởi 2 giai đoạn trên, mỗi bản vẫn chiếm 1 slot riêng.
    # Chỉ chạy trên tập `selected` đã bounded (nhỏ, rẻ) — xem
    # db.find_near_duplicate_pairs.
    try:
        selected = _drop_near_duplicates(
            selected, all_pool=sum(sources.values(), []), selected_ids=selected_ids,
        )
    except Exception as e:
        print(f"[MERGE] Bỏ qua lọc near-duplicate do lỗi: {e}")

    for c in selected:
        if hasattr(c, '_source_name'):
            delattr(c, '_source_name')

    return selected

def _drop_near_duplicates(
    selected: list[RetrievedCandidate],
    all_pool: list[RetrievedCandidate],
    selected_ids: set[str],
) -> list[RetrievedCandidate]:
    """Với mỗi cặp candidate trong `selected` có embedding similarity vượt
    `settings.d_merge_near_dup_similarity_threshold`, giữ điểm cao hơn, bỏ
    điểm thấp hơn — giải phóng 1 slot, kéo candidate tốt tiếp theo (chưa
    từng được chọn ở bất kỳ nguồn nào) vào lấp chỗ. Lặp tối đa
    `d_merge_near_dup_max_passes` lần để tránh dao động qua lại vô hạn."""
    if len(selected) < 2:
        return selected

    atom_ids = [c.atom_id for c in selected]
    pairs = db.find_near_duplicate_pairs(atom_ids, settings.d_merge_near_dup_similarity_threshold)
    if not pairs:
        return selected

    by_id = {c.atom_id: c for c in selected}
    remaining_pool = sorted(
        [c for c in all_pool if c.atom_id not in selected_ids],
        key=lambda c: c.relevance_score, reverse=True,
    )
    pool_idx = 0
    target_total = len(selected)
    passes = 0

    while pairs and passes < settings.d_merge_near_dup_max_passes:
        passes += 1
        # Lấy cặp similarity cao nhất trước — xử lý trường hợp rõ ràng nhất.
        id1, id2, sim = max(pairs, key=lambda p: p[2])
        if id1 not in by_id or id2 not in by_id:
            pairs = db.find_near_duplicate_pairs(list(by_id.keys()),
                                                  settings.d_merge_near_dup_similarity_threshold)
            continue
        c1, c2 = by_id[id1], by_id[id2]
        drop = c1 if c1.relevance_score <= c2.relevance_score else c2
        print(f"[MERGE] Near-duplicate (similarity={sim:.3f}): bỏ #{drop.atom_id} "
              f"(score={drop.relevance_score:.3f}), giữ "
              f"#{c2.atom_id if drop is c1 else c1.atom_id}")
        del by_id[drop.atom_id]
        selected_ids.discard(drop.atom_id)

        # Kéo candidate tốt tiếp theo (chưa được chọn) vào lấp chỗ, nếu còn.
        while pool_idx < len(remaining_pool):
            cand = remaining_pool[pool_idx]
            pool_idx += 1
            if cand.atom_id in by_id or cand.atom_id in selected_ids:
                continue
            by_id[cand.atom_id] = cand
            selected_ids.add(cand.atom_id)
            break

        if len(by_id) < 2:
            break
        pairs = db.find_near_duplicate_pairs(list(by_id.keys()),
                                              settings.d_merge_near_dup_similarity_threshold)

    result = list(by_id.values())
    result.sort(key=lambda c: c.relevance_score, reverse=True)
    return result[:target_total]

def _batch_score_query_similarity(query_text: str, candidates: list[RetrievedCandidate]) -> None:
    """Tính query_similarity thực sự cho từng candidate bằng cross-encoder."""
    if not candidates:
        return
    try:
        from sentence_transformers import CrossEncoder
        model = CrossEncoder("BAAI/bge-reranker-v2-m3", max_length=1024)
        pairs = [(query_text, c.raw) for c in candidates]
        scores = model.predict(pairs)
        for c, s in zip(candidates, scores):
            c.query_similarity = float(1.0 / (1.0 + math.exp(-float(s))))
    except Exception as e:
        logger.warning("Query similarity batch scoring failed: %s", e)
        # fallback: giữ nguyên giá trị cũ (dù không chính xác)
def link_entities_from_terms(key_terms: list[str], query_text: str, source_id: Optional[str],
                              llm: Optional[LLMClient] = None, min_ids: int = 1,
                              log_prefix: str = "link_entities_from_terms") -> list[str]:
    """Đề xuất #7 (sửa kèm) — MỘT cascade linking key-term -> entity_id dùng
    chung cho CẢ 2 kênh graph, thay vì graph_search_ppr dùng
    db.lookup_entity_ids (khớp CHÍNH XÁC canonical_name) còn
    entity_path_search/_entities_from_query dùng db.lookup_entity_ids_like
    (khớp ILIKE substring) — 2 hàm khác nhau cho cùng nhiệm vụ "map
    key-term câu hỏi -> entity_id", khiến 2 kênh graph có hành vi linking
    khác nhau một cách không chủ đích.

    4 bước, mỗi bước chỉ chạy nếu bước trước chưa đạt `min_ids` kết quả:
      1. Khớp CHÍNH XÁC canonical_name (db.lookup_entity_ids) — rẻ nhất,
         precision cao nhất.
      2. Khớp ILIKE substring (db.lookup_entity_ids_like) trên cùng
         key_terms — bắt các mention một phần/khác dạng viết mà khớp chính
         xác bỏ lỡ.
      3. Trích key-term qua LLM (extract_key_terms_llm) + ILIKE — bắt các
         mention không viết hoa / diễn đạt khác mà heuristic key_terms bỏ
         lỡ (đề xuất #2, bước 1).
      4. Embedding similarity trên entity_map.name_embedding
         (db.ann_search_entities) — bắt trường hợp canonical_name (A4.5
         union-find chọn) không khớp substring literal với cách câu hỏi
         diễn đạt (đề xuất #2, bước 2).

    `min_ids` để caller quyết định "đủ" là bao nhiêu: entity_path_search
    cần >=2 (để có 1 cặp dựng path), graph_search_ppr cần >=1 (1 anchor
    vẫn có ích cho personalization vector của PPR).
    """
    ids = db.lookup_entity_ids(key_terms, source_id) if key_terms else []
    if len(ids) >= min_ids:
        return ids

    if key_terms:
        like_ids = db.lookup_entity_ids_like(key_terms, source_id=source_id)
        ids = list(dict.fromkeys(ids + like_ids))
    if len(ids) >= min_ids:
        return ids

    llm_terms: list[str] = []
    if llm is not None:
        llm_terms = extract_key_terms_llm(query_text, llm)
        extra_terms = [t for t in llm_terms if t.lower() not in {k.lower() for k in key_terms}]
        if extra_terms:
            more_ids = db.lookup_entity_ids_like(extra_terms, source_id=source_id)
            ids = list(dict.fromkeys(ids + more_ids))
            print(f"{log_prefix}: LLM key-term fallback: {extra_terms} -> +{len(more_ids)} id(s)")

    if len(ids) >= min_ids:
        return ids

    if llm is not None:
        terms_for_embed = key_terms or llm_terms
        if terms_for_embed:
            try:
                embeddings = llm.embed(terms_for_embed)
            except Exception as e:
                logger.warning("%s: embedding fallback failed (%s)", log_prefix, e)
                embeddings = []
            for term, emb in zip(terms_for_embed, embeddings):
                hits = db.ann_search_entities(
                    emb, top_k=1, source_id=source_id,
                    min_similarity=settings.d_entity_link_embed_min_similarity,
                )
                for h in hits:
                    if h["entity_id"] not in ids:
                        ids.append(h["entity_id"])
                        print(f"{log_prefix}: embedding fallback: '{term}' -> "
                              f"{h['entity_id']} ({h['canonical_name']!r}, score={h.get('score'):.3f})")

    return ids


def _entities_from_query(query_text: str, source_id: Optional[str],
                          llm: Optional[LLMClient] = None) -> list[str]:
    """Link entities mentioned in the question to entity_map rows — thin
    wrapper over the shared link_entities_from_terms cascade (đề xuất #7),
    min_ids=2 vì entity_path_search cần >=2 seed để dựng path."""
    key_terms = extract_key_terms(query_text)
    extra_terms = extract_key_terms_llm(query_text, llm)
    if extra_terms:
        key_terms = list(dict.fromkeys(key_terms + extra_terms))
    print(f"_entities_from_query key {key_terms}")
    return link_entities_from_terms(key_terms, query_text, source_id, llm, min_ids=2,
                                     log_prefix="_entities_from_query")


def graph_ppr_facts(seed_entity_ids: list[str], source_id: Optional[str] = None,
                     alpha: float = 0.85, top_k: int = 10) -> list[dict]:
    """Đề xuất #6 — Personalized PageRank trên graph kg_facts (entity-entity,
    domain-specific, nhỏ và ổn định theo domain — KHÔNG phình theo độ dài
    tài liệu như graph atom hỗn hợp graph_search_ppr chạy trên). Vì graph
    này nhỏ, không cần ego-radius cap kiểu _bounded_graph_for_ppr — chạy
    full-graph PPR trực tiếp.

    Dùng làm FALLBACK cho entity_path_search khi BFS depth-capped
    (db.graph_traverse_facts, cắt cứng ở settings.d_entity_path_max_depth)
    không tìm được path, hoặc path tìm được có coverage thấp — lúc đó PPR
    có thể tìm ra entity trung gian xác suất cao mà BFS bỏ lỡ vì nó nằm
    NGOÀI max_depth (PPR không bị giới hạn hop, chỉ bị giới hạn bởi
    max_iter/tol). KHÔNG thay thế BFS — BFS vẫn nhanh và chính xác hơn cho
    path ngắn, xem entity_path_search cho cách 2 kênh phối hợp.

    Trả về list[dict] {"entity_id", "ppr_score"} (đã loại seed), sort giảm
    dần theo score, cắt top_k. Không raise — graph rỗng hoặc PPR không hội
    tụ chỉ trả về [] (retrieval tiếp tục với path BFS đã có, nếu có)."""
    if not seed_entity_ids:
        return []
    fact_rows = db.get_all_facts_for_source(source_id)
    if not fact_rows:
        return []

    g = nx.Graph()
    for r in fact_rows:
        w = float(r.get("confidence") if r.get("confidence") is not None else 0.5)
        src, tgt = r["source_entity_id"], r["target_entity_id"]
        if g.has_edge(src, tgt):
            g[src][tgt]["weight"] += w
        else:
            g.add_edge(src, tgt, weight=w)

    personalization = {sid: 1.0 for sid in seed_entity_ids if sid in g}
    if not personalization:
        return []
    total = sum(personalization.values())
    personalization = {k: v / total for k, v in personalization.items()}

    try:
        scores = nx.pagerank(g, alpha=alpha, personalization=personalization, weight="weight",
                              max_iter=settings.d_ppr_max_iter, tol=settings.d_ppr_tol)
    except Exception as e:
        logger.warning("graph_ppr_facts: PPR failed/không hội tụ (%s) — bỏ qua fallback", e)
        return []

    seed_set = set(seed_entity_ids)
    ranked = sorted(
        ((eid, s) for eid, s in scores.items() if eid not in seed_set),
        key=lambda x: x[1], reverse=True,
    )[:top_k]
    return [{"entity_id": eid, "ppr_score": s} for eid, s in ranked]


def graph_ppr_facts_multi(seed_clusters: list[list[str]], source_id: Optional[str] = None,
                           alpha: float = 0.85, top_k_per_run: int = 10) -> list[dict]:
    """Đề xuất #13 — thay vì 1 personalization vector gộp TOÀN BỘ seed entity
    (dễ bị 1 cụm đông/hub degree cao lấn át cụm nhỏ), chạy PPR RIÊNG cho
    từng cụm seed rồi cộng điểm thưởng "connector node" cho entity lọt
    top-K ở >=2 lần chạy ĐỘC LẬP — về bản chất là "meet-in-the-middle
    search" áp lên PPR, khớp đúng bản chất câu hỏi multi-hop (tìm điểm nối
    giữa 2 nhóm thực thể được hỏi) hơn hẳn 1 điểm PPR gộp chung.

    CHỈ áp dụng cho fact-graph PPR (kg_facts, nhỏ, ổn định theo domain,
    KHÔNG phình theo độ dài tài liệu) — build nx.Graph 1 LẦN rồi tái dùng
    cho N lần personalization khác nhau (phần tốn nhất là build graph, tái
    dùng được, không tốn N lần), nên chi phí N lần chạy `nx.pagerank` chấp
    nhận được ở đây. KHÔNG áp dụng cho graph_search_ppr (graph atom hỗn hợp
    lớn hơn) — chi phí N lần ở đó cao hơn lợi ích tại giai đoạn này (xem
    đề xuất #13 trong đề xuất cải tiến).

    seed_clusters: list các cụm, mỗi cụm là 1 list entity_id — đơn giản
    nhất (và cách caller entity_path_search dùng): mỗi seed entity riêng lẻ
    là 1 cụm. Cụm rỗng bị lọc bỏ. Nếu sau khi lọc chỉ còn <2 cụm THỰC SỰ,
    kỹ thuật multi-run vô nghĩa với 1 cụm — fallback về graph_ppr_facts()
    gộp thường (personalization đều trên toàn bộ entity của cụm duy nhất).

    Trả về list[dict] {"entity_id", "ppr_score" (điểm PPR trung bình các
    lần chạy mà entity đó xuất hiện trong top-K), "connector": bool — True
    nếu entity lọt top_k_per_run ở >=2 lần chạy độc lập, tức được xác nhận
    là điểm nối từ >=2 seed KHÁC NHAU thay vì chỉ là hàng xóm gần 1 seed}.
    Sort giảm dần theo (connector, ppr_score) — connector node luôn được ưu
    tiên trước, cắt top_k_per_run. Không raise — cụm rỗng/PPR không hội tụ
    cho 1 cụm chỉ bỏ qua cụm đó, không làm hỏng cả hàm.
    """
    clusters = [list(dict.fromkeys(c)) for c in seed_clusters if c]
    if not clusters:
        return []
    if len(clusters) < 2:
        flat_seed = clusters[0] if clusters else []
        return graph_ppr_facts(flat_seed, source_id=source_id, alpha=alpha, top_k=top_k_per_run)

    fact_rows = db.get_all_facts_for_source(source_id)
    if not fact_rows:
        return []

    g = nx.Graph()
    for r in fact_rows:
        w = float(r.get("confidence") if r.get("confidence") is not None else 0.5)
        src, tgt = r["source_entity_id"], r["target_entity_id"]
        if g.has_edge(src, tgt):
            g[src][tgt]["weight"] += w
        else:
            g.add_edge(src, tgt, weight=w)

    all_seed_ids = {sid for cluster in clusters for sid in cluster}
    hit_count: dict[str, int] = {}
    score_sum: dict[str, float] = {}

    for cluster in clusters:
        personalization = {sid: 1.0 for sid in cluster if sid in g}
        if not personalization:
            continue
        total = sum(personalization.values())
        personalization = {k: v / total for k, v in personalization.items()}
        try:
            scores = nx.pagerank(g, alpha=alpha, personalization=personalization, weight="weight",
                                  max_iter=settings.d_ppr_max_iter, tol=settings.d_ppr_tol)
        except Exception as e:
            logger.warning("graph_ppr_facts_multi: PPR thất bại/không hội tụ cho 1 cụm (%s) — "
                            "bỏ qua cụm này, các cụm khác vẫn chạy", e)
            continue
        ranked = sorted(
            ((eid, s) for eid, s in scores.items() if eid not in all_seed_ids),
            key=lambda x: x[1], reverse=True,
        )[:top_k_per_run]
        for eid, s in ranked:
            hit_count[eid] = hit_count.get(eid, 0) + 1
            score_sum[eid] = score_sum.get(eid, 0.0) + s

    if not hit_count:
        return []

    results = [
        {"entity_id": eid, "ppr_score": score_sum[eid] / hit_count[eid], "connector": hit_count[eid] >= 2}
        for eid in hit_count
    ]
    results.sort(key=lambda r: (r["connector"], r["ppr_score"]), reverse=True)
    print(f"[ENTITY-PATH] graph_ppr_facts_multi: {len(clusters)} cụm, "
          f"{sum(1 for r in results if r['connector'])} connector node(s) tìm được")
    return results[:top_k_per_run]


def _linear_path_edges(path_rows_by_target: dict[str, dict], seed_a: str,
                        target_b: str) -> Optional[list[dict]]:
    """Đề xuất #8 — dựng lại đường đi TUYẾN TÍNH cụ thể seed_a -> ... ->
    target_b từ path_rows (1 row/target_entity_id, DISTINCT ON — tập cạnh
    reachable phẳng), dùng cột `path` graph_traverse_facts giờ trả về (mảng
    entity_id từ origin_seed tới target_entity_id của đường đi ngắn nhất
    tới đúng target đó).

    Đi lùi theo path[0]->path[1]->...->path[-1]=target_b, với mỗi cạnh
    (u, v) tra path_rows_by_target[v] để lấy fact_id — vì path_rows chỉ có
    1 row/target nên đây chính xác là dữ liệu đã có, không cần query thêm.

    Trả về None nếu target_b không reachable, hoặc đường đi ngắn nhất ghi
    nhận tới nó không xuất phát từ seed_a (một seed khác tới nó ở
    depth bằng/ngắn hơn và thắng DISTINCT ON) — đây là trường hợp thật
    "không có đường tuyến tính từ A", không phải lỗi.
    """
    row_b = path_rows_by_target.get(target_b)
    if not row_b or not row_b.get("path"):
        return None
    path = list(row_b["path"])
    if not path or path[0] != seed_a:
        return None
    edges: list[dict] = []
    for u, v in zip(path, path[1:]):
        row_v = path_rows_by_target.get(v)
        if not row_v:
            return None
        # Chấp nhận cả 2 chiều nối: (u=source, v=target) đi THUẬN, hoặc
        # (u=target, v=source) đi NGƯỢC — chỉ xảy ra khi bidirectional=True.
        forward = row_v["source_entity_id"] == u and row_v["target_entity_id"] == v
        backward = row_v["target_entity_id"] == u and row_v["source_entity_id"] == v
        if not (forward or backward):
            return None
        edges.append(row_v)
    return edges


def _chain_coverage_for_pairs(path_rows: list[dict], seed_entity_ids: list[str],
                               evidence_by_fact: dict[str, list[dict]]) -> Optional[float]:
    """Đề xuất #8/#9 — chain_coverage: khác `path_coverage` (đếm PHẲNG số
    cạnh có evidence / tổng số cạnh, không phân biệt vị trí), với mỗi cặp
    seed entity (A, B) trong câu hỏi, dựng lại path TUYẾN TÍNH A->...->B rồi
    đi từ đầu, dừng ngay khi gặp cạnh đầu tiên thiếu evidence:

        chain_coverage = longest_contiguous_evidence_prefix_len / len(linear_path_edges)

    Một cạnh thiếu evidence ở ĐẦU/GIỮA làm gãy toàn bộ suy luận từ đó về
    sau (chain_coverage thấp dù các cạnh sau đó có evidence); thiếu ở CUỐI
    thì phần đầu vẫn dùng được (chain_coverage cao). path_coverage không
    phân biệt được 2 trường hợp này.

    Trả về MIN across tất cả cặp seed dựng được path (chain đứt tệ nhất là
    tín hiệu gate cho self_verify, xem đề xuất #9) — hoặc None nếu không
    cặp seed nào dựng được path tuyến tính (single-hop / <2 seed / không
    path) — caller phải coi None là "không áp dụng", KHÔNG phải "đã đứt".
    """
    if len(seed_entity_ids) < 2:
        return None
    path_rows_by_target = {r["reached_entity_id"]: r for r in path_rows}
    coverages: list[float] = []
    for a in seed_entity_ids:
        for b in seed_entity_ids:
            if a == b:
                continue
            edges = _linear_path_edges(path_rows_by_target, a, b)
            if not edges:
                continue
            prefix = 0
            for r in edges:
                if evidence_by_fact.get(r["fact_id"]):
                    prefix += 1
                else:
                    break
            coverages.append(prefix / len(edges))
    return min(coverages) if coverages else None


def entity_path_search(query_text: str, llm: LLMClient, source_id: Optional[str] = None,
                        top_k: Optional[int] = None ,
    fallback_entity_ids: Optional[list[str]] = None 
    ) -> tuple[list[RetrievedCandidate], list[EntityPathHop], Optional[float]]:
    """Giai đoạn 2 algorithm: entity path -> fact edges -> evidence atoms ->
    evidence-gap detection -> targeted retrieval (max
    settings.d_entity_path_max_gap_rounds rounds) -> path coverage.

    1. Extract entities from the question, link them into entity_map.
       Đề xuất #7 — HỢP NHẤT 2 nguồn seed (không phải fallback
       all-or-nothing): `_entities_from_query` (entity trích trực tiếp từ
       key-terms câu hỏi) + `fallback_entity_ids` (entity trích từ top atom
       dense-seed, tính sẵn trong `retrieve()`) luôn được gộp (loại trùng),
       giống cách `graph_search_ppr` đã hòa seed-atom + anchor-entity vào
       CÙNG 1 personalization vector — KHÔNG đợi nguồn 1 về 0 mới dùng
       nguồn 2 như trước (case mất entity: câu hỏi trích được 1 entity rõ
       nhưng entity thứ 2 không match ILIKE dù CÓ trong fallback).
    2. BFS on the `reasoning`-tier graph (kg_facts only, via
       db.graph_traverse_facts) to find the most likely entity path(s)
       connecting them. FALLBACK (đề xuất #6): if BFS finds no path, or a
       low-coverage one, try graph_ppr_facts() to find high-probability
       bridge entities OUTSIDE the depth cap, add them to the seed set, and
       re-run BFS once — does not replace BFS, only extends its seeds. Per
       đề xuất #10, the PPR score itself is NEVER assigned directly as a
       fact's relevance — it only nominates bridge entities that get
       mapped BACK through an explicit BFS re-run before anything derived
       from them is used.
    3. Map every edge on the path to its kg_facts row -> fact_evidence ->
       list of evidence atoms (db.get_fact_evidence_for_facts).
    4. Path Coverage (flat) = edges with >=1 evidence atom / total edges on
       the path. Below settings.d_entity_path_coverage_threshold: issue a
       targeted sub-query ("{entity_a} {relation} {entity_b}") via
       dense_search_atom for exactly the missing edge, capped at
       settings.d_entity_path_max_gap_rounds rounds so a chain with many
       gaps can't blow up per-query latency. Unchanged by đề xuất #8 below —
       still the sole signal that decides which edges to gap-fill.
    5. Chain Coverage (đề xuất #8) — SEPARATE from path_coverage: for each
       pair of seed entities in the question, rebuild the ONE linear chain
       A->...->B (via db.graph_traverse_facts's new `path` column) and
       measure the longest contiguous evidence PREFIX from the start,
       stopping at the first gap — unlike path_coverage's flat edge count,
       this distinguishes a gap that breaks the chain from the start/middle
       vs. one near the end that still leaves the earlier reasoning usable.
    6. Returns (candidates, entity_paths, chain_coverage):
       - candidates: RetrievedCandidate objects (origin="graph_expansion",
         source="graph", relation=<fact relation_type>) ready to be fused
         with dense/bm25/graph_search/community_search via
         reciprocal_rank_fusion — this function does NOT call
         rerank1/self_verify itself, the caller (retrieve()) does that once
         on the whole merged pool.
       - entity_paths (đề xuất #1): the entity-fact CHAIN itself
         (list[EntityPathHop]), kept intact instead of being flattened away
         — this is what lets stage E show the LLM "Redis --CAUSES-->
         Session Loss --TRIGGERS--> Auth Retry" as one chain instead of
         making it re-infer the chain from scattered atoms.
       - chain_coverage (đề xuất #8/#9): Optional[float], min across
         reconstructable seed pairs, or None if not applicable (single-hop
         / <2 seeds / no path) — the caller (retrieve()) now threads this
         into self_verify() as a binary gate instead of letting it vanish
         after this function returns.
    """
    # ----- Bắt đầu logging -----
    print(f"[ENTITY-PATH] ====== Bắt đầu Entity-Path Search ======")
    print(f"[ENTITY-PATH] Query: {query_text}")
    # -----

    if not settings.d_entity_path_enabled:
        return [], [], None
    top_k = top_k or settings.d_entity_path_top_k
    
    # print(f"[ENTITY-PATH] Entity IDs tìm thấy (trực tiếp từ câu hỏi): {direct_entity_ids}")
    direct_entity_ids = _entities_from_query(query_text, source_id, llm)
    # Đề xuất #7 — luôn HỢP NHẤT (loại trùng), không phải thay-toàn-bộ.
    seed_entity_ids = list(dict.fromkeys(direct_entity_ids + (fallback_entity_ids or [])))
    if fallback_entity_ids:
        print(f"[ENTITY-PATH] Hợp nhất với fallback ({len(fallback_entity_ids)} entity từ dense-seed) "
              f"-> {len(seed_entity_ids)} seed sau khi loại trùng: {seed_entity_ids}")

    if len(seed_entity_ids) < 2:
        print("[ENTITY-PATH] Không đủ entity seed, bỏ qua entity-path search.")
        return [], [], None

    path_rows = db.graph_traverse_facts(seed_entity_ids, max_depth=settings.d_entity_path_max_depth,
                                         source_id=source_id,
                                         bidirectional=settings.d_entity_path_bidirectional)

 

    # Đề xuất #6 — BFS depth-capped có thể bỏ lỡ path dài hơn max_depth (hoặc
    # không tìm thấy path nào). Khi đó, thử PPR full-graph trên kg_facts để
    # tìm entity trung gian xác suất cao nằm ngoài max_depth, thêm vào seed
    # set và chạy lại BFS một lần — chỉ mở rộng seed, không thay BFS.
    if settings.d_entity_path_ppr_fallback_enabled:
        need_ppr = not path_rows
        if path_rows:
            ev_now = db.get_fact_evidence_for_facts([r["fact_id"] for r in path_rows if r.get("fact_id")])
            covered_fact_ids_now = {e["fact_id"] for e in ev_now}
            coverage_now = (sum(1 for r in path_rows if r.get("fact_id") in covered_fact_ids_now)
                             / len(path_rows))
            need_ppr = coverage_now < settings.d_entity_path_coverage_threshold
        if need_ppr:
            # Đề xuất #13 — mỗi seed entity là 1 cụm riêng (đơn giản nhất,
            # xem docstring graph_ppr_facts_multi), PPR chạy ĐỘC LẬP từng
            # cụm thay vì 1 personalization vector gộp toàn bộ seed (dễ bị
            # cụm đông/hub degree cao lấn át cụm nhỏ). Chỉ bật khi số cụm
            # đủ nhỏ (<= d_graph_ppr_facts_multi_max_clusters) — vượt quá
            # mức đó, chi phí N lần pagerank không còn "chấp nhận được" như
            # phân tích trong đề xuất #13, fallback về graph_ppr_facts gộp
            # 1 lần như cũ.
            if (settings.d_graph_ppr_facts_multi_enabled
                    and len(seed_entity_ids) <= settings.d_graph_ppr_facts_multi_max_clusters):
                seed_clusters = [[eid] for eid in seed_entity_ids]
                ppr_hits = graph_ppr_facts_multi(seed_clusters, source_id=source_id,
                                                  top_k_per_run=settings.d_entity_path_ppr_top_k)
            else:
                ppr_hits = graph_ppr_facts(seed_entity_ids, source_id=source_id,
                                            top_k=settings.d_entity_path_ppr_top_k)
            if ppr_hits:
                bridge_ids = [h["entity_id"] for h in ppr_hits]
                print(f"[ENTITY-PATH] BFS depth-capped không đủ, thử PPR fallback trên kg_facts — "
                      f"bridge entities: {bridge_ids}")
                extended_seeds = list(dict.fromkeys(seed_entity_ids + bridge_ids))
                extended_path_rows = db.graph_traverse_facts(
                    extended_seeds, max_depth=settings.d_entity_path_max_depth, source_id=source_id,
                                         bidirectional=settings.d_entity_path_bidirectional)
                if len(extended_path_rows) > len(path_rows):
                    print(f"[ENTITY-PATH] PPR fallback mở rộng path: {len(path_rows)} -> "
                          f"{len(extended_path_rows)} cạnh")
                    path_rows = extended_path_rows

    if not path_rows:
        print("[ENTITY-PATH] Không tìm thấy đường đi nào giữa các entity.")
        return [], [], None

    print(f"[ENTITY-PATH] Tìm thấy {len(path_rows)} cạnh fact trên đường đi:")
    for i, r in enumerate(path_rows):
        print(f"  {i+1}. {r['source_entity_id']} --{r['relation_type']}--> {r['target_entity_id']} "
              f"(depth={r['depth']}, seed_reach_count={r.get('seed_reach_count', '?')})")   

    fact_ids = [r["fact_id"] for r in path_rows if r.get("fact_id")]
    evidence_rows = db.get_fact_evidence_for_facts(fact_ids)
    evidence_by_fact: dict[str, list[dict]] = {}
    for ev in evidence_rows:
        evidence_by_fact.setdefault(ev["fact_id"], []).append(ev)

    covered_edges = sum(1 for r in path_rows if evidence_by_fact.get(r["fact_id"]))
    path_coverage = covered_edges / len(path_rows) if path_rows else 1.0
    logger.info("entity_path_search: %d edges on path, coverage=%.2f", len(path_rows), path_coverage)

    # Đề xuất #8/#9 — chain_coverage: dùng seed_entity_ids GỐC (entity của
    # câu hỏi, không gồm bridge_ids do PPR fallback thêm vào ở bước trên —
    # bridge_ids có thể xuất hiện Ở GIỮA path_rows, nhưng cặp (A,B) để tính
    # chain vẫn phải là các entity thật của câu hỏi).
    chain_coverage = _chain_coverage_for_pairs(path_rows, seed_entity_ids, evidence_by_fact)
    logger.info("entity_path_search: chain_coverage=%s", chain_coverage)

    # Nhãn hiển thị cho entity — cần cho CẢ entity_paths (đề xuất #1) lẫn
    # gap-fill sub-query bên dưới, nên tính một lần, dùng chung (trước đây
    # chỉ tính khi gap-fill chạy, entity_paths không có sẵn nhãn).
    entity_labels = {n["id"]: n["label"] for n in db.get_nodes_edges_for_source(source_id)[0]} \
        if source_id else {}

    candidates: list[RetrievedCandidate] = []
    seen_atom_ids: set[str] = set()
    # atom_id -> seed_reach_count of the fact-edge it's evidence for. This is
    # the real "neo" (anchor) check: an entity reached from >=2 DISTINCT
    # query entities within max_depth is a genuine bridge on a path that
    # connects the question's entities; one reached from only 1 seed is
    # just a nearby neighbor of a single entity, with nothing yet confirming
    # it actually relates to the rest of the question.
    convergence_by_atom_id: dict[str, int] = {}
    for r in path_rows:
        for ev in evidence_by_fact.get(r["fact_id"], []):
            if ev["atom_id"] in seen_atom_ids:
                continue
            seen_atom_ids.add(ev["atom_id"])
            convergence_by_atom_id[ev["atom_id"]] = int(r.get("seed_reach_count") or 1)
            candidates.append(RetrievedCandidate(
                atom_id=ev["atom_id"], raw=ev["raw"], normalized=ev.get("normalized"),
                section_id=ev.get("section_id"), source="entity_path_hit", origin="graph_expansion",
                relation=r["relation_type"], linked_from=r["source_entity_id"],
                # Graph-trust placeholder — kg_facts.confidence, which
                # actually grows with the number of independent atoms that
                # corroborated this entity-entity relation (see
                # b2_wiki_graph_chunking.build_kg / a5_5_fact_extraction),
                # unlike fact_evidence.confidence which is a near-constant
                # per-row value. Blended with query similarity below —
                # NOT overwritten by it, see the hop-decayed blend a few
                # lines down.
                relevance_score=float(ev.get("fact_confidence") if ev.get("fact_confidence") is not None else 0.5),
                confidence=float(ev.get("atom_confidence") or 0), rank=r["depth"],
                contradicts_flag=bool(ev.get("contradicts_flag")),
                location=f"{ev.get('source_id')} — Chapter {ev.get('chapter')}, Page {ev.get('page_start')}",
            ))

    # Đề xuất #1 — giữ nguyên chuỗi entity-fact TRƯỚC KHI nó bị "phẳng hóa"
    # thành candidates rời rạc ở trên (mỗi candidate chỉ là 1 evidence atom,
    # mất hoàn toàn thứ tự/chuỗi liên kết). entity_paths giữ đúng thứ tự
    # path_rows (đã ORDER BY depth ASC từ graph_traverse_facts).

    _paths_for_prompt = sorted(
        path_rows,
        key=lambda r: (
            0 if int(r.get("seed_reach_count") or 1) >= 2 else 1,
            0 if evidence_by_fact.get(r.get("fact_id")) else 1,
            r["depth"],
        ),
    )[: settings.d_entity_paths_max_hops_for_prompt]
    if len(_paths_for_prompt) < len(path_rows):
        print(f"[ENTITY-PATH] entity_paths cho prompt: cắt {len(path_rows)} -> "
              f"{len(_paths_for_prompt)} hop (ưu tiên connector/có evidence/depth thấp)")

    
    entity_paths: list[EntityPathHop] = [
        EntityPathHop(
            source_entity_id=r["source_entity_id"],
            target_entity_id=r["target_entity_id"],
            source_label=entity_labels.get(r["source_entity_id"], r["source_entity_id"]),
            relation_type=r["relation_type"],
            target_label=entity_labels.get(r["target_entity_id"], r["target_entity_id"]),
            evidence_atom_ids=[ev["atom_id"] for ev in evidence_by_fact.get(r["fact_id"], [])],
        )
        for r in _paths_for_prompt
    ]

    for c in _paths_for_prompt:
        print(f"_paths_for_prompt  source_entity_id [{c["source_entity_id"]}] target_entity_id={c["target_entity_id"]} depth={c["depth"]}")


    # Evidence-gap -> targeted sub-query, capped rounds to bound latency.
    gap_edges = [r for r in path_rows if not evidence_by_fact.get(r["fact_id"])]
    rounds = min(len(gap_edges), settings.d_entity_path_max_gap_rounds)
    if path_coverage < settings.d_entity_path_coverage_threshold and rounds > 0:
        for r in gap_edges[:rounds]:
            src_label = entity_labels.get(r["source_entity_id"], r["source_entity_id"])
            tgt_label = entity_labels.get(r["target_entity_id"], r["target_entity_id"])
            sub_query = f"{src_label} {r['relation_type']} {tgt_label}"
            sub_hits = dense_search_atom(sub_query, llm, limit=3, source_id=source_id)
            for c in sub_hits:
                if c.atom_id in seen_atom_ids:
                    continue
                seen_atom_ids.add(c.atom_id)
                c.origin = "graph_expansion"
                c.relation = r["relation_type"]
                # dense_search_atom sets .rank = enumerate index (0,1,2...),
                # not hop depth — overwrite so the hop-decay blend below
                # treats gap-fill candidates consistently with path-evidence
                # ones (both keyed by actual BFS depth of the edge they fill).
                c.rank = r["depth"]
                convergence_by_atom_id[c.atom_id] = int(r.get("seed_reach_count") or 1)
                candidates.append(c)

    if not candidates:
        return [], entity_paths, chain_coverage

    # Calibrate against the actual question before returning — but NOT with
    # a flat blend ratio, and NOT with a flat floor either. Two separate
    # design requirements, both must hold at once:
    #   1. Multi-hop BRIDGE evidence must not be punished just for having
    #      low text overlap with the question (a hop-2/hop-3 atom supports
    #      an intermediate link, not a restatement of the question) — so
    #      query_similarity's weight DECAYS with hop depth (c.rank).
    #   2. That decay must stay ANCHORED to the question, not drift freely
    #      just because something is "on a path from some entity" — so the
    #      floor itself depends on whether the node is a genuine
    #      convergence point (seed_reach_count >= 2: reached from >=2
    #      DISTINCT query entities, i.e. verified to actually sit on a path
    #      connecting them) vs. a single-seed flood-fill neighbor
    #      (seed_reach_count == 1: only confirmed near ONE query entity,
    #      nothing yet ties it to the rest of the question). Only genuine
    #      bridges get the deep floor; unconverged neighbors keep a higher
    #      floor so they can't drift arbitrarily far from the question text
    #      just by riding hop depth down — the "tam sao thất bản" case this
    #      is meant to prevent.
    # Same cross-encoder already used for expanded/graph candidates
    # (_batch_score_query_similarity), so scores live on the same 0..1
    # scale as the rest of the pool.
    prior_score = {c.atom_id: c.relevance_score for c in candidates}
    _batch_score_query_similarity(query_text, candidates)
    for c in candidates:
        hop = max(c.rank or 1, 1)
        converged = convergence_by_atom_id.get(c.atom_id, 1) >= 2
        floor = (settings.d_entity_path_query_weight_floor if converged
                 else settings.d_entity_path_query_weight_floor_unconverged)
        query_weight = max(settings.d_entity_path_query_weight_hop1
                            - settings.d_entity_path_query_weight_decay * (hop - 1),
                            floor)
        c.relevance_score = query_weight * c.query_similarity + (1 - query_weight) * prior_score.get(c.atom_id, 0.0)
    candidates.sort(key=lambda c: c.relevance_score, reverse=True)
    return candidates[:top_k], entity_paths, chain_coverage
