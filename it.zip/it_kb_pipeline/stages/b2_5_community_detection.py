"""
B2.5 — Community Detection + Lazy Summary

DÙNG LEIDEN THAY LOUVAIN — xem ke_hoach_trien_khai_cai_tien_graph.md P1
"""
from __future__ import annotations

import logging

from common import db
from common.config import settings
from common.llm_client import LLMClient
from common.schemas import ChunkRecord

logger = logging.getLogger(__name__)

COMMUNITY_SUMMARY_SYSTEM_PROMPT = """Bạn tóm tắt một cụm (community) các đoạn tri thức (atom) và thực thể (entity)
có liên quan chặt chẽ với nhau trong 1 tài liệu, dựa trên đồ thị tri thức.
Viết 2-4 câu tóm tắt chủ đề chung của cụm này bằng tiếng Việt, dựa CHỈ trên nội dung được cung cấp.
Không suy diễn thêm thông tin không có trong danh sách. Trả lời CHỈ bằng đoạn văn bản, không thêm JSON/markdown."""


def _edge_weight(relation: str, score) -> float:
    if relation == "SIMILAR_TO":
        return float(score) if score is not None else 0.5
    if relation == "MENTIONS":
        return 1.0
    if relation == "CONTRADICTS":
        return 0.3
    if relation in ("INSTANCE_OF", "SAME_SECTION"):
        return 0.15
    return 0.7  # DEFINES/EXTENDS/RELATED_TO / PARENT_OF


def detect_communities(source_id: str) -> list[list[str]]:
    """Runs Leiden over the persisted graph for one document.
    Loại SIMILAR_TO khỏi đồ thị phân cụm — xem ke_hoach_trien_khai_cai_tien_graph.md P1.
    """
    # Các quan hệ được dùng để phân cụm — KHÔNG bao gồm SIMILAR_TO
    CLUSTERING_RELATIONS = {"MENTIONS", "DEFINES", "EXTENDS", "CONTRADICTS", "RELATED_TO", "PARENT_OF"}

    try:
        import igraph as ig
        import leidenalg
    except ImportError:
        logger.warning("python-igraph/leidenalg not installed — skipping community detection for %s", source_id)
        return []

    nodes, edges = db.get_nodes_edges_for_source(source_id)
    if not nodes:
        return []

    # Xây graph CHỈ với các quan hệ trong CLUSTERING_RELATIONS
    # Dùng dict để gom trọng số trước khi chuyển sang igraph
    edge_weights: dict[tuple[str, str], float] = {}
    for e in edges:
        if e["relation"] not in CLUSTERING_RELATIONS:
            continue
        w = _edge_weight(e["relation"], e.get("score"))
        key = tuple(sorted([e["source_id"], e["target_id"]]))
        edge_weights[key] = edge_weights.get(key, 0.0) + w

    if not edge_weights:
        return []

    # Chuyển sang igraph
    node_list = [n["id"] for n in nodes]
    node_index = {nid: i for i, nid in enumerate(node_list)}
    ig_graph = ig.Graph()
    ig_graph.add_vertices(len(node_list))

    ig_edges = [(node_index[u], node_index[v]) for (u, v) in edge_weights.keys()]
    ig_weights = list(edge_weights.values())
    ig_graph.add_edges(ig_edges)
    ig_graph.es["weight"] = ig_weights

    try:
        partition = leidenalg.find_partition(
            ig_graph,
            leidenalg.RBConfigurationVertexPartition,
            weights="weight",
            seed=42,
        )
        communities = [
            [node_list[idx] for idx in cluster] for cluster in partition
        ]
    except Exception as e:
        logger.warning("Leiden community detection failed for %s: %s", source_id, e)
        return []

    # Lọc cộng đồng nhỏ
    filtered = [c for c in communities if len(c) >= settings.b2_5_min_community_size]

    # --- ĐO TỶ LỆ ATOM CÔ LẬP — xem ke_hoach_trien_khai_cai_tien_graph.md P1 ---
    all_clustered = {nid for c in filtered for nid in c}
    isolated = [n["id"] for n in nodes if n["id"] not in all_clustered]
    isolated_rate = len(isolated) / max(len(nodes), 1)
    logger.info(
        "[B2.5][isolated-check] source=%s: %d/%d node cô lập (%.1f%%) sau khi loại SIMILAR_TO khỏi clustering",
        source_id, len(isolated), len(nodes), isolated_rate * 100,
    )
    if isolated_rate > 0.35:
        logger.warning(
            "[B2.5][isolated-check] source=%s: tỷ lệ cô lập %.1f%% VƯỢT ngưỡng 35%% — "
            "cân nhắc thêm SAME_SECTION (weight thấp) hoặc nới CLUSTERING_RELATIONS",
            source_id, isolated_rate * 100,
        )

    return filtered


def _member_labels(member_ids: list[str]) -> list[str]:
    """Fetch display text for a community's members."""
    labels: list[str] = []
    atom_ids = [m for m in member_ids if not m.startswith("ent_")]
    atoms = db.atoms_for_ids(atom_ids[:50])
    for aid in atom_ids[:50]:
        a = atoms.get(aid)
        if a:
            labels.append(f"[{a['label']}] {a['normalized'] or a['raw']}")
    return labels


def build_community_summaries(source_id: str, func_get_llm: Callable[[], Any]) -> list[ChunkRecord]:
    """Entry point for stage B2.5."""
    communities = detect_communities(source_id)
    if not communities:
        return []

    previous = db.load_community_membership(source_id)
    previous_sets = {cid: set(members) for cid, members in previous.items()}

    records: list[ChunkRecord] = []
    seen_community_ids: set[str] = set()

    for i, member_ids in enumerate(communities):
        llm = func_get_llm()
        community_id = f"community_{source_id}_{i}"
        seen_community_ids.add(community_id)
        member_set = set(member_ids)

        if previous_sets.get(community_id) == member_set:
            continue

        labels = _member_labels(member_ids)
        if not labels:
            continue
        prompt = "Các atom/entity trong cụm:\n" + "\n".join(f"- {l}" for l in labels)
        try:
            summary_text = llm.generate(prompt, system=COMMUNITY_SUMMARY_SYSTEM_PROMPT,
                                         json_mode=False, tier="light").strip()
        except Exception as e:
            logger.warning("Community summary LLM call failed for %s: %s", community_id, e)
            continue
        if not summary_text:
            continue

        try:
            embedding = llm.embed([summary_text])[0]
        except Exception:
            embedding = None

        rec = ChunkRecord(id=community_id, type="community", content=summary_text,
                           embedding=embedding, children=member_ids,
                           metadata={"source_id": source_id, "member_count": len(member_ids)})
        db.upsert_chunk_record(rec)
        db.save_community_membership(source_id, community_id, member_ids)
        records.append(rec)

    return records