
from __future__ import annotations

import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from common import db
from common.llm_client import LLMClient, LocalEmbedder
from itertools import cycle


from common.llm_client import get_llm_client
from common.schemas import RetrievalQuery
from stages import (
    a1_parser, a2_reading_order, a3_global_index, a3_5_hashing,
    a4_constraint_extraction, a5_global_merge, b1_dedup, b2_wiki_graph_chunking,
    c_storage, d_retrieval, e_query_output,
)

def step(title: str) -> None:
    print(f"\n{'=' * 70}\n{title}\n{'=' * 70}")


def main() -> None:

    llm = get_llm_client()     

    # =====================================================================
    # KNOWLEDGE BASE ĐÃ SẴN SÀNG — bây giờ thử truy vấn (D -> E)
    # =====================================================================
    step("TRUY VẤN KNOWLEDGE BASE VỪA TẠO")
    query_text = "Khi thực hiện sao lưu định kỳ, dữ liệu phục vụ việc đăng nhập và dữ liệu phục vụ việc xử lý đơn hàng có được gộp chung trong cùng một lần sao lưu hay tách biệt hoàn toàn với nhau? Vì sao lại như vậy?"
    print(f"query: {query_text!r}")

    # D — INPUT: RetrievalQuery  ->  OUTPUT: RetrievalResult (dense+bm25+graph, RRF, rerank, self-verify)
    retrieval = d_retrieval.retrieve(
        RetrievalQuery(query_text=query_text, top_k_final=20, source_id="abc1"), llm)
    print(f"\nD — retrieve(): insufficient_context={retrieval.insufficient_context}  "
          f"candidates={len(retrieval.candidates)}")
    # for c in retrieval.candidates:
    #     print(f"candidates  [{c.source}] score={c.relevance_score:.3f}  {c.raw[:80]!r}  {c.type}")
    
    # for c in retrieval.suggestions:
    #     print(f"suggestions  [{c.source}] section_id={c.section_id}  score={c.relevance_score:.3f}  {c.raw[:80]!r}  {c.type}")

    # E — INPUT: RetrievalResult  ->  OUTPUT: AnswerWithCitations (câu trả lời cuối)
    answer = e_query_output.answer_query(query_text, retrieval, llm)
    print(f"\nE — answer_query():")
    print(f"answer: {answer.answer}")
    print(f"citations:")
    for c in answer.citations:
        print(f"  [#{c.atom_id}] {c.raw!r}  ({c.location})")
    # print(f"suggestions:")
    # for c in answer.suggestions:
    #     print(f"  [#{c.type}] {c.content_preview!r}")    


if __name__ == "__main__":
    main()
